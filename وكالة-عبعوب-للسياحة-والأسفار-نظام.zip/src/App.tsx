/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Customer, Trip, Employee, Branch, OperationLog, AgencySettings, Receipt } from './types';
import { defaultTrips } from './data/trips';
import { Logo } from './components/Logo';
import { CustomerForm, getRoomOptionsForTrip, getTripPriceLabelsAndDefaults } from './components/CustomerForm';
import { CustomerTable } from './components/CustomerTable';
import { PrintDocument } from './components/PrintDocument';
import { TripManifests } from './components/TripManifests';
import { Login } from './components/Login';
import { ReceiptVoucher } from './components/ReceiptVoucher';
import { 
  db, 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  deleteDoc, 
  query, 
  orderBy 
} from './lib/firebase';
import { 
  Users, 
  Map, 
  Wallet, 
  Database, 
  Download, 
  Upload, 
  Clock, 
  Plus, 
  Sparkles, 
  Trash2, 
  LayoutDashboard, 
  Compass, 
  Share2, 
  CheckCircle2, 
  AlertCircle,
  Edit2,
  X,
  LogOut,
  Building2,
  ShieldCheck,
  ArrowLeftRight,
  HelpCircle,
  BookOpen,
  UserSquare2,
  DollarSign,
  UserPlus2,
  ShieldAlert,
  RefreshCw,
  Check,
  TrendingUp,
  Receipt as ReceiptIcon
} from 'lucide-react';

// Color shade generator helpers for dynamic theme styling
function hexToRgb(hex: string): { r: number, g: number, b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16)
  } : null;
}

function rgbToHex(r: number, g: number, b: number): string {
  return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

function adjustColorBrightness(hex: string, percent: number): string {
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;
  const r = Math.max(0, Math.min(255, Math.round(rgb.r + (255 - rgb.r) * percent)));
  const g = Math.max(0, Math.min(255, Math.round(rgb.g + (255 - rgb.g) * percent)));
  const b = Math.max(0, Math.min(255, Math.round(rgb.b + (255 - rgb.b) * percent)));
  return rgbToHex(r, g, b);
}

function darkenColor(hex: string, percent: number): string {
  const rgb = hexToRgb(hex);
  if (!rgb) return hex;
  const r = Math.max(0, Math.min(255, Math.round(rgb.r * (1 - percent))));
  const g = Math.max(0, Math.min(255, Math.round(rgb.g * (1 - percent))));
  const b = Math.max(0, Math.min(255, Math.round(rgb.b * (1 - percent))));
  return rgbToHex(r, g, b);
}

const DEFAULT_BRANCHES: Branch[] = [
  { id: 'branch-touggourt', name: 'فرع تقرت الرئيسي', location: 'حي عياد تبسبست، تقرت' },
  { id: 'branch-algiers', name: 'فرع الجزائر العاصمة', location: 'شارع ديدوش مراد، الجزائر العاصمة' },
  { id: 'branch-ouargla', name: 'فرع ورقلة', location: 'وسط المدينة، ورقلة' }
];

const DEFAULT_EMPLOYEES: Employee[] = [
  { id: 'emp-1', username: 'admin', name: 'عبد الفتاح عبعوب', role: 'Admin', branchId: 'branch-touggourt', branchName: 'فرع تقرت الرئيسي' },
  { id: 'emp-2', username: 'manager_algiers', name: 'أحمد بن علي', role: 'Manager', branchId: 'branch-algiers', branchName: 'فرع الجزائر العاصمة' },
  { id: 'emp-3', username: 'agent_touggourt', name: 'بلال تبسبستي', role: 'Agent', branchId: 'branch-touggourt', branchName: 'فرع تقرت الرئيسي' },
  { id: 'emp-4', username: 'agent_ouargla', name: 'ليلى هلالي', role: 'Agent', branchId: 'branch-ouargla', branchName: 'فرع ورقلة' }
];

interface TripProfitDetailEditorProps {
  trip: Trip;
  customers: Customer[];
  onSaveExpenses: (
    tripId: string,
    acc: number,
    trans: number,
    guide: number,
    ins: number,
    other: number
  ) => Promise<void>;
  onBack: () => void;
}

function TripProfitDetailEditor({ trip, customers, onSaveExpenses, onBack }: TripProfitDetailEditorProps) {
  const [acc, setAcc] = useState(trip.expenseAccommodation || 0);
  const [trans, setTrans] = useState(trip.expenseTransport || 0);
  const [guide, setGuide] = useState(trip.expenseGuide || 0);
  const [ins, setIns] = useState(trip.expenseInsurance || 0);
  const [other, setOther] = useState(trip.expenseOther || 0);
  const [isSaving, setIsSaving] = useState(false);

  // Synchronize state if trip changes
  useEffect(() => {
    setAcc(trip.expenseAccommodation || 0);
    setTrans(trip.expenseTransport || 0);
    setGuide(trip.expenseGuide || 0);
    setIns(trip.expenseInsurance || 0);
    setOther(trip.expenseOther || 0);
  }, [trip]);

  const tripCustomers = customers.filter(c => c.tripId === trip.id);
  const totalSales = tripCustomers.reduce((sum, c) => {
    if (c.totalPrice !== undefined) return sum + c.totalPrice;
    return sum + (trip.price * (c.peopleCount || 1));
  }, 0);

  const expensesSum = acc + trans + guide + ins + other;
  const netProfit = totalSales - expensesSum;

  const handleSave = async () => {
    setIsSaving(true);
    await onSaveExpenses(trip.id, acc, trans, guide, ins, other);
    setIsSaving(false);
  };

  return (
    <div className="space-y-4 text-right animate-in fade-in duration-200">
      {/* Header section with Back Button */}
      <div className="flex items-center justify-between bg-stone-50 p-3 rounded-2xl border border-stone-150">
        <div>
          <h4 className="text-xs font-black text-stone-850">{trip.name}</h4>
          <p className="text-[10px] text-stone-450 font-bold">{trip.destination} • {trip.date}</p>
        </div>
        <button
          type="button"
          onClick={onBack}
          className="px-3 py-1.5 bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 font-bold rounded-xl text-[10px] transition-all cursor-pointer flex items-center gap-1"
        >
          <span>← رجوع لقائمة الرحلات</span>
        </button>
      </div>

      {/* Earned Money */}
      <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-150 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <span className="text-[11px] font-bold text-emerald-800 block">💰 إجمالي المبالغ المكتسبة من الحاجزين (الفلوس لي كسبتها):</span>
          <span className="text-[10px] text-emerald-600/90 font-bold">عدد المسافرين المسجلين في هذه الرحلة: {tripCustomers.reduce((sum, c) => sum + (c.peopleCount || 0), 0)} مسافر</span>
        </div>
        <div className="text-left font-mono">
          <span className="text-lg font-black text-emerald-700">{totalSales.toLocaleString()} <span className="text-[10px] font-sans font-extrabold text-emerald-600">د.ج</span></span>
        </div>
      </div>

      {/* The 5 empty expense fields */}
      <div className="bg-stone-50/50 p-4 rounded-2xl border border-stone-150 space-y-3">
        <h5 className="text-[11px] font-black text-stone-700 block">💸 مصاريف ونفقات الرحلة (د.ج):</h5>
        
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-stone-500">🏨 الإقامة</label>
            <input
              type="number"
              value={acc === 0 ? '' : acc}
              onChange={(e) => setAcc(Number(e.target.value))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-xl text-center font-bold text-xs font-mono focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
            />
          </div>
          
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-stone-500">🚌 النقل</label>
            <input
              type="number"
              value={trans === 0 ? '' : trans}
              onChange={(e) => setTrans(Number(e.target.value))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-xl text-center font-bold text-xs font-mono focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-stone-500">🚩 المرشد</label>
            <input
              type="number"
              value={guide === 0 ? '' : guide}
              onChange={(e) => setGuide(Number(e.target.value))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-xl text-center font-bold text-xs font-mono focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-stone-500">🛡️ التأمين</label>
            <input
              type="number"
              value={ins === 0 ? '' : ins}
              onChange={(e) => setIns(Number(e.target.value))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-xl text-center font-bold text-xs font-mono focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
            />
          </div>

          <div className="space-y-1 col-span-2 sm:col-span-1">
            <label className="block text-[10px] font-bold text-stone-500">⚙️ أخرى</label>
            <input
              type="number"
              value={other === 0 ? '' : other}
              onChange={(e) => setOther(Number(e.target.value))}
              placeholder="0"
              className="w-full px-2.5 py-1.5 bg-white border border-stone-200 rounded-xl text-center font-bold text-xs font-mono focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Live Formula */}
      <div className="bg-amber-50/50 p-3 rounded-2xl border border-amber-100/80 flex flex-col items-center justify-center text-center gap-1.5">
        <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px] md:text-xs font-bold text-stone-600">
          <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-lg font-mono">{totalSales.toLocaleString()} د.ج</span>
          <span className="text-stone-400 font-extrabold">-</span>
          <span className="bg-red-50 text-red-700 px-2 py-0.5 rounded-lg font-mono">({acc.toLocaleString()} + {trans.toLocaleString()} + {guide.toLocaleString()} + {ins.toLocaleString()} + {other.toLocaleString()})</span>
          <span className="text-stone-400 font-extrabold">=</span>
          <span className={`px-2 py-0.5 rounded-lg font-mono font-black ${netProfit >= 0 ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>
            {netProfit.toLocaleString()} د.ج
          </span>
        </div>
        <p className="text-[9px] text-stone-400 font-bold">
          * قيمة الأرباح الصافية الحالية تساوي المبلغ الإجمالي المكتسب مطروحاً منه كافة المصاريف المدخلة أعلاه.
        </p>
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
        <button
          type="button"
          onClick={onBack}
          className="px-4 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
        >
          رجوع
        </button>
        <button
          type="button"
          disabled={isSaving}
          onClick={handleSave}
          className="px-5 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-stone-300 text-white font-bold rounded-xl text-xs transition-all cursor-pointer inline-flex items-center gap-1 shadow-xs"
        >
          {isSaving ? (
            <span className="block w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
          ) : (
            <Check size={12} />
          )}
          <span>حفظ المصاريف والأرباح</span>
        </button>
      </div>
    </div>
  );
}

export default function App() {
  // 1. STATE INITIALIZATION
  const [customers, setCustomers] = useState<Customer[]>(() => {
    try {
      const cached = localStorage.getItem('aboub_customers');
      return cached ? JSON.parse(cached) : [];
    } catch {
      return [];
    }
  });

  const [trips, setTrips] = useState<Trip[]>(() => {
    try {
      const cached = localStorage.getItem('aboub_trips');
      if (cached) {
        const parsed: Trip[] = JSON.parse(cached);
        // Find default trips not currently in local cache (like Sharm El Sheikh added recently)
        const missingDefaults = defaultTrips.filter(
          dt => !parsed.some(pt => pt.id === dt.id)
        );
        if (missingDefaults.length > 0) {
          const merged = [...parsed, ...missingDefaults];
          localStorage.setItem('aboub_trips', JSON.stringify(merged));
          return merged.filter(t => t.status !== 'deleted');
        }
        return parsed.filter(t => t.status !== 'deleted');
      }
      return defaultTrips.filter(t => t.status !== 'deleted');
    } catch {
      return defaultTrips.filter(t => t.status !== 'deleted');
    }
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'manifests' | 'trips' | 'options' | 'admin' | 'receipt'>('dashboard');
  const [receipts, setReceipts] = useState<Receipt[]>(() => {
    try {
      const cached = localStorage.getItem('aboub_receipts');
      return cached ? JSON.parse(cached) : [];
    } catch {
      return [];
    }
  });
  const [selectedPrintCustomer, setSelectedPrintCustomer] = useState<Customer | null>(null);
  const [selectedTripFilter, setSelectedTripFilter] = useState<string>('all');
  const [tripStatusFilter, setTripStatusFilter] = useState<'all' | 'active' | 'upcoming' | 'suspended' | 'completed'>('all');
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  
  // CORPORATE ACCESS & TRACKING STATES
  const [branches, setBranches] = useState<Branch[]>(() => {
    try {
      const cached = localStorage.getItem('aboub_branches');
      return cached ? JSON.parse(cached) : DEFAULT_BRANCHES;
    } catch {
      return DEFAULT_BRANCHES;
    }
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    try {
      const cached = localStorage.getItem('aboub_employees');
      return cached ? JSON.parse(cached) : DEFAULT_EMPLOYEES;
    } catch {
      return DEFAULT_EMPLOYEES;
    }
  });

  const [logs, setLogs] = useState<OperationLog[]>(() => {
    try {
      const cached = localStorage.getItem('aboub_logs');
      return cached ? JSON.parse(cached) : [];
    } catch {
      return [];
    }
  });

  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(() => {
    try {
      const cached = localStorage.getItem('aboub_current_employee');
      return cached ? JSON.parse(cached) : DEFAULT_EMPLOYEES[0];
    } catch {
      return DEFAULT_EMPLOYEES[0];
    }
  });

  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>('all');

  // Employee Management Form States
  const [newEmpName, setNewEmpName] = useState('');
  const [newEmpUsername, setNewEmpUsername] = useState('');
  const [newEmpPassword, setNewEmpPassword] = useState('123');
  const [newEmpRole, setNewEmpRole] = useState<'Admin' | 'Manager' | 'Agent'>('Agent');
  const [newEmpBranchId, setNewEmpBranchId] = useState('');

  // Employee Editing / Deactivation States
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [editEmpName, setEditEmpName] = useState('');
  const [editEmpUsername, setEditEmpUsername] = useState('');
  const [editEmpPassword, setEditEmpPassword] = useState('');
  const [editEmpRole, setEditEmpRole] = useState<'Admin' | 'Manager' | 'Agent'>('Agent');
  const [editEmpBranchId, setEditEmpBranchId] = useState('');

  // Branch Management Form States
  const [newBranchName, setNewBranchName] = useState('');
  const [newBranchLocation, setNewBranchLocation] = useState('');
  
  // Alert Status
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  // Time and Date tracker
  const [currentTime, setCurrentTime] = useState(new Date());

  // Agency Settings & Configuration
  const [agencySettings, setAgencySettings] = useState<AgencySettings>({
    websiteName: 'وكالة عبعوب للسياحة والأسفار',
    websiteEnglishName: 'ABOUB TRAVEL & TOURISM',
    primaryColor: '#d97706',
  });

  // Secret triggers
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [secretModalTab, setSecretModalTab] = useState<'branding' | 'profits'>('branding');
  const [selectedProfitTripId, setSelectedProfitTripId] = useState<string | null>(null);
  const [secretPassword, setSecretPassword] = useState('');
  const [secretError, setSecretError] = useState('');

  // Settings Edit states
  const [editWebsiteName, setEditWebsiteName] = useState('وكالة عبعوب للسياحة والأسفار');
  const [editWebsiteEnglishName, setEditWebsiteEnglishName] = useState('ABOUB TRAVEL & TOURISM');
  const [editPrimaryColor, setEditPrimaryColor] = useState('#d97706');
  const [editReceiptLogoUrl, setEditReceiptLogoUrl] = useState('');
  const [editWebsiteLogoUrl, setEditWebsiteLogoUrl] = useState('');

  // EMPLOYEE / BRANCH WRITE ACTIONS
  const handleAddEmployeeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmpName.trim() || !newEmpUsername.trim() || !newEmpPassword.trim() || !newEmpBranchId) {
      showToast('الرجاء تعبئة كامل حقول حساب الموظف الجديد', 'error');
      return;
    }

    try {
      const generatedId = `emp-${Date.now()}`;
      const branchObj = branches.find(b => b.id === newEmpBranchId);
      const branchName = branchObj ? branchObj.name : 'فرع غير معروف';
      const newEmp: Employee = {
        id: generatedId,
        name: newEmpName.trim(),
        username: newEmpUsername.trim().toLowerCase(),
        password: newEmpPassword,
        role: newEmpRole,
        branchId: newEmpBranchId,
        branchName: branchName,
      };

      await setDoc(doc(db, 'employees', generatedId), newEmp);

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'add_employee' as const,
        details: `إنشاء حساب موظف جديد: ${newEmp.name} (اسم المستخدم: ${newEmp.username}) في ${branchName}`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      setNewEmpName('');
      setNewEmpUsername('');
      setNewEmpPassword('123');
      setNewEmpRole('Agent');
      showToast(`تم إنشاء حساب الموظف بنجاح!`, 'success');
    } catch (err) {
      console.error(err);
      showToast('خطأ في الاتصال بقاعدة البيانات', 'error');
    }
  };

  const handleDeleteEmployee = async (empId: string) => {
    if (empId === 'emp-1') {
      showToast('غير مسموح إطلاقاً بحذف حساب المدير العام الرئيسي للوكالة!', 'error');
      return;
    }
    if (empId === currentEmployee?.id) {
      showToast('غير مسموح أن تقوم بحذف حسابك الذي تستخدمه حالياً!', 'error');
      return;
    }

    try {
      const targetEmp = employees.find(e => e.id === empId);
      if (!targetEmp) {
        showToast('الموظف غير متوفر في السجلات', 'error');
        return;
      }
      await deleteDoc(doc(db, 'employees', empId));

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'delete_employee' as const,
        details: `حذف حساب الموظف: ${targetEmp.name} (اسم المستخدم: ${targetEmp.username})`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      showToast(`تم حذف وإنهاء حساب موظف الفرع بنجاح`, 'info');
    } catch (err) {
      console.error(err);
      showToast('خطأ في الاتصال بقاعدة البيانات', 'error');
    }
  };

  const handleUpdateEmployeeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee) return;
    if (!editEmpName.trim() || !editEmpUsername.trim() || !editEmpBranchId) {
      showToast('الرجاء كتابة الاسم واسم المستخدم واختيار فرع صالح', 'error');
      return;
    }

    try {
      const branchObj = branches.find(b => b.id === editEmpBranchId);
      const branchName = branchObj ? branchObj.name : 'فرع غير معروف';
      
      const updatedEmp: Employee = {
        ...editingEmployee,
        name: editEmpName.trim(),
        username: editEmpUsername.trim().toLowerCase(),
        password: editEmpPassword.trim() || editingEmployee.password,
        role: editEmpRole,
        branchId: editEmpBranchId,
        branchName: branchName,
      };

      await setDoc(doc(db, 'employees', editingEmployee.id), updatedEmp);

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'update_employee' as const,
        details: `تحديث بيانات الموظف: ${updatedEmp.name} (اسم المستخدم: ${updatedEmp.username})`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      setEditingEmployee(null);
      showToast('تم تحديث بيانات حساب الموظف بنجاح!', 'success');
    } catch (err) {
      console.error(err);
      showToast('خطأ في الاتصال بقاعدة البيانات', 'error');
    }
  };

  const toggleDisableEmployee = async (empId: string, currentStatus: boolean | undefined) => {
    if (empId === 'emp-1') {
      showToast('غير مسموح بتعطيل حساب المدير العام الرئيسي للوكالة!', 'error');
      return;
    }
    if (empId === currentEmployee?.id) {
      showToast('غير مسموح بتعطيل حسابك الشخصي الذي تستخدمه حالياً!', 'error');
      return;
    }

    try {
      const targetEmp = employees.find(e => e.id === empId);
      if (!targetEmp) return;

      const updatedEmp = {
        ...targetEmp,
        disabled: !currentStatus
      };

      await setDoc(doc(db, 'employees', empId), updatedEmp);

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'update_employee' as const,
        details: `${!currentStatus ? 'تعطيل' : 'تنشيط'} حساب الموظف: ${targetEmp.name}`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      showToast(!currentStatus ? 'تم تعطيل نشاط هذا الموظف بنجاح' : 'تم إعادة تنشيط الموظف بنجاح', 'success');
    } catch (err) {
      console.error(err);
      showToast('خطأ في تعديل حالة تفعيل الموظف بقاعدة البيانات', 'error');
    }
  };

  const handleAddBranchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchName.trim() || !newBranchLocation.trim()) {
      showToast('الرجاء كتابة اسم الفرع والموقع الجغرافي بالكامل', 'error');
      return;
    }

    try {
      const generatedId = `branch-${Date.now()}`;
      const newBranch: Branch = {
        id: generatedId,
        name: newBranchName.trim(),
        location: newBranchLocation.trim(),
      };

      await setDoc(doc(db, 'branches', generatedId), newBranch);

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'add_branch' as const,
        details: `تأسيس وإرساء الفرع الجديد: ${newBranch.name} في ${newBranch.location}`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      setNewBranchName('');
      setNewBranchLocation('');
      showToast(`تم تأسيس وإرساء الفرع بنجاح وتحصينه!`, 'success');
    } catch (err) {
      console.error(err);
      showToast('خطأ في تأسيس الفرع بقاعدة البيانات', 'error');
    }
  };

  // 1.5 GLOBAL AGENCY SETTINGS & THEMING & SECRET KEY LISTENER
  // Secret "ع" key listener effect (Press 5 times consecutively within 2s gaps)
  useEffect(() => {
    let count = 0;
    let lastPress = 0;
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is typing in inputs or textareas to avoid false triggers
      const activeEl = document.activeElement;
      if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.getAttribute('contenteditable') === 'true')) {
        return;
      }
      
      const isAin = e.key === 'ع' || e.key === 'u' || e.key === 'U';
      if (isAin) {
        const now = Date.now();
        if (now - lastPress < 2000) {
          count += 1;
        } else {
          count = 1;
        }
        lastPress = now;
        if (count === 5) {
          count = 0;
          setSecretPassword('');
          setSecretError('');
          setShowPasswordModal(true);
        }
      } else {
        count = 0;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Sync settings and apply dynamic Tailwind styles
  useEffect(() => {
    const root = document.documentElement;
    if (agencySettings?.primaryColor) {
      const primary = agencySettings.primaryColor;
      const hover = agencySettings.primaryColorHover || darkenColor(primary, 0.15);
      const light = agencySettings.primaryColorLight || adjustColorBrightness(primary, 0.65);
      const bg = agencySettings.primaryColorBg || adjustColorBrightness(primary, 0.85);
      const lightest = agencySettings.primaryColorLightest || adjustColorBrightness(primary, 0.95);

      root.style.setProperty('--color-amber-500', primary);
      root.style.setProperty('--color-amber-600', hover);
      root.style.setProperty('--color-amber-400', light);
      root.style.setProperty('--color-amber-100', bg);
      root.style.setProperty('--color-amber-50', lightest);
      
      root.style.setProperty('--color-amber-700', darkenColor(primary, 0.3));
      root.style.setProperty('--color-amber-800', darkenColor(primary, 0.45));
      root.style.setProperty('--color-amber-900', darkenColor(primary, 0.6));
      root.style.setProperty('--color-amber-950', darkenColor(primary, 0.75));
    }
  }, [agencySettings]);

  // Real-time Firestore Agency Settings Sync (Global, runs on mount)
  useEffect(() => {
    console.log('Registering real-time Firestore settings synchronizer...');
    const unsubscribeSettings = onSnapshot(doc(db, 'agencySettings', 'default'), (snap) => {
      if (snap.exists()) {
        const data = snap.data() as AgencySettings;
        setAgencySettings(data);
        localStorage.setItem('agencySettings', JSON.stringify(data));
        
        // Populate edit states
        if (data.websiteName) setEditWebsiteName(data.websiteName);
        if (data.websiteEnglishName) setEditWebsiteEnglishName(data.websiteEnglishName);
        if (data.primaryColor) setEditPrimaryColor(data.primaryColor);
        if (data.receiptLogoUrl) setEditReceiptLogoUrl(data.receiptLogoUrl);
        if (data.websiteLogoUrl) setEditWebsiteLogoUrl(data.websiteLogoUrl);

        // Notify other components
        window.dispatchEvent(new Event('agencySettingsChanged'));
      }
    }, (error) => {
      console.warn('Could not subscribe to online agency settings, using local storage cache:', error);
    });

    return () => {
      unsubscribeSettings();
    };
  }, []);

  // 2. LIVE CLOCK EFFECT & GLOBAL PRINT HEADERS/FOOTERS SUPPRESSION
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Globally hide webpage titles and default browser headers (URL, Website name, Date/Time) during print
  useEffect(() => {
    const originalTitle = document.title;
    const handleBeforePrint = () => {
      document.title = ''; // Setting document.title to empty suppresses the website title/name in Chrome/Firefox/Safari
    };
    const handleAfterPrint = () => {
      document.title = originalTitle || 'بوابة إدارة الفروع - وكالة عبعوب';
    };
    window.addEventListener('beforeprint', handleBeforePrint);
    window.addEventListener('afterprint', handleAfterPrint);
    return () => {
      window.removeEventListener('beforeprint', handleBeforePrint);
      window.removeEventListener('afterprint', handleAfterPrint);
    };
  }, []);

  // Helpers: Load dynamic datasets from backend with fail-safe local storage fallback
  const loadFromLocalStorageFallback = () => {
    try {
      const cachedCust = localStorage.getItem('aboub_customers');
      const cachedTrips = localStorage.getItem('aboub_trips');
      const cachedBranches = localStorage.getItem('aboub_branches');
      const cachedEmployees = localStorage.getItem('aboub_employees');
      const cachedLogs = localStorage.getItem('aboub_logs');

      if (cachedCust) setCustomers(JSON.parse(cachedCust));
      
      if (cachedTrips) {
        const parsed: Trip[] = JSON.parse(cachedTrips);
        // Sync any missing default itineraries
        const missingDefaults = defaultTrips.filter(
          dt => !parsed.some(pt => pt.id === dt.id)
        );
        if (missingDefaults.length > 0) {
          const merged = [...parsed, ...missingDefaults];
          setTrips(merged.filter(t => t.status !== 'deleted'));
          localStorage.setItem('aboub_trips', JSON.stringify(merged));
        } else {
          setTrips(parsed.filter(t => t.status !== 'deleted'));
        }
      } else {
        setTrips(defaultTrips.filter(t => t.status !== 'deleted'));
        localStorage.setItem('aboub_trips', JSON.stringify(defaultTrips));
      }

      if (cachedBranches) setBranches(JSON.parse(cachedBranches));
      if (cachedEmployees) setEmployees(JSON.parse(cachedEmployees));
      if (cachedLogs) setLogs(JSON.parse(cachedLogs));
    } catch (e) {
      console.error('Failed to load fallback localStorage data:', e);
    }
  };

  const fetchInitialData = async () => {
    try {
      const res = await fetch('/api/data');
      if (res.ok) {
        const result = await res.json();
        if (result.success && result.data) {
          setCustomers(result.data.customers || []);
          
          const fetchedTrips: Trip[] = result.data.trips || [];
          const missingDefaults = defaultTrips.filter(
            dt => !fetchedTrips.some(pt => pt.id === dt.id)
          );
          if (missingDefaults.length > 0) {
            const merged = [...fetchedTrips, ...missingDefaults];
            setTrips(merged.filter(t => t.status !== 'deleted'));
            localStorage.setItem('aboub_trips', JSON.stringify(merged));
          } else {
            setTrips(fetchedTrips.filter(t => t.status !== 'deleted'));
          }

          setBranches(result.data.branches || []);
          setEmployees(result.data.employees || []);
          setLogs(result.data.logs || []);
        }
      } else if (res.status === 401) {
        setCurrentEmployee(null);
      } else {
        loadFromLocalStorageFallback();
      }
    } catch (e) {
      console.error('Failed fetching server database, falling back to local cache:', e);
      loadFromLocalStorageFallback();
    }
  };

  const forceTriggerTripsSync = () => {
    try {
      const cached = localStorage.getItem('aboub_trips');
      let merged = [...defaultTrips];
      if (cached) {
        const parsed: Trip[] = JSON.parse(cached);
        const uniqueTrips = [...parsed];
        defaultTrips.forEach(dt => {
          const index = uniqueTrips.findIndex(ut => ut.id === dt.id);
          if (index !== -1) {
            uniqueTrips[index] = { ...uniqueTrips[index], ...dt };
          } else {
            uniqueTrips.push(dt);
          }
        });
        merged = uniqueTrips;
      }
      setTrips(merged);
      localStorage.setItem('aboub_trips', JSON.stringify(merged));
      showToast('تم تحديث ومزامنة جميع الرحلات السياحية (بما في ذلك رحلة شرم الشيخ صيف 2026 🇪🇬) ومسح الكاش المتقادم بنجاح!', 'success');
    } catch (e) {
      setTrips(defaultTrips);
      localStorage.setItem('aboub_trips', JSON.stringify(defaultTrips));
      showToast('تمت إعادة تهيئة الروزنامة وحل مشكلة الكاش بنجاح!', 'success');
    }
  };

  // Passive synchronization hooks to automatically persist application state
  useEffect(() => {
    if (customers.length > 0) {
      localStorage.setItem('aboub_customers', JSON.stringify(customers));
    }
  }, [customers]);

  useEffect(() => {
    if (trips.length > 0) {
      localStorage.setItem('aboub_trips', JSON.stringify(trips));
    }
  }, [trips]);

  useEffect(() => {
    if (branches.length > 0) {
      localStorage.setItem('aboub_branches', JSON.stringify(branches));
    }
  }, [branches]);

  useEffect(() => {
    if (employees.length > 0) {
      localStorage.setItem('aboub_employees', JSON.stringify(employees));
    }
  }, [employees]);

  useEffect(() => {
    if (logs.length > 0) {
      localStorage.setItem('aboub_logs', JSON.stringify(logs));
    }
  }, [logs]);

  useEffect(() => {
    if (receipts.length > 0) {
      localStorage.setItem('aboub_receipts', JSON.stringify(receipts));
    }
  }, [receipts]);

  useEffect(() => {
    if (currentEmployee) {
      localStorage.setItem('aboub_current_employee', JSON.stringify(currentEmployee));
    } else {
      localStorage.removeItem('aboub_current_employee');
    }
  }, [currentEmployee]);

  // 3. LOAD DATA & SESSION STATE FROM API (PROTECTED AUTO-RECOVERY ROUTE)
  useEffect(() => {
    const inspectSession = async () => {
      try {
        const res = await fetch('/api/auth/me');
        if (res.ok) {
          const result = await res.json();
          if (result.success && result.employee) {
            setCurrentEmployee(result.employee);
          }
        } else {
          // If the backend has failed (like on Vercel deployment), keep the default local admin active
          if (!currentEmployee) {
            setCurrentEmployee(DEFAULT_EMPLOYEES[0]);
          }
        }
      } catch (e) {
        console.error('Session recovery failed, maintaining default session:', e);
        if (!currentEmployee) {
          setCurrentEmployee(DEFAULT_EMPLOYEES[0]);
        }
      }
    };
    inspectSession();
  }, []);

  // Real-time Firestore Synchronization Hook (replaces old interval-based polling)
  useEffect(() => {
    if (!currentEmployee) return;

    console.log('Registering real-time Firestore synchronizers...');

    // 1. Listen to customers collection
    const unsubscribeCustomers = onSnapshot(collection(db, 'customers'), (snap) => {
      const list: Customer[] = [];
      snap.forEach(docSnap => {
        list.push(docSnap.data() as Customer);
      });
      setCustomers(list);
    }, (error) => {
      console.error('Error listening to customers:', error);
    });

    // 2. Listen to trips collection
    const unsubscribeTrips = onSnapshot(collection(db, 'trips'), (snap) => {
      const list: Trip[] = [];
      snap.forEach(docSnap => {
        list.push(docSnap.data() as Trip);
      });
      let merged: Trip[] = [];
      if (list.length > 0) {
        // Sync any missing default itineraries
        const missingDefaults = defaultTrips.filter(
          dt => !list.some(pt => pt.id === dt.id)
        );
        if (missingDefaults.length > 0) {
          merged = [...list, ...missingDefaults];
        } else {
          merged = list;
        }
      } else {
        merged = defaultTrips;
      }
      // Filter out 'deleted' trips so they don't appear in the application
      setTrips(merged.filter(t => t.status !== 'deleted'));
    }, (error) => {
      console.error('Error listening to trips:', error);
    });

    // 3. Listen to branches collection
    const unsubscribeBranches = onSnapshot(collection(db, 'branches'), (snap) => {
      const list: Branch[] = [];
      snap.forEach(docSnap => {
        list.push(docSnap.data() as Branch);
      });
      if (list.length > 0) {
        setBranches(list);
      } else {
        setBranches(DEFAULT_BRANCHES);
      }
    }, (error) => {
      console.error('Error listening to branches:', error);
    });

    // 4. Listen to employees collection
    const unsubscribeEmployees = onSnapshot(collection(db, 'employees'), (snap) => {
      const list: Employee[] = [];
      snap.forEach(docSnap => {
        list.push(docSnap.data() as Employee);
      });
      if (list.length > 0) {
        setEmployees(list);
      } else {
        setEmployees(DEFAULT_EMPLOYEES);
      }
    }, (error) => {
      console.error('Error listening to employees:', error);
    });

    // 5. Listen to logs collection (limit to latest 150)
    const logsQuery = query(collection(db, 'logs'), orderBy('timestamp', 'desc'));
    const unsubscribeLogs = onSnapshot(logsQuery, (snap) => {
      const list: OperationLog[] = [];
      snap.forEach(docSnap => {
        list.push(docSnap.data() as OperationLog);
      });
      setLogs(list.slice(0, 150));
    }, (error) => {
      console.error('Error listening to logs:', error);
    });

    // 6. Listen to receipts collection
    const unsubscribeReceipts = onSnapshot(collection(db, 'receipts'), (snap) => {
      const list: Receipt[] = [];
      snap.forEach(docSnap => {
        list.push(docSnap.data() as Receipt);
      });
      setReceipts(list);
    }, (error) => {
      console.error('Error listening to receipts:', error);
    });

    return () => {
      unsubscribeCustomers();
      unsubscribeTrips();
      unsubscribeBranches();
      unsubscribeEmployees();
      unsubscribeLogs();
      unsubscribeReceipts();
    };
  }, [currentEmployee]);

  // 4. WORKSPACE SESSION AUTHENTICATION
  const handleLogin = (employee: Employee) => {
    setCurrentEmployee(employee);
    setSelectedBranchFilter('all');
    setActiveTab('dashboard');
    showToast(`أهلاً بك مجدداً يا ${employee.name} في بوابة وكالة عبعوب!`, 'success');
  };

  const handleLogout = async () => {
    showToast('بوابة مفتوحة وخالية من حواجز الدخول.', 'info');
  };

  // 4.5 WRITE DATA TO LOCAL STORAGE ON STATE CHANGE
  // Automatically handled by the standard passive observer effects

  // 5. HELPER ACTION: TOAST MESSAGES
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // 5.8 DYNAMIC MULTI-BRANCH DATA SCOPING
  const scopedCustomers = useMemo(() => {
    if (!currentEmployee) return [];
    // Agents can now access customers across all branches (Removing sales censorship/restrictions)
    if (selectedBranchFilter && selectedBranchFilter !== 'all') {
      return customers.filter(c => c.branchId === selectedBranchFilter);
    }
    return customers;
  }, [customers, currentEmployee, selectedBranchFilter]);

  // 6. DASHBOARD CALCULATED METRICS
  const metrics = useMemo(() => {
    const activeCustomers = selectedTripFilter === 'all' 
      ? scopedCustomers 
      : scopedCustomers.filter(c => c.tripId === selectedTripFilter);

    const totalPassengers = activeCustomers.reduce((sum, c) => sum + (c.peopleCount || 1), 0);
    
    const totalRevenue = activeCustomers.reduce((sum, c) => {
      if (c.totalPrice !== undefined) {
        return sum + c.totalPrice;
      }
      const trip = trips.find(t => t.id === c.tripId);
      const tripPrice = trip ? trip.price : 0;
      return sum + (tripPrice * (c.peopleCount || 1));
    }, 0);

    const activeTripCount = trips.filter(t => t.status === 'active').length;

    return {
      totalBookingRecords: activeCustomers.length,
      totalPassengers,
      totalRevenue,
      activeTripCount
    };
  }, [scopedCustomers, trips, selectedTripFilter]);

  const tripProfitSummary = useMemo(() => {
    let passengersCount = 0;
    let totalSales = 0;
    let totalPaid = 0;
    let totalCost = 0;

    trips.forEach(t => {
      const tCusts = customers.filter(c => c.tripId === t.id);
      const passCount = tCusts.reduce((sum, c) => sum + (c.peopleCount || 0), 0);
      const sales = tCusts.reduce((sum, c) => {
        if (c.totalPrice !== undefined) return sum + c.totalPrice;
        return sum + (t.price * (c.peopleCount || 1));
      }, 0);
      const paid = tCusts.reduce((sum, c) => sum + (c.paidAmount || 0), 0);
      
      const acc = t.expenseAccommodation || 0;
      const trans = t.expenseTransport || 0;
      const guide = t.expenseGuide || 0;
      const ins = t.expenseInsurance || 0;
      const other = t.expenseOther || 0;
      const tripExpensesTotal = acc + trans + guide + ins + other;

      passengersCount += passCount;
      totalSales += sales;
      totalPaid += paid;
      totalCost += tripExpensesTotal;
    });

    return {
      passengersCount,
      totalSales,
      totalPaid,
      totalCost,
      netProfit: totalSales - totalCost
    };
  }, [trips, customers]);

  // 6.5 CORPORATE LOGGING HELPER
  const addLog = async (actionType: OperationLog['actionType'], details: string) => {
    // Audit logs are securely recorded on the server automatically.
    // This client-side helper is maintained for typings compatibility.
  };

  // 7. CORE EVENT: ADD MEMBER
  const handleAddCustomer = async (newCust: Omit<Customer, 'id' | 'registrationDate' | 'invoiceNumber'>) => {
    try {
      const generatedId = `customer-${Date.now()}`;
      const nextSeq = String(customers.length + 1).padStart(4, '0');
      const invoiceNumber = `AB-2026-${nextSeq}`;
      const completeCustomer: Customer = {
        ...newCust,
        id: generatedId,
        registrationDate: new Date().toISOString(),
        invoiceNumber: invoiceNumber,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchId: currentEmployee?.branchId || 'branch-touggourt',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
      } as Customer;

      // Write to Firestore in the cloud
      await setDoc(doc(db, 'customers', generatedId), completeCustomer);

      let tripName = 'غير معروفة';
      const trip = trips.find(t => t.id === newCust.tripId);
      if (trip) tripName = trip.name;

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'add_customer' as const,
        details: `تم تسجيل حجز جديد بنجاح للزبون: ${completeCustomer.firstName} ${completeCustomer.lastName} (رقم الحجز: ${invoiceNumber}) لرحلة "${tripName}"`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      showToast(`تم تسجيل الزبون ${newCust.firstName} ${newCust.lastName} بنجاح كحجز جديد!`, 'success');
    } catch (e) {
      console.error('Failed to register customer to Firestore:', e);
      showToast('فشل تسجيل حجز العميل الجديد في قاعدة البيانات', 'error');
    }
  };

  // 8. CORE EVENT: UPDATE MEMBER
  const handleUpdateCustomer = async (updatedCust: Customer) => {
    try {
      await setDoc(doc(db, 'customers', updatedCust.id), updatedCust);
      
      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'update_customer' as const,
        details: `تحديث بيانات حجز الزبون: ${updatedCust.firstName} ${updatedCust.lastName} (رقم الحجز: ${updatedCust.invoiceNumber})`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      showToast(`تم تعديل بيانات الزبون ${updatedCust.firstName} بنجاح وحفظها.`, 'success');
    } catch (e) {
      console.error('Failed to update customer in Firestore:', e);
      showToast('فشل تحديث بيانات العميل', 'error');
    }
  };

  // 9. CORE EVENT: DELETE MEMBER
  const handleDeleteCustomer = async (id: string) => {
    try {
      const customer = customers.find(c => c.id === id);
      if (!customer) {
        showToast('الزبون غير مسجل بالنظام', 'error');
        return;
      }
      await deleteDoc(doc(db, 'customers', id));

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'delete_customer' as const,
        details: `تم إلغاء وحذف حجز الزبون بالكامل: ${customer.firstName} ${customer.lastName} (رقم الحجز: ${customer.invoiceNumber})`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);

      showToast(`تم حذف حجز الزبون بنجاح من سجلات بوابة فروع وكالة عبعوب.`, 'info');
    } catch (e) {
      console.error('Failed to delete customer from Firestore:', e);
      showToast('فشل حذف قيد حجز العميل', 'error');
    }
  };

  // 9.5 RECEIPT VOUCHER EVENTS
  const handleSaveReceipt = async (receipt: Receipt) => {
    try {
      // Strip undefined properties for Firestore compatibility
      const cleanReceipt = JSON.parse(JSON.stringify(receipt));
      await setDoc(doc(db, 'receipts', receipt.id), cleanReceipt);

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'add_customer' as const,
        details: `قام بحفظ/تحديث وصل مالي رقم ${receipt.voucherNo} للزبون ${receipt.customerName} بقيمة ${receipt.amountPaid.toLocaleString()} دج (${receipt.voucherType === 'receipt' ? 'وصل استلام' : 'وصل دفع'})`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);
      showToast('تم حفظ ومزامنة المستند بنجاح في السجلات!', 'success');
    } catch (e) {
      console.error('Failed to save receipt in Firestore:', e);
      showToast('حدث خطأ أثناء حفظ المستند في السجلات', 'error');
      throw e;
    }
  };

  const handleDeleteReceipt = async (receiptId: string) => {
    try {
      const receiptToDelete = receipts.find(r => r.id === receiptId);
      if (!receiptToDelete) {
        showToast('المستند غير متوفر في السجلات', 'error');
        return;
      }
      await deleteDoc(doc(db, 'receipts', receiptId));

      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'delete_customer' as const,
        details: `قام بحذف الوصل المالي رقم ${receiptToDelete.voucherNo} للزبون ${receiptToDelete.customerName}`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);
      showToast('تمت إزالة المستند بنجاح من قاعدة البيانات.', 'success');
    } catch (e) {
      console.error('Failed to delete receipt from Firestore:', e);
      showToast('حدث خطأ أثناء حذف المستند من قاعدة البيانات', 'error');
      throw e;
    }
  };

  // 10. TOURISM PROGRAM EVENTS: ADD TOUR
  const [newTripData, setNewTripData] = useState<{
    name: string;
    destination: string;
    price: number;
    duration: string;
    date: string;
    dates: string[];
    departurePlaceNotes?: string;
    isProfessional?: boolean;
    priceSingle?: number;
    priceDouble?: number;
    priceTriple?: number;
    priceQuadruple?: number;
    priceQuintuple?: number;
    priceSextuple?: number;
    priceChild?: number;
    customPrices?: { id: string; label: string; price: number }[];
  }>({
    name: '',
    destination: '',
    price: 50000,
    duration: '8 أيام / 7 ليالٍ',
    date: '',
    dates: [],
    departurePlaceNotes: '',
    isProfessional: false,
    priceSingle: undefined,
    priceDouble: undefined,
    priceTriple: undefined,
    priceQuadruple: undefined,
    priceQuintuple: undefined,
    priceSextuple: undefined,
    priceChild: undefined,
    customPrices: [],
  });

  const [newTripDatesInput, setNewTripDatesInput] = useState('');
  const [editTripDatesInput, setEditTripDatesInput] = useState('');

  const handleAddNewTripDateState = () => {
    if (!newTripDatesInput) return;
    if (newTripData.dates.includes(newTripDatesInput) || newTripData.date === newTripDatesInput) {
      showToast('هذا التاريخ مضاف بالفعل كخيار انطلاق!', 'error');
      return;
    }
    setNewTripData({
      ...newTripData,
      dates: [...newTripData.dates, newTripDatesInput].sort(),
    });
    setNewTripDatesInput('');
  };

  const handleRemoveNewTripDateState = (dateToRemove: string) => {
    setNewTripData({
      ...newTripData,
      dates: newTripData.dates.filter((d) => d !== dateToRemove),
    });
  };

  const handleAddTrip = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTripData.name.trim() || !newTripData.destination.trim() || !newTripData.date) {
      showToast('الرجاء تعبئة كامل حقول الرحلة الجديدة', 'error');
      return;
    }

    try {
      const generatedId = `trip-${Date.now()}`;
      const createdTrip: Trip = {
        id: generatedId,
        name: newTripData.name,
        destination: newTripData.destination,
        price: Number(newTripData.price),
        duration: newTripData.duration,
        date: newTripData.date,
        dates: newTripData.dates || [],
        status: 'active',
        departurePlaceNotes: newTripData.departurePlaceNotes || '',
        isProfessional: !!newTripData.isProfessional,
        priceSingle: newTripData.priceSingle ? Number(newTripData.priceSingle) : undefined,
        priceDouble: newTripData.priceDouble ? Number(newTripData.priceDouble) : undefined,
        priceTriple: newTripData.priceTriple ? Number(newTripData.priceTriple) : undefined,
        priceQuadruple: newTripData.priceQuadruple ? Number(newTripData.priceQuadruple) : undefined,
        priceQuintuple: newTripData.priceQuintuple ? Number(newTripData.priceQuintuple) : undefined,
        priceSextuple: newTripData.priceSextuple ? Number(newTripData.priceSextuple) : undefined,
        priceChild: newTripData.priceChild ? Number(newTripData.priceChild) : undefined,
        customPrices: newTripData.customPrices || [],
      };

      await setDoc(doc(db, 'trips', generatedId), createdTrip);
      
      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'add_trip' as const,
        details: `إنشاء برنامج رحلة سياحية جديدة: "${createdTrip.name}" الموجهة إلى ${createdTrip.destination}`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);
      
      setNewTripData({
        name: '',
        destination: '',
        price: 50000,
        duration: '8 أيام / 7 ليالٍ',
        date: '',
        dates: [],
        departurePlaceNotes: '',
        isProfessional: false,
        priceSingle: undefined,
        priceDouble: undefined,
        priceTriple: undefined,
        priceQuadruple: undefined,
        priceQuintuple: undefined,
        priceSextuple: undefined,
        priceChild: undefined,
        customPrices: [],
      });
      showToast(`تمت إضافة برنامج رحلة سياحية جديدة بنجاح!`, 'success');
    } catch (err) {
      console.error('Failed to add trip:', err);
      showToast('فشل إضافة الرحلة في قاعدة البيانات', 'error');
    }
  };

  const handleDeleteTrip = async (tripId: string) => {
    const affectedCount = customers.filter(c => c.tripId === tripId).length;
    if (affectedCount > 0) {
      showToast(`عذراً! لا يمكن حذف هذه الرحلة لوجود ${affectedCount} زبون تم حجزهم عليها.`, 'error');
      return;
    }

    try {
      const targetTrip = trips.find(t => t.id === tripId);
      if (!targetTrip) {
        showToast('البرنامج السياحي غير متوفر', 'error');
        return;
      }
      
      // Soft-delete by setting status to 'deleted'
      const deletedTrip = { ...targetTrip, status: 'deleted' as const };
      await setDoc(doc(db, 'trips', tripId), deletedTrip);
      
      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'delete_trip' as const,
        details: `إزالة وإلغاء برنامج الرحلة السياحية: "${targetTrip.name}"`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);
      showToast('تمت إزالة برنامج الرحلة بنجاح.', 'success');
    } catch (err) {
      console.error('Failed to delete trip:', err);
      showToast('فشل حذف الرحلة من قاعدة البيانات', 'error');
    }
  };

  const handleUpdateTrip = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTrip) return;
    if (!editingTrip.name.trim() || !editingTrip.destination.trim() || !editingTrip.date) {
      showToast('الرجاء تعبئة كامل حقول البرنامج السياحي', 'error');
      return;
    }

    try {
      await setDoc(doc(db, 'trips', editingTrip.id), editingTrip);
      
      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'update_trip' as const,
        details: `تحديث بيانات برنامج الرحلة: "${editingTrip.name}"`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);
      setEditingTrip(null);
      showToast(`تم تعديل وتحديث بيانات برنامج الرحلة بنجاح!`, 'success');
    } catch (err) {
      console.error('Failed to update trip:', err);
      showToast('فشل تعديل بيانات هذه الرحلة في قاعدة البيانات', 'error');
    }
  };

  // 11. DATA MIGRATION: EXPORT / IMPORT DATABASE (FOR BACKUP COPIES)
  const downloadBackupJSON = () => {
    const databaseDump = {
      customers,
      trips,
      exportedAt: new Date().toISOString(),
      agency: 'Aboub Travel and Tourism Agency'
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(databaseDump, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `نسخة_احتياطية_وكالة_عبعوب_${new Date().toISOString().slice(0,10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('تم تحميل نسخة من السجلات الاحتياطية بنجاح.', 'success');
  };

  const triggerJSONFileInput = () => {
    document.getElementById('backup-file-uploader')?.click();
  };

  const handleUploadBackupJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const files = e.target.files;
    if (!files || files.length === 0) return;

    fileReader.onload = async (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed && Array.isArray(parsed.customers) && Array.isArray(parsed.trips)) {
          const res = await fetch('/api/backup/import', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ customers: parsed.customers, trips: parsed.trips }),
          });
          const data = await res.json();
          if (res.ok && data.success) {
            setCustomers(data.customers || []);
            setTrips(data.trips || []);
            if (data.logs) setLogs(data.logs);
            showToast(`تم استيراد نسخة السجلات الاحتياطية وتزامنها مع الخادم المركزي بنجاح!`, 'success');
          } else {
            showToast(data.error || 'فشل دمج البيانات بالمخدم', 'error');
          }
        } else {
          showToast('تنسيق ملف النسخة الاحتياطية غير متوافق.', 'error');
        }
      } catch (err) {
        showToast('فشل في قراءة واستيراد ملف السجلات وتزامنها.', 'error');
      }
    };
    if (files[0]) {
      fileReader.readAsText(files[0]);
    }
    // Clear value to allow upload again
    e.target.value = '';
  };

  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>, target: 'website' | 'receipt') => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // File size safety check (max 1.2MB)
    if (file.size > 1.2 * 1024 * 1024) {
      showToast('حجم الصورة كبير جداً! الرجاء استخدام صورة بحجم أقل من 1.2 ميجابايت لضمان الحفظ والمزامنة السريعة.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      if (target === 'website') {
        setEditWebsiteLogoUrl(base64);
      } else {
        setEditReceiptLogoUrl(base64);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveTripExpenses = async (
    tripId: string,
    expenseAccommodation: number,
    expenseTransport: number,
    expenseGuide: number,
    expenseInsurance: number,
    expenseOther: number
  ) => {
    try {
      const tripToUpdate = trips.find(t => t.id === tripId);
      if (!tripToUpdate) return;
      const updatedTrip: Trip = {
        ...tripToUpdate,
        expenseAccommodation,
        expenseTransport,
        expenseGuide,
        expenseInsurance,
        expenseOther
      };
      await setDoc(doc(db, 'trips', tripId), updatedTrip);
      
      // Update local state
      setTrips(prev => prev.map(t => t.id === tripId ? updatedTrip : t));

      // Log action
      const logId = `log-${Date.now()}`;
      const newLog = {
        id: logId,
        employeeId: currentEmployee?.id || 'emp-1',
        employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
        branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
        actionType: 'update_trip' as const,
        details: `تحديث مصاريف رحلة "${tripToUpdate.name}": إقامة ${expenseAccommodation.toLocaleString()} د.ج، نقل ${expenseTransport.toLocaleString()} د.ج، مرشد ${expenseGuide.toLocaleString()} د.ج، تأمين ${expenseInsurance.toLocaleString()} د.ج، أخرى ${expenseOther.toLocaleString()} د.ج`,
        timestamp: new Date().toISOString()
      };
      await setDoc(doc(db, 'logs', logId), newLog);
      showToast('تم حفظ تفاصيل مصاريف الرحلة وتحديث الأرباح بنجاح!', 'success');
    } catch (err) {
      console.error(err);
      showToast('فشل حفظ مصاريف الرحلة', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-stone-900 flex flex-col md:flex-row-reverse font-sans selection:bg-amber-100 selection:text-amber-900 print:bg-white print:text-black" dir="rtl">
      
      {/* DESKTOP FIXED SIDEBAR */}
      <aside className="w-80 bg-zinc-950 text-white sticky top-0 h-screen hidden md:flex flex-col justify-between p-6 print:hidden shrink-0 border-l border-amber-500/10 shadow-xl z-40">
        <div className="space-y-6">
          {/* Logo Heading - Premium & Modern Corporate Layout */}
          <div className="flex items-center gap-3.5">
            <button
              onClick={() => {
                setSecretPassword('');
                setSecretError('');
                setShowPasswordModal(true);
              }}
              title="لوحة التحكم السرية"
              className="focus:outline-none cursor-pointer transform hover:scale-110 hover:rotate-6 active:scale-95 transition-all duration-300 shrink-0"
            >
              {agencySettings.websiteLogoUrl ? (
                <img
                  src={agencySettings.websiteLogoUrl}
                  alt={agencySettings.websiteName || 'وكالة عبعوب للسياحة'}
                  className="w-11 h-11 rounded-2xl object-cover shadow-lg shadow-amber-500/10 select-none border border-amber-500/20"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 text-zinc-950 w-11 h-11 rounded-2xl flex items-center justify-center font-black text-lg shadow-lg shadow-amber-500/10 select-none">
                  ع
                </div>
              )}
            </button>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.55">
                <h1 className="font-sans font-black text-xs tracking-tight select-none leading-none bg-gradient-to-l from-white to-stone-200 bg-clip-text text-transparent">
                  {agencySettings.websiteName || 'وكالة عبعوب للسياحة'}
                </h1>
                <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[8px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider scale-90">
                  PORTAL
                </span>
              </div>
              <span className="font-mono text-[8px] text-stone-400 font-bold tracking-wider select-none mt-1 opacity-80 uppercase leading-none">
                {agencySettings.websiteEnglishName || 'ABOUB TRAVEL AGENCY'}
              </span>
            </div>
          </div>

          <div className="border-t border-zinc-800/80 my-1"></div>

          {/* Navigation Links with generous hover and active states */}
          <nav className="space-y-1.5">
            <button
              onClick={() => setActiveTab('dashboard')}
              id="sidebar-btn-dashboard"
              className={`w-full py-3 px-3.5 rounded-xl transition-all font-bold text-xs cursor-pointer flex items-center justify-start gap-3.5 ${
                activeTab === 'dashboard'
                  ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/15 font-black'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900/60'
              }`}
            >
              <LayoutDashboard size={14} className="shrink-0" />
              <span>تسجيل وعرض الحجوزات</span>
            </button>

            <button
              onClick={() => setActiveTab('manifests')}
              id="sidebar-btn-manifests"
              className={`w-full py-3 px-3.5 rounded-xl transition-all font-bold text-xs cursor-pointer flex items-center justify-start gap-3.5 ${
                activeTab === 'manifests'
                  ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/15 font-black'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900/60'
              }`}
            >
              <Users size={14} className="shrink-0" />
              <span>دليل قوائم المسافرين</span>
            </button>

            <button
              onClick={() => setActiveTab('trips')}
              id="sidebar-btn-trips"
              className={`w-full py-3 px-3.5 rounded-xl transition-all font-bold text-xs cursor-pointer flex items-center justify-start gap-3.5 ${
                activeTab === 'trips'
                  ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/15 font-black'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900/60'
              }`}
            >
              <Compass size={14} className="shrink-0" />
              <span>برامج الرحلات والمواسم</span>
            </button>

            <button
              onClick={() => setActiveTab('receipt')}
              id="sidebar-btn-receipt"
              className={`w-full py-3 px-3.5 rounded-xl transition-all font-bold text-xs cursor-pointer flex items-center justify-start gap-3.5 ${
                activeTab === 'receipt'
                  ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/15 font-black'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900/60'
              }`}
            >
              <ReceiptIcon size={14} className="shrink-0" />
              <span>وصل استلام (مستند)</span>
            </button>

            <button
              onClick={() => setActiveTab('options')}
              id="sidebar-btn-options"
              className={`w-full py-3 px-3.5 rounded-xl transition-all font-bold text-xs cursor-pointer flex items-center justify-start gap-3.5 ${
                activeTab === 'options'
                  ? 'bg-amber-500 text-zinc-950 shadow-lg shadow-amber-500/15 font-black'
                  : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900/60'
              }`}
            >
              <Database size={14} className="shrink-0" />
              <span>النسخ الاحتياطي والضبط</span>
            </button>
          </nav>
        </div>

        {/* Sidebar Footer Info */}
        <div className="space-y-4 pt-4 mt-auto border-t border-zinc-900/80 text-right">
          <div className="flex items-center gap-2.5 bg-zinc-900/60 border border-zinc-900 rounded-xl px-3 py-2 select-none justify-center">
            <Clock size={13} className="text-amber-400 shrink-0 animate-spin-slow" />
            <span className="font-mono text-[10px] text-stone-300 font-bold tracking-wider">
              {currentTime.toLocaleTimeString('ar-DZ')}
            </span>
          </div>
          <div className="text-[10px] text-stone-500 leading-normal space-y-1 font-sans">
            <div>📍 حي عياد تبسبست، تقرت</div>
            <div>📞 الهاتف: 0667910148 / 0696789633</div>
          </div>
        </div>
      </aside>

      {/* MOBILE RESPONSIVE TOP HEADER */}
      <header className="bg-zinc-950 text-white sticky top-0 z-40 shadow-md border-b border-amber-500/20 print:hidden flex flex-col md:hidden">
        <div className="px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setSecretPassword('');
                setSecretError('');
                setShowPasswordModal(true);
              }}
              title="لوحة التحكم السرية"
              className="focus:outline-none cursor-pointer transform hover:scale-110 hover:rotate-6 active:scale-95 transition-all duration-300 shrink-0"
            >
              {agencySettings.websiteLogoUrl ? (
                <img
                  src={agencySettings.websiteLogoUrl}
                  alt={agencySettings.websiteName || 'وكالة عبعوب للسياحة'}
                  className="w-9 h-9 rounded-lg object-cover shadow-md select-none"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="bg-gradient-to-br from-amber-400 to-amber-600 text-zinc-950 w-9 h-9 rounded-lg flex items-center justify-center font-black text-md shadow-md">
                  ع
                </div>
              )}
            </button>
            <div className="flex flex-col text-right">
              <h1 className="font-sans font-black text-xs leading-none">{agencySettings.websiteName || 'وكالة عبعوب للسياحة'}</h1>
              <span className="font-mono text-[7.5px] text-stone-400 font-bold uppercase tracking-wide mt-1">{agencySettings.websiteEnglishName || 'ABOUB TRAVEL'}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5 bg-zinc-900 px-2 py-1 rounded-lg border border-zinc-800 text-[10px] font-mono font-bold text-amber-400">
            {currentTime.toLocaleTimeString('ar-DZ', { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>

        {/* Mobile Navigation tab bar with modern horizontal swiper feel */}
        <div className="border-t border-zinc-900 px-2 py-1.5 bg-zinc-900/50 flex items-center justify-around gap-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('dashboard')}
            id="mobile-tab-dashboard"
            className={`flex-1 py-1.5 px-1.5 rounded-lg text-[9.5px] font-bold flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all ${
              activeTab === 'dashboard' ? 'bg-amber-500 text-zinc-950 font-black shadow-xs' : 'text-stone-400 font-medium'
            }`}
          >
            <LayoutDashboard size={11} />
            <span>الحجوزات</span>
          </button>
          <button
            onClick={() => setActiveTab('manifests')}
            id="mobile-tab-manifests"
            className={`flex-1 py-1.5 px-1.5 rounded-lg text-[9.5px] font-bold flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all ${
              activeTab === 'manifests' ? 'bg-amber-500 text-zinc-950 font-black shadow-xs' : 'text-stone-400 font-medium'
            }`}
          >
            <Users size={11} />
            <span>الكشوفات</span>
          </button>
          <button
            onClick={() => setActiveTab('trips')}
            id="mobile-tab-trips"
            className={`flex-1 py-1.5 px-1.5 rounded-lg text-[9.5px] font-bold flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all ${
              activeTab === 'trips' ? 'bg-amber-500 text-zinc-950 font-black shadow-xs' : 'text-stone-450 font-medium'
            }`}
          >
            <Compass size={11} />
            <span>الرحلات</span>
          </button>
          <button
            onClick={() => setActiveTab('receipt')}
            id="mobile-tab-receipt"
            className={`flex-1 py-1.5 px-1.5 rounded-lg text-[9.5px] font-bold flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all ${
              activeTab === 'receipt' ? 'bg-amber-500 text-zinc-950 font-black shadow-xs' : 'text-stone-400 font-medium'
            }`}
          >
            <ReceiptIcon size={11} />
            <span>وصل استلام</span>
          </button>
          <button
            onClick={() => setActiveTab('options')}
            id="mobile-tab-options"
            className={`flex-1 py-1.5 px-1.5 rounded-lg text-[9.5px] font-bold flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-all ${
              activeTab === 'options' ? 'bg-amber-500 text-zinc-950 font-black shadow-xs' : 'text-stone-400 font-medium'
            }`}
          >
            <Database size={11} />
            <span>الضبط</span>
          </button>
        </div>
      </header>

      {/* CONTENT WORKSPACE WRAPPER */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* DESKTOP STICKY SUB-HEADER TOP BAR - Super clean, high contrast design */}
        <header className="bg-white border-b border-stone-200/65 py-4 px-8 sticky top-0 z-30 justify-between items-center hidden md:flex print:hidden">
          <div className="space-y-0.5 text-right">
            <h2 className="font-sans font-black text-zinc-900 text-[15px] tracking-tight leading-none">
              {activeTab === 'dashboard' && 'لوحة تحكم كشوف الحجوزات والزبائن الفورية'}
              {activeTab === 'manifests' && 'دليل قوائم الركاب ومسافري كشف النقل'}
              {activeTab === 'trips' && 'إدارة البرامج والمواسم السياحية للوكالة'}
              {activeTab === 'receipt' && 'تحرير وطباعة وصولات الاستلام الرسمية'}
              {activeTab === 'options' && 'نظام النسخ الاحتياطي ومزامنة البيانات'}
            </h2>
            <p className="text-[10px] text-stone-500 font-sans mt-1">
              {activeTab === 'dashboard' && 'تابع الحسابات المالية لملفات العائلات والزبائن مع تصفية مجدولة'}
              {activeTab === 'manifests' && 'توليد قوائم المسافرين الرسمية لجهات النقل والبلدية لولاية تقرت'}
              {activeTab === 'trips' && 'أضف، حدّث أو امسح البرامج السياحية الفعالة أو القادمة للزبائن'}
              {activeTab === 'receipt' && 'املأ تفاصيل مبالغ زبائنك، قم بالتفقيط الآلي واطبع وصل الاستلام بجودة عالية'}
              {activeTab === 'options' && 'أرسل أو استرجع قاعدة بيانات الحجوزات في جهاز المكتب بخصوصية مطلقة'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-stone-50 rounded-lg border border-stone-200/60 font-sans text-[11px] text-stone-500 font-semibold select-none leading-none">
              <span>تاريخ التقرير اليومي:</span>
              <span className="font-mono text-stone-850 font-bold">{new Date().toLocaleDateString('ar-DZ')}</span>
            </div>
          </div>
        </header>

        {/* 3. DYNAMIC APP ALERTS (TOAST) */}
        {toast && (
          <div className="fixed bottom-6 left-6 z-50 max-w-sm w-full animate-in slide-in-from-bottom-5 duration-200">
            <div className={`p-4 rounded-xl border shadow-xl flex items-start gap-4 text-right font-sans translate-x-0 ${
              toast.type === 'success' 
                ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
                : toast.type === 'error' 
                ? 'bg-rose-50 border-rose-100 text-rose-800' 
                : 'bg-indigo-50 border-indigo-100 text-indigo-800'
            }`}>
              <div className="shrink-0 mt-0.5">
                {toast.type === 'success' ? (
                  <CheckCircle2 size={18} className="text-emerald-500" id="toast-success-icon" />
                ) : (
                  <AlertCircle size={18} className="text-rose-500" id="toast-danger-icon" />
                )}
              </div>
              <div className="space-y-1">
                <span className="font-bold text-xs block">تنبيه النظام</span>
                <p className="text-xs font-semibold mt-1 leading-relaxed">{toast.message}</p>
              </div>
            </div>
          </div>
        )}

        {/* 4. MAIN ACTION WORKSPACE */}
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        
        {/* TAB CONTENTS */}
        <div className={`tab-container ${(activeTab === 'manifests' || activeTab === 'receipt') ? '' : 'print:hidden'}`}>
          
          {/* TAB 1: CUSTOMERS & RESERVATIONS DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="flex flex-col gap-6 w-full items-stretch">
              
              {/* Top Row: Customer Registration Form */}
              <div className="w-full">
                <CustomerForm trips={trips} onAddCustomer={handleAddCustomer} />
              </div>

              {/* Bottom Row: Customers Table Directory */}
              <div className="w-full">
                <CustomerTable
                  customers={scopedCustomers}
                  trips={trips}
                  onDeleteCustomer={handleDeleteCustomer}
                  onUpdateCustomer={handleUpdateCustomer}
                  onPrintCustomer={(customer) => setSelectedPrintCustomer(customer)}
                />
              </div>

            </div>
          )}

          {/* TAB 1.5: TRIP PASSENGER MANIFESTS */}
          {activeTab === 'manifests' && (
            <TripManifests customers={scopedCustomers} trips={trips} />
          )}

          {/* TAB 2: VOYAGE PROGRAMS EDITOR AND LISTS */}
          {activeTab === 'trips' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start animate-in fade-in duration-200">
              
              {/* Add New Voyage form (4 / 12 spans) */}
              <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex items-center gap-3 border-b border-slate-100 pb-3 mb-4">
                  <div className="p-2.5 bg-blue-50 text-blue-600 rounded-lg">
                    <Plus size={18} id="icon-add-trip-bar" />
                  </div>
                  <div>
                    <h3 className="font-sans font-bold text-slate-800 text-sm">إضافة برنامج سفر جديد</h3>
                    <p className="text-[10px] text-slate-400 font-sans mt-0.5">أدرج رحلة طيران أو عمرة جديدة لبرامج الوكالة المتاحة</p>
                  </div>
                </div>

                <form onSubmit={handleAddTrip} className="space-y-4 font-sans text-right text-xs">
                  <div>
                    <label htmlFor="trip-name" className="block font-bold text-slate-600 mb-1">اسم الرحلة / البرنامج</label>
                    <input
                      type="text"
                      id="trip-name"
                      placeholder="مثال: رحلة سياحية إلى أنطاليا التركية"
                      value={newTripData.name}
                      onChange={(e) => setNewTripData({ ...newTripData, name: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium"
                      required
                    />
                  </div>

                  <div>
                    <label htmlFor="trip-destination" className="block font-bold text-slate-600 mb-1">الوجهة (المدينة والبلد)</label>
                    <input
                      type="text"
                      id="trip-destination"
                      placeholder="مثال: تركيا"
                      value={newTripData.destination}
                      onChange={(e) => setNewTripData({ ...newTripData, destination: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 mt-1">
                    <div>
                      <label htmlFor="trip-price" className="block font-bold text-slate-600 mb-1">سعر المقعد بالدينار (DZD)</label>
                      <input
                        type="number"
                        id="trip-price"
                        value={newTripData.price}
                        onChange={(e) => setNewTripData({ ...newTripData, price: parseInt(e.target.value) || 0 })}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium"
                        required
                      />
                    </div>
                    <div>
                      <label htmlFor="trip-main-date" className="block font-bold text-slate-600 mb-1">تاريخ الانطلاق الرئيسي</label>
                      <input
                        type="date"
                        id="trip-main-date"
                        value={newTripData.date}
                        onChange={(e) => setNewTripData({ ...newTripData, date: e.target.value })}
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium"
                        required
                      />
                    </div>
                  </div>

                  {/* Trip Type Selector for ADD (Standard / Normal vs Professional) */}
                  <div className="space-y-1.5 font-sans text-right">
                    <span className="block text-[10px] font-bold text-stone-600">تصنيف وتسعير برنامج الرحلة</span>
                    <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200/50">
                      <button
                        type="button"
                        onClick={() => setNewTripData({ ...newTripData, isProfessional: false })}
                        className={`py-1.5 px-3 rounded-lg text-center font-bold text-[10px] transition-all cursor-pointer ${
                          !newTripData.isProfessional
                            ? 'bg-white text-slate-800 shadow-xs border border-slate-250 font-extrabold'
                            : 'text-slate-550 hover:text-slate-850 hover:bg-slate-50'
                        }`}
                      >
                        ✈️ رحلة عادية (سعر موحد ومباشر)
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewTripData({ ...newTripData, isProfessional: true })}
                        className={`py-1.5 px-3 rounded-lg text-center font-bold text-[10px] transition-all cursor-pointer ${
                          newTripData.isProfessional
                            ? 'bg-blue-600 text-white shadow-xs font-extrabold'
                            : 'text-slate-550 hover:text-slate-850 hover:bg-slate-50'
                        }`}
                      >
                        ⭐ رحلة احترافية (أسعار غرف مفصلة)
                      </button>
                    </div>
                  </div>

                  {/* Detailed Prices Section (Algerian Accommodation Style) - Visible for All Trips (Optional) */}
                  {newTripData.isProfessional && (
                    <div className="bg-blue-50/45 p-3 rounded-lg border border-blue-100 space-y-2 mt-2 font-sans text-right animate-in fade-in duration-150">
                      <h4 className="font-extrabold text-[11px] text-blue-900 border-b border-blue-100 pb-1 mb-1.5 flex items-center gap-1">
                        <span>🏷️ تفاصيل الأسعار حسب نوع الغرفة والمقعد والأطفال (اختياري)</span>
                      </h4>
                      <p className="text-[9px] text-slate-500 leading-normal mb-1">
                        تعبئة هذه الحقول تفعل تلقائياً خيارات الغرف المفصلة للمسافرين في استمارة التسجيل والعروض.
                      </p>
                      <div className="grid grid-cols-2 gap-2 text-[10px]">
                        <div>
                          <label htmlFor="trip-price-single" className="block font-bold text-slate-600 mb-0.5">غرفة فردية Single</label>
                          <input
                            type="number"
                            id="trip-price-single"
                            placeholder="مثال: 75000"
                            value={newTripData.priceSingle || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceSingle: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                        <div>
                          <label htmlFor="trip-price-double" className="block font-bold text-slate-600 mb-0.5">غرفة ثنائية Double</label>
                          <input
                            type="number"
                            id="trip-price-double"
                            placeholder="مثال: 55000"
                            value={newTripData.priceDouble || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceDouble: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                        <div>
                          <label htmlFor="trip-price-triple" className="block font-bold text-slate-600 mb-0.5">غرفة ثلاثية Triple</label>
                          <input
                            type="number"
                            id="trip-price-triple"
                            placeholder="مثال: 48000"
                            value={newTripData.priceTriple || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceTriple: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                        <div>
                          <label htmlFor="trip-price-quadruple" className="block font-bold text-slate-600 mb-0.5">غرفة رباعية Quadruple</label>
                          <input
                            type="number"
                            id="trip-price-quadruple"
                            placeholder="مثال: 42000"
                            value={newTripData.priceQuadruple || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceQuadruple: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                        <div>
                          <label htmlFor="trip-price-quintuple" className="block font-bold text-slate-600 mb-0.5">غرفة خماسية Quintuple</label>
                          <input
                            type="number"
                            id="trip-price-quintuple"
                            placeholder="مثال: 38000"
                            value={newTripData.priceQuintuple || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceQuintuple: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                        <div>
                          <label htmlFor="trip-price-sextuple" className="block font-bold text-slate-600 mb-0.5">غرفة سداسية Sextuple</label>
                          <input
                            type="number"
                            id="trip-price-sextuple"
                            placeholder="مثال: 35000"
                            value={newTripData.priceSextuple || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceSextuple: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                        <div className="col-span-2">
                          <label htmlFor="trip-price-child" className="block font-bold text-slate-600 mb-0.5">سعر الأطفال Child</label>
                          <input
                            type="number"
                            id="trip-price-child"
                            placeholder="مثال: 32000"
                            value={newTripData.priceChild || ''}
                            onChange={(e) => {
                              const val = parseInt(e.target.value) || undefined;
                              setNewTripData({ ...newTripData, priceChild: val });
                            }}
                            className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                          />
                        </div>
                      </div>

                      {/* Custom Price Fields Section */}
                      {newTripData.customPrices && newTripData.customPrices.length > 0 && (
                        <div className="space-y-2 mt-3 pt-3 border-t border-blue-100 text-right">
                          <span className="block text-[10px] text-blue-900 font-extrabold">📋 الأسعار الإضافية المخصصة:</span>
                          <div className="space-y-1.5">
                            {newTripData.customPrices.map((cp, idx) => (
                              <div key={cp.id} className="flex gap-1.5 items-center bg-white/70 p-1.5 rounded-lg border border-slate-200">
                                <div className="flex-1">
                                  <input
                                    type="text"
                                    value={cp.label}
                                    onChange={(e) => {
                                      const updated = [...(newTripData.customPrices || [])];
                                      updated[idx].label = e.target.value;
                                      setNewTripData({ ...newTripData, customPrices: updated });
                                    }}
                                    placeholder="اسم التسعيرة (مثال: غرفة مطلة على البحر)"
                                    className="w-full px-2 py-1 border border-slate-200 rounded text-[11px] text-stone-800 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                                    required
                                  />
                                </div>
                                <div className="w-24">
                                  <input
                                    type="number"
                                    value={cp.price || ''}
                                    onChange={(e) => {
                                      const updated = [...(newTripData.customPrices || [])];
                                      updated[idx].price = parseInt(e.target.value) || 0;
                                      setNewTripData({ ...newTripData, customPrices: updated });
                                    }}
                                    placeholder="السعر دج"
                                    className="w-full px-2 py-1 border border-slate-200 rounded text-[11px] text-stone-850 bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                                    required
                                  />
                                </div>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setNewTripData({
                                      ...newTripData,
                                      customPrices: (newTripData.customPrices || []).filter((_, i) => i !== idx)
                                    });
                                  }}
                                  className="p-1 text-red-500 hover:bg-red-50 rounded text-xs cursor-pointer flex items-center justify-center border border-red-100"
                                  title="حذف"
                                >
                                  ❌
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Add Custom Price Button */}
                      <div className="mt-2 text-right">
                        <button
                          type="button"
                          onClick={() => {
                            const newCustom = {
                              id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                              label: '',
                              price: 0
                            };
                            setNewTripData({
                              ...newTripData,
                              customPrices: [...(newTripData.customPrices || []), newCustom]
                            });
                          }}
                          className="w-full py-1.5 bg-blue-100/60 hover:bg-blue-200/60 text-blue-800 text-[10px] font-bold rounded-lg border border-dashed border-blue-300 transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          ➕ إضافة خانة تسعيرة مخصصة إضافية جديدة (أي عنوان وسعر)
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Departure/Itinerary info details */}
                  <div className="font-sans text-right">
                    <label htmlFor="trip-departure-notes" className="block font-bold text-slate-600 mb-1">تفاصيل وملاحظات خط سير الرحلة ونقاط المغادرة</label>
                    <textarea
                      id="trip-departure-notes"
                      placeholder="مثال: الانطلاق عبر الحافلة من تقرت بساحة الشهداء، مع توفير خط تجمع في بسكرة والجزائر..."
                      value={newTripData.departurePlaceNotes || ''}
                      onChange={(e) => setNewTripData({ ...newTripData, departurePlaceNotes: e.target.value })}
                      rows={2}
                      className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium font-sans leading-relaxed text-right text-stone-800"
                    />
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60 mt-1">
                    <label className="block font-bold text-slate-700 mb-1 text-[11px] flex items-center justify-between">
                      <span>📆 تواريخ انطلاق إضافية أخرى</span>
                      <span className="text-[10px] text-slate-400 font-normal">اختياري</span>
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="date"
                        value={newTripDatesInput}
                        onChange={(e) => setNewTripDatesInput(e.target.value)}
                        className="flex-1 px-2.5 py-1.5 border border-slate-200 bg-white rounded-lg text-xs font-medium font-sans"
                      />
                      <button
                        type="button"
                        onClick={handleAddNewTripDateState}
                        className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 font-bold rounded-lg border border-blue-200 transition-colors text-xs shrink-0 cursor-pointer"
                      >
                        إضافة تاريخ
                      </button>
                    </div>

                    {newTripData.dates && newTripData.dates.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2.5 pt-2 border-t border-slate-200/50 font-sans">
                        {newTripData.dates.map((d, index) => (
                          <div key={index} className="inline-flex items-center gap-1 bg-white border border-slate-200 text-slate-700 px-1.5 py-0.5 rounded text-[10px] font-bold font-mono">
                            <span>{d}</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveNewTripDateState(d)}
                              className="text-red-500 hover:text-red-700 text-[10px] px-0.5 font-bold"
                            >
                              ×
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <button
                    type="submit"
                    id="btn-confirm-trip-add"
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors cursor-pointer text-center text-xs shadow-sm hover:shadow"
                  >
                    أضف البرنامج لقائمة الحجوزات
                  </button>
                </form>
              </div>

              {/* Programs and Active Tours list (8 / 12 spans) */}
              <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                  <div>
                    <h3 className="font-sans font-bold text-slate-800 text-base mb-1">برامج الرحلات والبرامج السياحية للوكالة</h3>
                    <p className="text-xs text-slate-400 font-sans">إدارة وحجز رحلات الطيران، العمرة، والبرامج السياحية المختلفة للوكالة:</p>
                  </div>
                </div>

                {/* Trip Status Filter Tabs */}
                <div className="flex flex-wrap gap-1.5 mb-5 bg-slate-100 p-1 rounded-xl border border-slate-200/50 font-sans">
                  <button
                    type="button"
                    onClick={() => setTripStatusFilter('all')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-[10px] transition-all cursor-pointer ${
                      tripStatusFilter === 'all'
                        ? 'bg-white text-slate-800 shadow-xs border border-slate-200'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    عرض الكل ({trips.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTripStatusFilter('active')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-[10px] transition-all cursor-pointer ${
                      tripStatusFilter === 'active'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-emerald-600 hover:bg-emerald-50/50'
                    }`}
                  >
                    نشطة حالياً ({trips.filter(t => t.status === 'active').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTripStatusFilter('upcoming')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-[10px] transition-all cursor-pointer ${
                      tripStatusFilter === 'upcoming'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-blue-600 hover:bg-blue-50/50'
                    }`}
                  >
                    قادمة قريباً ({trips.filter(t => t.status === 'upcoming').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTripStatusFilter('suspended')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-[10px] transition-all cursor-pointer ${
                      tripStatusFilter === 'suspended'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-rose-600 hover:bg-rose-50/50'
                    }`}
                  >
                    معلّقة ({trips.filter(t => t.status === 'suspended').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTripStatusFilter('completed')}
                    className={`px-3 py-1.5 rounded-lg font-bold text-[10px] transition-all cursor-pointer ${
                      tripStatusFilter === 'completed'
                        ? 'bg-stone-600 text-white shadow-xs'
                        : 'text-stone-500 hover:bg-stone-200/50'
                    }`}
                  >
                    مكتملة / منتهية ({trips.filter(t => t.status === 'completed').length})
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {trips
                    .filter((tour) => tripStatusFilter === 'all' || tour.status === tripStatusFilter)
                    .map((tour) => {
                      const bookedClientsCount = customers.filter(c => c.tripId === tour.id).length;
                      return (
                        <div key={tour.id} className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 flex flex-col justify-between hover:bg-slate-50 transition-colors">
                          <div>
                            <div className="flex justify-between items-start gap-2">
                              <span className="text-[10px] font-bold text-slate-500 bg-white border border-slate-200 rounded px-2 py-0.5 font-mono">
                                {tour.duration}
                              </span>
                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                tour.status === 'active'
                                  ? 'bg-emerald-50 text-emerald-600'
                                  : tour.status === 'upcoming'
                                  ? 'bg-blue-50 text-blue-600'
                                  : tour.status === 'suspended'
                                  ? 'bg-rose-50 text-rose-600 border border-rose-100'
                                  : 'bg-stone-100 text-stone-600'
                              }`}>
                                {tour.status === 'active'
                                  ? 'فعّالة حالياً'
                                  : tour.status === 'upcoming'
                                  ? 'قادمة قريباً'
                                  : tour.status === 'suspended'
                                  ? 'معلّقة مؤقتاً'
                                  : 'مكتملة / منتهية'}
                              </span>
                            </div>

                          <h4 className="font-sans font-bold text-slate-800 text-sm mt-3 leading-snug">
                            {tour.name}
                          </h4>

                          <div className="mt-3 space-y-1 text-slate-500 text-xs font-sans">
                            <div>الوجهة والبلد: <span className="font-semibold text-slate-800">{tour.destination}</span></div>
                            <div className="flex flex-col gap-0.5">
                              <span>تاريخ المغادرة المتوقع:</span>
                              {tour.dates && tour.dates.length > 0 ? (
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {Array.from(new Set([tour.date, ...tour.dates])).filter(Boolean).map((d, index) => (
                                    <span key={index} className="bg-slate-100 text-slate-700 font-bold font-mono px-1.5 py-0.5 rounded text-[9px] border border-slate-200">
                                      {d}
                                    </span>
                                  ))}
                                </div>
                              ) : (
                                <span className="font-semibold text-slate-800 font-mono">{tour.date}</span>
                              )}
                            </div>
                            <div>حجوزات نشطة حالياً: <span className="font-bold text-blue-600 px-1">{bookedClientsCount} مسافرين</span></div>
                          </div>

                          {/* Rich metadata display of prices and departure details */}
                          {(tour.departurePlaceNotes || true) && (() => {
                            const opts = getRoomOptionsForTrip(tour.id, tour.price, tour);
                            if (!tour.departurePlaceNotes && opts.length === 0) return null;
                            return (
                              <div className="mt-3 pt-3 border-t border-slate-200/50 space-y-2 text-[10px] text-slate-550 font-sans text-right">
                                {tour.departurePlaceNotes && (
                                  <div className="bg-slate-100 p-2 rounded text-[10px] text-slate-700 leading-relaxed">
                                    <strong className="text-slate-900 block mb-0.5">📌 مسار ونقاط الانطلاق:</strong>
                                    <p className="whitespace-pre-line">{tour.departurePlaceNotes}</p>
                                  </div>
                                )}
                                
                                {opts.length > 0 && tour.isProfessional && (
                                  <div className="bg-blue-50/50 p-2.5 rounded-xl border border-blue-100 text-blue-950 font-sans">
                                    <strong className="text-blue-900 block mb-1 text-[11px] font-extrabold">🏷️ تفاصيل أسعار الإقامة والغرف والخدمات المتاحة:</strong>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 text-[10px] mt-1.5">
                                      {opts.map((opt, i) => (
                                        <div key={i} className="flex justify-between items-center bg-white/55 px-2 py-1.5 rounded-lg border border-blue-100/40">
                                          <span className="font-semibold text-slate-700">{opt.label.split(' (')[0]}</span>
                                          <span className="font-extrabold text-blue-950 font-mono">
                                            {opt.price === 0 ? 'مجاناً' : `${opt.price.toLocaleString('ar-DZ')} دج`}
                                          </span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })()}
                        </div>

                        <div className="flex items-center justify-between mt-4 border-t border-slate-100 pt-3">
                          <span className="text-blue-600 font-bold font-mono text-sm">
                            {tour.price.toLocaleString('ar-DZ')} د.ج
                          </span>
                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => {
                                const defaultTripObj = defaultTrips.find(dt => dt.id === tour.id);
                                const enrichedTrip = {
                                  ...defaultTripObj,
                                  ...tour,
                                };
                                setEditingTrip(enrichedTrip);
                              }}
                              id={`btn-trip-edit-${tour.id}`}
                              className="text-slate-600 p-1.5 bg-white border border-slate-200 rounded-lg hover:border-amber-500 hover:text-amber-600 transition-colors cursor-pointer flex items-center justify-center"
                              title="تعديل تفاصيل البرنامج السياحي"
                            >
                              <Edit2 size={13} id={`icon-edit-trip-${tour.id}`} />
                            </button>
                            <button
                              onClick={() => handleDeleteTrip(tour.id)}
                              id={`btn-trip-del-${tour.id}`}
                              className="text-rose-500 p-1.5 bg-white border border-slate-200 rounded-lg hover:border-rose-600 hover:text-rose-700 transition-colors cursor-pointer flex items-center justify-center"
                              title="إزالة البرنامج السياحي"
                            >
                              <Trash2 size={13} id={`icon-del-trip-${tour.id}`} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          )}

          {/* TAB 3: BACKUP UTILITIES AND LOCAL EXPORT */}
          {activeTab === 'options' && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 max-w-2xl mx-auto space-y-6 animate-in fade-in duration-200">
              <div className="text-center space-y-2 border-b border-slate-100 pb-5">
                <div className="mx-auto w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center">
                  <Database size={24} id="icon-options-db" />
                </div>
                <h3 className="font-bold text-lg text-slate-800">إدارة السجلات والنسخ الاحتياطي</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                  بما أن هذا التطبيق مخصص للعمل المكتبي الآمن، يتم تخزين كافة البيانات في متصفحك بشكل فوري وهو ما يعني خصوصية مطلقة للزبائن. لضمان عدم ضياع أعمالك، يمكنك إجراء نسخ احتياطي فوري واستعادته بأي وقت.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Download Backup */}
                <div className="border border-slate-200 p-4 rounded-xl space-y-3 bg-gradient-to-br from-slate-50 to-white hover:shadow-xs transition-all">
                  <h4 className="font-bold text-sm text-slate-800">حفظ نسخة احتياطية للقرص</h4>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    تحميل كامل قاعدة بيانات الزبائن ومواعيد حجز الرحلات في ملف واحد بصيغة JSON آمنة ومحمية لحفظها في حاسوبك المكتبي.
                  </p>
                  <button
                    onClick={downloadBackupJSON}
                    id="btn-export-records"
                    className="w-full mt-2 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  >
                    <Download size={14} id="icon-export-bk" />
                    تحميل نسخة احتياطية للبيانات
                  </button>
                </div>

                {/* Restore Backup */}
                <div className="border border-slate-200 p-4 rounded-xl space-y-3 bg-gradient-to-br from-slate-50 to-white hover:shadow-xs transition-all">
                  <h4 className="font-bold text-sm text-slate-800">استعادة البيانات من ملف</h4>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    تحميل ملف النسخة الاحتياطية المسبقة لدمج واستعادة كامل حسابات المسافرين وتواريخ انطلاق السفر المخزنة فوراً.
                  </p>
                  
                  {/* Hidden Input Uploader */}
                  <input
                    type="file"
                    id="backup-file-uploader"
                    accept=".json"
                    onChange={handleUploadBackupJSON}
                    className="hidden"
                  />

                  <button
                    onClick={triggerJSONFileInput}
                    id="btn-import-records"
                    className="w-full mt-2 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  >
                    <Upload size={14} id="icon-import-bk" />
                    اختر واستورد ملف السجلات الاحتياطية
                  </button>
                </div>

              </div>

              {/* Force Cache Reset and Sync Official Trips */}
              <div className="border border-blue-250 p-5 rounded-xl space-y-3 bg-blue-50/45 text-right font-sans">
                <h4 className="font-bold text-sm text-blue-900 flex items-center gap-2 justify-end">
                  <span>مزامنة وتفعيل برامج الرحلات الجديدة (تحديث صيف 2026 🇪🇬)</span>
                  <RefreshCw size={15} className="text-blue-600 animate-spin" style={{ animationDuration: '6s' }} />
                </h4>
                <p className="text-[11px] text-blue-800 leading-relaxed font-sans">
                  إذا واجهتك مشكلة في ظهور برامج الرحلات المضافة حديثاً (مثل <strong>رحلة شرم الشيخ صيف 2026</strong> بمصر) بعد رفع الموقع على GitHub/Vercel، فهذا يعود لمتصفحك الذي يحتفظ بنسخة كاش عتيقة لملف <code>localStorage</code>. بالنقر على زر المزامنة أدناه، سيتم مسح الكاش المتقادم وتثبيت أحدث روزنامة رحلات معتمدة فوراً دون التأثير على الحجوزات المسجلة مطلقاً.
                </p>
                <button
                  onClick={forceTriggerTripsSync}
                  id="btn-sync-cache-trips"
                  className="w-full mt-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-all shadow-sm cursor-pointer"
                >
                  <RefreshCw size={14} />
                  تحديث ومزامنة روزنامة البرامج (حل مشكلة الكاش)
                </button>
              </div>

              {/* Developer Note */}
              <div className="bg-blue-50/70 rounded-xl p-4 border border-blue-105 text-xs text-blue-800 leading-relaxed font-sans">
                <strong>💡 تنويه أمني:</strong> تذكر دائماً ألا تمسح ملفات تعريف ارتباط المتصفح (Cache) أو بيانات المتصفح الخاصة لضمان ثبات السجلات. يوصى بشدة بتحميل نسخة احتياطية في نهاية كل أسبوع عمل لحماية وحفظ ملفات زبائن وكالة عبعوب للسياحة والأسفار.
              </div>
            </div>
          )}

          {/* TAB 3.5: RECEIPT VOUCHER MAKER & PRINTER */}
          {activeTab === 'receipt' && (
            <ReceiptVoucher
              customers={customers}
              trips={trips}
              agencySettings={agencySettings}
              receipts={receipts}
              onSaveReceipt={handleSaveReceipt}
              onDeleteReceipt={handleDeleteReceipt}
            />
          )}

          {/* TAB 4: ADVANCED ADMIN & HR CENTER */}
          {activeTab === 'admin' && (currentEmployee.role === 'Admin' || currentEmployee.role === 'Manager') && (
            <div className="space-y-6 animate-in fade-in duration-200 text-right">
              
              {/* Header Info */}
              <div className="bg-gradient-to-l from-zinc-900 to-zinc-800 text-white rounded-2xl p-6 shadow-md border-b border-amber-500/30 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-md font-bold uppercase tracking-wider">
                    قسم الرقابة والعمليات الإدارية الموحد
                  </span>
                  <h3 className="font-sans font-black text-lg">بوابة التحكم بالفروع وتقييم المبيعات والموظفين</h3>
                  <p className="text-xs text-stone-300">أنت تتصفح حالياً بصلاحيات الإشراف الإداري العام. قم بتهيأة الموظفين الميدانيين وفرض ضوابط المحاسبة.</p>
                </div>
                <div className="flex items-center gap-2.5 bg-zinc-950/60 border border-zinc-800 px-4 py-2.5 rounded-xl">
                  <Users className="text-amber-500 shrink-0" size={20} />
                  <div className="text-right">
                    <span className="text-[10px] text-stone-400 block font-bold leading-none">إجمالي القوى العاملة:</span>
                    <span className="font-mono text-base font-black text-stone-100">{employees.length} موظف معتمد</span>
                  </div>
                </div>
              </div>

              {/* Administrative Bento Statistics Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white border border-stone-200/80 rounded-2xl p-4 flex items-center justify-between shadow-3xs">
                  <div className="space-y-1">
                    <span className="text-[10px] text-stone-400 font-bold block">الفروع الجغرافية</span>
                    <span className="text-lg font-black text-stone-900 font-mono">{branches.length} مكاتب فرعية</span>
                    <p className="text-[9px] text-stone-500">متصلة بالنظام الموحد</p>
                  </div>
                  <div className="p-3 bg-stone-50 text-stone-600 rounded-xl border border-stone-100">
                    <Building2 size={18} />
                  </div>
                </div>

                <div className="bg-white border border-stone-200/80 rounded-2xl p-4 flex items-center justify-between shadow-3xs">
                  <div className="space-y-1">
                    <span className="text-[10px] text-stone-400 font-bold block">الوكلاء ومسؤولي الحجز</span>
                    <span className="text-lg font-black text-stone-900 font-mono">
                      {employees.filter(e => e.role === 'Agent').length} وكلاء حجز
                    </span>
                    <p className="text-[9px] text-stone-500">مستخدمين نشطين بالبوابة</p>
                  </div>
                  <div className="p-3 bg-stone-50 text-stone-600 rounded-xl border border-stone-100">
                    <UserSquare2 size={18} />
                  </div>
                </div>

                <div className="bg-white border border-stone-200/80 rounded-2xl p-4 flex items-center justify-between shadow-3xs">
                  <div className="space-y-1">
                    <span className="text-[10px] text-stone-400 font-bold block">المبيعات والحجوزات الحالية</span>
                    <span className="text-lg font-black text-stone-900 font-mono">{customers.length} زبون</span>
                    <p className="text-[9px] text-stone-500">مسجلين في كافة الفروع</p>
                  </div>
                  <div className="p-3 bg-stone-50 text-stone-600 rounded-xl border border-stone-100">
                    <DollarSign size={18} className="text-amber-600" />
                  </div>
                </div>

                <div className="bg-white border border-stone-200/80 rounded-2xl p-4 flex items-center justify-between shadow-3xs">
                  <div className="space-y-1">
                    <span className="text-[10px] text-stone-400 font-bold block">المدراء والمشرفين</span>
                    <span className="text-lg font-black text-stone-900 font-mono">
                      {employees.filter(e => e.role === 'Admin' || e.role === 'Manager').length} إداريين
                    </span>
                    <p className="text-[9px] text-stone-500">صلاحيات تحكم كاملة</p>
                  </div>
                  <div className="p-3 bg-stone-50 text-stone-600 rounded-xl border border-stone-100">
                    <ShieldCheck size={18} className="text-blue-600" />
                  </div>
                </div>
              </div>

              {/* Action Creators: Add Employee & Add Branch Side-By-Side */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                
                {/* Creator: Add Employee Account (8 / 12) */}
                <div className="lg:col-span-8 bg-white rounded-2xl border border-stone-200 p-5 space-y-4">
                  <div className="border-b border-stone-100 pb-3 flex items-center gap-3">
                    <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
                      <UserPlus2 size={16} />
                    </div>
                    <div>
                      <h4 className="font-sans font-black text-stone-900 text-sm">تسجيل وتهيأة حساب موظف جديد</h4>
                      <p className="text-[10px] text-stone-500 font-sans mt-0.5">أنشئ حساب دخول منفرد لكل وكيل حجز أو رئيس فرع لتتبع مبيعاته</p>
                    </div>
                  </div>

                  <form onSubmit={handleAddEmployeeSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-sans text-right text-xs">
                    <div className="space-y-1">
                      <label className="font-extrabold text-stone-700 block">الاسم الثلاثي الكامل للموظف <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        placeholder="مثال: يونس بن مسعود"
                        value={newEmpName}
                        onChange={(e) => setNewEmpName(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold font-sans text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-extrabold text-stone-700 block">اسم المستخدم الفريد (الدخول) <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        placeholder="مثال: younes_touggourt"
                        value={newEmpUsername}
                        onChange={(e) => setNewEmpUsername(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold font-mono text-left text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                        dir="ltr"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-extrabold text-stone-700 block">كلمة المرور الخاصة بالحساب <span className="text-rose-500">*</span></label>
                      <input
                        type="password"
                        placeholder="اكتب كلمة سر قوية أو اترك الافتراضي 123"
                        value={newEmpPassword}
                        onChange={(e) => setNewEmpPassword(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold font-mono text-left text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                        dir="ltr"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-extrabold text-stone-700 block">الدور والجهوزية الأمنية <span className="text-rose-500">*</span></label>
                      <select
                        value={newEmpRole}
                        onChange={(e) => setNewEmpRole(e.target.value as any)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none cursor-pointer"
                      >
                        <option value="Agent">Agent (عميل حجز قياسي - يرى فرعه فقط)</option>
                        <option value="Manager">Manager (مشرف فروع - يرى فرعه ولديه صلاحية تصفية باقي الفروع)</option>
                        <option value="Admin">Admin (المدير الإداري العام للشركة - صلاحيات شاملة ورقابة كل الفروع)</option>
                      </select>
                    </div>

                    <div className="space-y-1 sm:col-span-2">
                      <label className="font-extrabold text-stone-700 block">الفرع الجغرافي المعيّن فيه هذا الموظف <span className="text-rose-500">*</span></label>
                      <select
                        value={newEmpBranchId}
                        onChange={(e) => setNewEmpBranchId(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-black text-amber-950 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none cursor-pointer"
                      >
                        <option value="">-- اختر الفرع الجغرافي التابع له الموظف --</option>
                        {branches.map(b => (
                          <option key={b.id} value={b.id}>🏢 {b.name} ({b.location})</option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2 pt-2 text-left">
                      <button
                        type="submit"
                        className="px-6 py-2.5 bg-zinc-950 hover:bg-zinc-900 border border-amber-500/20 text-amber-400 hover:text-amber-300 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer inline-flex"
                      >
                        <UserPlus2 size={13} className="shrink-0" />
                        <span>تأسيس وتنشيط حساب الموظف</span>
                      </button>
                    </div>
                  </form>
                </div>

                {/* Creator: Add Branch (4 / 12) */}
                <div className="lg:col-span-4 bg-white rounded-2xl border border-stone-200 p-5 space-y-4">
                  <div className="border-b border-stone-100 pb-3 flex items-center gap-3">
                    <div className="p-2 bg-sky-50 text-sky-600 rounded-xl">
                      <Building2 size={16} />
                    </div>
                    <div>
                      <h4 className="font-sans font-black text-stone-900 text-sm">تأسيس مكتب فرع جديد</h4>
                      <p className="text-[10px] text-stone-500 font-sans mt-0.5">افتح فرعاً جغرافياً لربط وكلائه بالنظام الجاري للشركة</p>
                    </div>
                  </div>

                  <form onSubmit={handleAddBranchSubmit} className="space-y-4 font-sans text-right text-xs">
                    <div className="space-y-1">
                      <label className="font-extrabold text-stone-700 block">اسم مكتب الفرع الجديد <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        placeholder="مثال: فرع الوادي، فرع قسنطينة"
                        value={newBranchName}
                        onChange={(e) => setNewBranchName(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold font-sans text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="font-extrabold text-stone-700 block">العنوان والموقع الجغرافي <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        placeholder="مثال: حي الرمال، وسط المدينة"
                        value={newBranchLocation}
                        onChange={(e) => setNewBranchLocation(e.target.value)}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold font-sans text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                      />
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 hover:text-blue-850 border border-blue-200 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Plus size={13} className="shrink-0" />
                        <span>تأكيد المطلب وتأسيس مكتب الفرع</span>
                      </button>
                    </div>
                  </form>
                </div>

              </div>

              {/* Table section: list of employees */}
              <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
                <div className="p-5 border-b border-stone-100 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h4 className="font-sans font-black text-stone-900 text-sm">سجل حسابات الموظفين المعتمدة بالوكالة</h4>
                    <p className="text-[10px] text-stone-400">كافة الروابط والحسابات النشطة والمسترجعة من الـ Local Storage بخصوصية</p>
                  </div>
                  <span className="font-mono text-[10px] text-stone-500 font-bold bg-stone-50 border border-stone-200 rounded-lg px-2 py-1">
                    إجمالي: {employees.length} حساب
                  </span>
                </div>

                <div className="overflow-x-auto text-xs">
                  <table className="w-full text-right border-collapse font-sans table-auto">
                    <thead>
                      <tr className="bg-stone-50 border-b border-stone-150 text-stone-500 font-bold select-none">
                        <th className="p-3">اسم الموظف الرسمي</th>
                        <th className="p-3">اسم المستخدم (المعرّف)</th>
                        <th className="p-3">صلاحية النظام</th>
                        <th className="p-3">الفرع المكتبي المعين فيه</th>
                        <th className="p-3 text-center">أمن الحساب</th>
                        <th className="p-3 text-center">التحكم والضبط</th>
                      </tr>
                    </thead>
                     <tbody className="divide-y divide-stone-150">
                       {employees.map(emp => (
                         <tr key={emp.id} className="hover:bg-amber-50/20 transition-all font-semibold text-stone-850 text-[11px]">
                           <td className="p-3 font-extrabold text-stone-900 flex items-center gap-2">
                             <span className="w-1.5 h-1.5 rounded-full bg-stone-400"></span>
                             <span className={emp.disabled ? 'line-through text-stone-400' : ''}>{emp.name}</span>
                           </td>
                           <td className="p-3 font-mono font-bold text-stone-600 text-left" dir="ltr">@{emp.username}</td>
                           <td className="p-3">
                             <span className={`px-2 py-0.5 rounded font-black text-[9.5px] border ${
                               emp.role === 'Admin' 
                                 ? 'bg-rose-50 text-rose-700 border-rose-100' 
                                 : emp.role === 'Manager' 
                                 ? 'bg-blue-50 text-blue-700 border-blue-105' 
                                 : 'bg-emerald-50 text-emerald-700 border-emerald-100'
                             }`}>
                               {emp.role === 'Admin' ? 'المدير العام' : emp.role === 'Manager' ? 'مشرف فروع' : 'وكيل حجز قياسي'}
                             </span>
                           </td>
                           <td className="p-3 font-medium text-stone-605">🏢 {emp.branchName}</td>
                           <td className="p-3 text-center">
                             {emp.disabled ? (
                               <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-rose-50 text-rose-700 border border-rose-150">
                                 <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse"></span>
                                 معطل
                               </span>
                             ) : (
                               <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-150">
                                 <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-none"></span>
                                 نشط {emp.id === 'emp-1' && '(محمي)'}
                               </span>
                             )}
                           </td>
                           <td className="p-2 text-center">
                             <div className="flex items-center justify-center gap-1.5">
                               <button
                                 onClick={() => {
                                   setEditingEmployee(emp);
                                   setEditEmpName(emp.name);
                                   setEditEmpUsername(emp.username);
                                   setEditEmpPassword('');
                                   setEditEmpRole(emp.role);
                                   setEditEmpBranchId(emp.branchId);
                                 }}
                                 className="p-1 px-2.5 bg-stone-50 hover:bg-stone-100 text-stone-700 hover:text-stone-900 border border-stone-200 rounded-lg flex items-center gap-1 transition-all font-black text-[10px] cursor-pointer"
                               >
                                 <Edit2 size={11} />
                                 <span>تعديل</span>
                               </button>

                               <button
                                 onClick={() => toggleDisableEmployee(emp.id, emp.disabled)}
                                 disabled={emp.id === 'emp-1' || emp.id === currentEmployee?.id}
                                 className={`p-1 px-2.5 rounded-lg border text-amber-700 hover:bg-amber-50 border-amber-200 transition-all cursor-pointer select-none flex items-center gap-1 text-[10px] font-black ${
                                   emp.id === 'emp-1' || emp.id === currentEmployee?.id ? 'opacity-30 cursor-not-allowed hover:bg-transparent border-stone-100 text-stone-300' : ''
                                 }`}
                               >
                                 {emp.disabled ? (
                                   <>
                                     <CheckCircle2 size={11} className="text-emerald-500" />
                                     <span>تفعيل</span>
                                   </>
                                 ) : (
                                   <>
                                     <AlertCircle size={11} className="text-rose-500" />
                                     <span>تعطيل</span>
                                   </>
                                 )}
                               </button>

                               <button
                                 onClick={() => {
                                   if (confirm(`هل أنت متأكد من رغبتك في إلغاء وإزالة موظف الوكالة "${emp.name}" بالكامل وفصل بياناته؟`)) {
                                     handleDeleteEmployee(emp.id);
                                   }
                                 }}
                                 className={`p-1 px-2.5 rounded-lg border text-rose-500 hover:bg-rose-50 border-stone-200 transition-all cursor-pointer select-none flex items-center gap-1 text-[10px] font-black ${
                                   emp.id === 'emp-1' || emp.id === currentEmployee?.id ? 'opacity-30 cursor-not-allowed text-stone-300 hover:bg-transparent border-stone-100' : ''
                                 }`}
                                 disabled={emp.id === 'emp-1' || emp.id === currentEmployee?.id}
                                >
                                 <Trash2 size={11} />
                                 <span>حذف</span>
                               </button>
                             </div>
                           </td>
                         </tr>
                       ))}
                     </tbody>
                  </table>
                </div>
              </div>

              {/* Interactive Audit Trail Log Desk (Real Logs) */}
              <div className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs">
                <div className="p-5 border-b border-stone-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-right space-y-0.5">
                    <h4 className="font-sans font-black text-stone-900 text-sm flex items-center gap-1.5 justify-end">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
                      <span>سجل العمليات والرقابة الفورية الموحد (System Audit Trail)</span>
                    </h4>
                    <p className="text-[10px] text-stone-400">بيانات رقابية مشفّرة غير قابلة للتعديل أو المسح لتحديد الموظب والفرع والوقت لكل عملية بشكل قطعي</p>
                  </div>
                  <button
                    onClick={() => {
                      if (confirm('تنبيه أمني: هل تود مسح وعصف سجل العمليات بالكامل لأسباب صيانة فنية؟')) {
                        setLogs([]);
                        localStorage.setItem('aboub_operation_logs', JSON.stringify([]));
                        showToast('تم تصفير وعصف سجل الرقابة والعمليات بنجاح!', 'info');
                      }
                    }}
                    className="px-3 py-1 bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-605 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer select-none"
                  >
                    <Trash2 size={11} />
                    <span>تصفير سجل الرقابة</span>
                  </button>
                </div>

                <div className="p-4 bg-stone-50 border-b border-stone-150 flex items-center justify-between text-xs font-sans text-stone-500 select-none">
                  <span>يعرض آخر العمليات الموثقة بالثواني والدقائق لموظفي فروع وكالة عبعوب</span>
                  <span className="font-mono text-stone-700 font-bold bg-white border border-stone-150 px-2 py-0.5 rounded-md">
                    مجموع القيود: {logs.length} عملية مرصودة
                  </span>
                </div>

                <div className="p-1 max-h-[380px] overflow-y-auto divide-y divide-stone-100">
                  {logs.length === 0 ? (
                    <div className="py-12 text-center text-stone-400 font-sans space-y-2">
                      <Lock size={20} className="mx-auto opacity-40 text-stone-500" />
                      <p className="text-xs">سجل العمليات الموحد فارغ تماماً حالياً.</p>
                      <p className="text-[10px]">البوابة ستقوم بتوثيق أي حركات حجز أو إضافة سياحية فور حدوثها.</p>
                    </div>
                  ) : (
                    [...logs].reverse().map((lg) => (
                      <div key={lg.id} className="p-3.5 hover:bg-stone-50/70 transition-all text-right flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs font-sans leading-relaxed">
                        
                        {/* Operator info and Action message */}
                        <div className="flex items-start md:items-center gap-3">
                          {/* Log Icon Badge */}
                          <div className={`p-1.5 rounded-lg shrink-0 mt-0.5 md:mt-0 ${
                            lg.actionType === 'add_customer' 
                              ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' 
                              : lg.actionType === 'delete_customer' 
                              ? 'bg-rose-50 text-rose-600 border border-rose-100 font-black' 
                              : lg.actionType === 'update_customer' 
                              ? 'bg-amber-50 text-amber-600 border border-amber-100' 
                              : 'bg-blue-50 text-blue-600 border border-blue-100'
                          }`}>
                            <ShieldAlert size={13} />
                          </div>

                          <div className="space-y-1">
                            {/* Action text */}
                            <p className="font-black text-stone-850 text-[11.5px]">{lg.details}</p>
                            
                            {/* Actor identity badge */}
                            <div className="flex items-center gap-2 text-[10px] text-stone-500 font-bold">
                              <span className="text-stone-900 bg-stone-150 rounded px-1.5 py-0.5">👤 {lg.operatorName} (@{lg.operatorUsername})</span>
                              <span>•</span>
                              <span className="text-amber-700 bg-amber-50 rounded px-1.5 py-0.5">🏢 الفرع: {lg.branchName}</span>
                            </div>
                          </div>
                        </div>

                        {/* Timestamp value */}
                        <div className="font-mono text-[9.5px] text-stone-400 bg-stone-100 rounded-md px-2.5 py-1 text-left shrink-0 font-bold flex items-center gap-1.5 border border-stone-200/50" dir="ltr">
                          <Clock size={9} />
                          <span>{new Date(lg.timestamp).toLocaleString('ar-DZ')}</span>
                        </div>

                      </div>
                    ))
                  )}
                </div>

              </div>

            </div>
          )}

        </div>

      </main>

      {/* 5. FOOTER */}
      <footer className="bg-white border-t border-slate-150 py-4 px-6 text-center text-xs text-slate-400 mt-12 print:hidden">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <span>
            جميع الحقوق محفوظة © {new Date().getFullYear()} - {agencySettings.websiteName || 'وكالة عبعوب لسياحة والأسفار والرحلات'}
          </span>
          <span className="font-mono text-[10px] bg-slate-50 border border-slate-100 px-2 py-1 rounded">
            Version 2.4.0 (Offline-first Workspace)
          </span>
        </div>
      </footer>

      </div> {/* End .flex-1 .flex-col content wrapper */}

      {/* 6. MODAL OVERLAYS FOR PRINTING */}
      {selectedPrintCustomer && (
        <PrintDocument
          customer={selectedPrintCustomer}
          customers={customers}
          trips={trips}
          onClose={() => setSelectedPrintCustomer(null)}
          onSelectCustomer={setSelectedPrintCustomer}
        />
      )}

      {/* 7. MODAL OVERLAYS FOR EDITING TRIP PROGRAM */}
      {editingTrip && (() => {
        const tripLabels = getTripPriceLabelsAndDefaults(editingTrip.id, editingTrip);
        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/35 backdrop-blur-xs font-sans" dir="rtl">
            <div className="bg-white rounded-2xl border border-stone-200 max-w-lg w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-155 max-h-[90vh] overflow-y-auto">
              
              <button
                onClick={() => setEditingTrip(null)}
                id="trip-modal-close"
                className="absolute top-4 left-4 p-1 rounded-full text-stone-400 bg-stone-50 hover:bg-stone-100 hover:text-stone-600 transition-colors cursor-pointer border border-stone-200"
              >
                <X size={16} />
              </button>

              <div className="flex items-center gap-2 border-b border-stone-100 pb-3 mb-4 justify-start">
                <Sparkles className="text-blue-600 animate-pulse" size={16} />
                <h3 className="font-extrabold text-zinc-900 text-sm md:text-base">تعديل تفاصيل برنامج الرحلة السياحية</h3>
              </div>

              <form onSubmit={handleUpdateTrip} className="space-y-4 text-right text-xs">
                
                <div>
                  <label htmlFor="edit-trip-name" className="block text-[10px] font-bold text-stone-600 mb-1">اسم الرحلة / البرنامج</label>
                  <input
                    type="text"
                    id="edit-trip-name"
                    value={editingTrip.name}
                    onChange={(e) => setEditingTrip({ ...editingTrip, name: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/80 transition-all text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="edit-trip-destination" className="block text-[10px] font-bold text-stone-600 mb-1">الوجهة (المدينة والبلد)</label>
                  <input
                    type="text"
                    id="edit-trip-destination"
                    value={editingTrip.destination}
                    onChange={(e) => setEditingTrip({ ...editingTrip, destination: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/80 transition-all text-stone-800"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="edit-trip-price" className="block text-[10px] font-bold text-stone-600 mb-1">سعر المقعد بالدينار (DZD)</label>
                    <input
                      type="number"
                      id="edit-trip-price"
                      value={editingTrip.price}
                      onChange={(e) => setEditingTrip({ ...editingTrip, price: parseInt(e.target.value) || 0 })}
                      className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white font-mono font-bold text-stone-800 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/80 transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label htmlFor="edit-trip-duration" className="block text-[10px] font-bold text-stone-600 mb-1">مدة الإقامة المجدولة</label>
                    <input
                    type="text"
                    id="edit-trip-duration"
                    value={editingTrip.duration}
                    onChange={(e) => setEditingTrip({ ...editingTrip, duration: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/80 transition-all text-stone-800"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="edit-trip-date" className="block text-[10px] font-bold text-stone-600 mb-1">تاريخ انطلاق السفر (الرئيسي)</label>
                  <input
                    type="date"
                    id="edit-trip-date"
                    value={editingTrip.date}
                    onChange={(e) => setEditingTrip({ ...editingTrip, date: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-200 rounded-lg text-xs bg-white font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/80 transition-all text-stone-800 text-right font-sans"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="edit-trip-status" className="block text-[10px] font-bold text-stone-600 mb-1">حالة البرنامج النشط</label>
                  <select
                    id="edit-trip-status"
                    value={editingTrip.status}
                    onChange={(e) => setEditingTrip({ ...editingTrip, status: e.target.value as 'active' | 'completed' | 'upcoming' | 'suspended' })}
                    className="w-full px-2.5 py-2 border border-stone-200 bg-white rounded-lg text-xs font-bold text-stone-800 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/80 cursor-pointer font-sans text-right"
                  >
                    <option value="active">فعّالة حالياً (نشطة)</option>
                    <option value="upcoming">قادمة قريباً</option>
                    <option value="suspended">معلّقة / موقوفة مؤقتاً</option>
                    <option value="completed">مكتملة / منتهية</option>
                  </select>
                </div>
              </div>

              <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 mt-2">
                <label className="block font-bold text-stone-700 mb-1 text-[10px] flex items-center justify-between">
                  <span>📆 تواريخ انطلاق إضافية أخرى</span>
                  <span className="text-[9px] text-stone-400 font-normal">اختياري</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="date"
                    value={editTripDatesInput}
                    onChange={(e) => setEditTripDatesInput(e.target.value)}
                    className="flex-1 px-2.5 py-1.5 border border-stone-200 bg-white rounded-lg text-xs font-medium font-sans"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!editTripDatesInput) return;
                      const currentDates = editingTrip.dates || [];
                      if (currentDates.includes(editTripDatesInput) || editingTrip.date === editTripDatesInput) {
                        showToast('هذا التاريخ مضاف بالفعل كخيار انطلاق!', 'error');
                        return;
                      }
                      setEditingTrip({
                        ...editingTrip,
                        dates: [...currentDates, editTripDatesInput].sort()
                      });
                      setEditTripDatesInput('');
                    }}
                    className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-600 font-bold rounded-lg border border-blue-200 transition-colors text-xs shrink-0 cursor-pointer"
                  >
                    إضافة تاريخ
                  </button>
                </div>

                {editingTrip.dates && editingTrip.dates.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2.5 pt-2 border-t border-stone-200/50">
                    {editingTrip.dates.map((d, index) => (
                      <div key={index} className="inline-flex items-center gap-1 bg-white border border-slate-200 text-slate-700 px-1.5 py-0.5 rounded text-[10px] font-bold font-mono">
                        <span>{d}</span>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingTrip({
                              ...editingTrip,
                              dates: editingTrip.dates?.filter(dt => dt !== d) || []
                            });
                          }}
                          className="text-red-500 hover:text-red-700 text-[10px] px-0.5 font-bold"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Trip Type Selector for EDIT (Standard / Normal vs Professional) */}
              <div className="space-y-1.5 font-sans text-right">
                <span className="block text-[10px] font-bold text-stone-600">تصنيف وتسعير برنامج الرحلة</span>
                <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200/50">
                  <button
                    type="button"
                    onClick={() => setEditingTrip({ ...editingTrip, isProfessional: false })}
                    className={`py-1.5 px-3 rounded-lg text-center font-bold text-[10px] transition-all cursor-pointer ${
                      !editingTrip.isProfessional
                        ? 'bg-white text-slate-800 shadow-xs border border-slate-250 font-extrabold'
                        : 'text-slate-550 hover:text-slate-850 hover:bg-slate-50'
                    }`}
                  >
                    ✈️ رحلة عادية (سعر موحد ومباشر)
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingTrip({ ...editingTrip, isProfessional: true })}
                    className={`py-1.5 px-3 rounded-lg text-center font-bold text-[10px] transition-all cursor-pointer ${
                      editingTrip.isProfessional
                        ? 'bg-blue-600 text-white shadow-xs font-extrabold'
                        : 'text-slate-550 hover:text-slate-850 hover:bg-slate-50'
                    }`}
                  >
                    ⭐ رحلة احترافية (أسعار غرف مفصلة)
                  </button>
                </div>
              </div>

              {/* Detailed Prices Section (Algerian Accommodation Style) - EDIT */}
              {editingTrip.isProfessional && (
                <div className="bg-blue-50/45 p-3 rounded-lg border border-blue-100 space-y-2 mt-2 font-sans text-right animate-in fade-in duration-150">
                  <h4 className="font-extrabold text-[11px] text-blue-900 border-b border-blue-100 pb-1 mb-1.5 flex items-center gap-1">
                    <span>🏷️ تفاصيل الأسعار حسب نوع الغرفة والمقعد والأطفال</span>
                  </h4>
                  <p className="text-[9px] text-slate-500 leading-normal mb-1">
                    تعديل هذه الحقول ينعكس فوراً للمسافرين في استمارة التسجيل الحالية والعروض لجميع المستخدمين.
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div>
                      <label htmlFor="edit-trip-price-single" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceSingle.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceSingle.label : 'غرفة فردية Single'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-single"
                        placeholder={tripLabels.priceSingle.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceSingle.defaultVal}` : 'مثال: 75000'}
                        value={editingTrip.priceSingle ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceSingle: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                    <div>
                      <label htmlFor="edit-trip-price-double" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceDouble.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceDouble.label : 'غرفة ثنائية Double'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-double"
                        placeholder={tripLabels.priceDouble.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceDouble.defaultVal}` : 'مثال: 55000'}
                        value={editingTrip.priceDouble ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceDouble: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                    <div>
                      <label htmlFor="edit-trip-price-triple" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceTriple.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceTriple.label : 'غرفة ثلاثية Triple'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-triple"
                        placeholder={tripLabels.priceTriple.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceTriple.defaultVal}` : 'مثال: 48000'}
                        value={editingTrip.priceTriple ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceTriple: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                    <div>
                      <label htmlFor="edit-trip-price-quadruple" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceQuadruple.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceQuadruple.label : 'غرفة رباعية Quadruple'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-quadruple"
                        placeholder={tripLabels.priceQuadruple.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceQuadruple.defaultVal}` : 'مثال: 42000'}
                        value={editingTrip.priceQuadruple ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceQuadruple: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                    <div>
                      <label htmlFor="edit-trip-price-quintuple" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceQuintuple.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceQuintuple.label : 'غرفة خماسية Quintuple'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-quintuple"
                        placeholder={tripLabels.priceQuintuple.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceQuintuple.defaultVal}` : 'مثال: 38000'}
                        value={editingTrip.priceQuintuple ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceQuintuple: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                    <div>
                      <label htmlFor="edit-trip-price-sextuple" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceSextuple.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceSextuple.label : 'غرفة سداسية Sextuple'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-sextuple"
                        placeholder={tripLabels.priceSextuple.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceSextuple.defaultVal}` : 'مثال: 35000'}
                        value={editingTrip.priceSextuple ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceSextuple: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                    <div className="col-span-2">
                      <label htmlFor="edit-trip-price-child" className="block font-bold text-slate-600 mb-0.5">
                        {tripLabels.priceChild.label !== 'غير مستخدم في هذا العرض' ? tripLabels.priceChild.label : 'سعر الأطفال Child'}
                      </label>
                      <input
                        type="number"
                        id="edit-trip-price-child"
                        placeholder={tripLabels.priceChild.defaultVal !== undefined ? `الافتراضي: ${tripLabels.priceChild.defaultVal}` : 'مثال: 32000'}
                        value={editingTrip.priceChild ?? ''}
                        onChange={(e) => {
                          const val = parseInt(e.target.value) || undefined;
                          setEditingTrip({ ...editingTrip, priceChild: val });
                        }}
                        className="w-full px-2 py-1.5 border border-slate-200 bg-white rounded-md text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono text-stone-800"
                      />
                    </div>
                  </div>

                  {/* Custom Price Fields Section - EDIT */}
                  {editingTrip.customPrices && editingTrip.customPrices.length > 0 && (
                    <div className="space-y-2 mt-3 pt-3 border-t border-blue-100 text-right">
                      <span className="block text-[10px] text-blue-900 font-extrabold">📋 الأسعار الإضافية المخصصة:</span>
                      <div className="space-y-1.5">
                        {editingTrip.customPrices.map((cp, idx) => (
                          <div key={cp.id} className="flex gap-1.5 items-center bg-white/70 p-1.5 rounded-lg border border-slate-200">
                            <div className="flex-1">
                              <input
                                type="text"
                                value={cp.label}
                                onChange={(e) => {
                                  const updated = [...(editingTrip.customPrices || [])];
                                  updated[idx].label = e.target.value;
                                  setEditingTrip({ ...editingTrip, customPrices: updated });
                                }}
                                placeholder="اسم التسعيرة (مثال: غرفة مطلة على البحر)"
                                className="w-full px-2 py-1 border border-slate-200 rounded text-[11px] text-stone-800 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                                required
                              />
                            </div>
                            <div className="w-24">
                              <input
                                type="number"
                                value={cp.price || ''}
                                onChange={(e) => {
                                  const updated = [...(editingTrip.customPrices || [])];
                                  updated[idx].price = parseInt(e.target.value) || 0;
                                  setEditingTrip({ ...editingTrip, customPrices: updated });
                                }}
                                placeholder="السعر دج"
                                className="w-full px-2 py-1 border border-slate-200 rounded text-[11px] text-stone-850 bg-white font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                                required
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setEditingTrip({
                                  ...editingTrip,
                                  customPrices: (editingTrip.customPrices || []).filter((_, i) => i !== idx)
                                });
                              }}
                              className="p-1 text-red-500 hover:bg-red-50 rounded text-xs cursor-pointer flex items-center justify-center border border-red-100"
                              title="حذف"
                            >
                              ❌
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Add Custom Price Button - EDIT */}
                  <div className="mt-2 text-right">
                    <button
                      type="button"
                      onClick={() => {
                        const newCustom = {
                          id: `custom-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
                          label: '',
                          price: 0
                        };
                        setEditingTrip({
                          ...editingTrip,
                          customPrices: [...(editingTrip.customPrices || []), newCustom]
                        });
                      }}
                      className="w-full py-1.5 bg-blue-100/60 hover:bg-blue-200/60 text-blue-800 text-[10px] font-bold rounded-lg border border-dashed border-blue-300 transition-all cursor-pointer flex items-center justify-center gap-1"
                    >
                      ➕ إضافة خانة تسعيرة مخصصة إضافية جديدة (أي عنوان وسعر)
                    </button>
                  </div>
                </div>
              )}

              {/* Departure/Itinerary info details - EDIT */}
              <div className="font-sans text-right">
                <label htmlFor="edit-trip-departure-notes" className="block font-bold text-slate-600 mb-1">تفاصيل وملاحظات خط سير الرحلة ونقاط المغادرة</label>
                <textarea
                  id="edit-trip-departure-notes"
                  placeholder="مثال: الانطلاق عبر الحافلة من أمام مقر الوكالة..."
                  value={editingTrip.departurePlaceNotes || ''}
                  onChange={(e) => setEditingTrip({ ...editingTrip, departurePlaceNotes: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-medium font-sans leading-relaxed text-right text-stone-800"
                />
              </div>

              {/* Cancel / Save */}
              <div className="flex items-center justify-end gap-2 border-t border-stone-100 pt-4 mt-2">
                <button
                  type="button"
                  onClick={() => setEditingTrip(null)}
                  id="btn-edit-trip-cancel"
                  className="px-4 py-2 text-xs font-bold text-stone-550 hover:text-stone-750 bg-stone-50 hover:bg-stone-150 rounded-lg border border-stone-200 cursor-pointer transition-all"
                >
                  إلغاء وتراجع
                </button>
                <button
                  type="submit"
                  id="btn-edit-trip-save"
                  className="px-5 py-2 text-xs font-black text-blue-100 bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 cursor-pointer transition-all shadow-sm border border-blue-650"
                >
                  <span className="text-white font-bold">تطبيق تعديل البرنامج</span>
                </button>
              </div>

            </form>
          </div>
        </div>
      )})()}

      {editingEmployee && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[9999] font-sans" dir="rtl">
          <div className="bg-white rounded-3xl border border-stone-200 max-w-lg w-full overflow-hidden shadow-2xl text-right">
            <div className="bg-amber-50 p-6 border-b border-stone-150 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/10 text-amber-600 rounded-xl">
                  <Edit2 size={18} />
                </div>
                <div>
                  <h3 className="font-sans font-black text-stone-900 text-base">تعديل ملف الموظف</h3>
                  <p className="text-[11px] text-stone-500 mt-0.5">تحديث معلومات حساب ومستويات وصول هذا الوكيل</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => setEditingEmployee(null)}
                className="p-1 px-2 border border-stone-200 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg transition-all cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleUpdateEmployeeSubmit} className="p-6 space-y-4 text-xs font-sans">
              <div className="space-y-1">
                <label className="font-extrabold text-stone-700 block">الاسم الكامل للموظف <span className="text-rose-500">*</span></label>
                <input
                  type="text"
                  required
                  value={editEmpName}
                  onChange={(e) => setEditEmpName(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-extrabold text-stone-700 block">اسم المستخدم (المعرِّف) <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={editEmpUsername}
                    onChange={(e) => setEditEmpUsername(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                    dir="ltr"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-extrabold text-stone-700 block">كلمة المرور الجديدة</label>
                  <input
                    type="password"
                    placeholder="اتركها فارغة لعدم التغيير"
                    value={editEmpPassword}
                    onChange={(e) => setEditEmpPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-mono text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-extrabold text-stone-700 block">الدور والصلاحيات بالنظام <span className="text-rose-500">*</span></label>
                <select
                  value={editEmpRole}
                  onChange={(e) => setEditEmpRole(e.target.value as any)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none cursor-pointer"
                  disabled={editingEmployee.id === 'emp-1'}
                >
                  <option value="Agent">Agent (عميل حجز قياسي)</option>
                  <option value="Manager">Manager (مشرف فروع)</option>
                  <option value="Admin">Admin (المدير الإداري العام)</option>
                </select>
                {editingEmployee.id === 'emp-1' && (
                  <p className="text-[10px] text-amber-600 mt-1">حساب المدير العام الرئيسي لا تُمَس صلاحياته للحفاظ على أمن النظام.</p>
                )}
              </div>

              <div className="space-y-1">
                <label className="font-extrabold text-stone-700 block">الفرع المكتبي المعين فيه <span className="text-rose-500">*</span></label>
                <select
                  value={editEmpBranchId}
                  onChange={(e) => setEditEmpBranchId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-black text-amber-950 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none cursor-pointer"
                >
                  {branches.map(b => (
                    <option key={b.id} value={b.id}>🏢&nbsp;&nbsp;{b.name}</option>
                  ))}
                </select>
              </div>

              <div className="pt-4 flex items-center justify-end gap-2 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setEditingEmployee(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  إلغاء التراجع
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold rounded-xl text-xs transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
                >
                  <ShieldCheck size={14} />
                  <span>تأكيد المطلب وحفظ التحديثات</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= SECRET PASSWORD MODAL ================= */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs font-sans" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-stone-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="font-extrabold text-stone-850 text-xs flex items-center gap-2">
                🔒 الدخول السرّي لوكيل الإدارة والمشرف
              </h3>
              <button
                type="button"
                onClick={() => setShowPasswordModal(false)}
                className="p-1 rounded-lg hover:bg-stone-150 text-stone-405 transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (secretPassword === 'aboub2026') {
                  setShowPasswordModal(false);
                  setShowSettingsModal(true);
                  setSecretPassword('');
                  setSecretError('');
                } else {
                  setSecretError('كلمة المرور غير صحيحة! يرجى المحاولة مرة أخرى.');
                }
              }}
              className="space-y-4 text-right"
            >
              <p className="text-[11px] text-stone-500 font-semibold leading-relaxed">
                أدخل كلمة المرور السرية المحددة للولوج إلى وحدة تخصيص هوية الموقع وألوانه وعلاماته التجارية المطبوعة.
              </p>

              <div>
                <label className="block text-[11px] font-bold text-stone-600 mb-1">كلمة المرور السرية</label>
                <input
                  type="password"
                  value={secretPassword}
                  onChange={(e) => {
                    setSecretPassword(e.target.value);
                    setSecretError('');
                  }}
                  placeholder="أدخل كلمة السر هنا..."
                  className="w-full px-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                  autoFocus
                  required
                />
                {secretError && (
                  <p className="text-[10px] text-red-500 mt-1 font-bold">⚠️ {secretError}</p>
                )}
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  إلغاء التراجع
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold rounded-xl text-xs transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
                >
                  <ShieldCheck size={14} />
                  <span>تأكيد الهوية</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= SECRET SETTINGS MODAL ================= */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs font-sans overflow-y-auto" dir="rtl">
          <div className={`bg-white rounded-3xl w-full ${secretModalTab === 'profits' ? 'max-w-4xl' : 'max-w-xl'} p-6 shadow-2xl border border-stone-100 my-8 animate-in fade-in zoom-in-95 duration-150 transition-all duration-300`}>
            <div className="flex items-center justify-between border-b border-stone-100 pb-3 mb-4">
              <h3 className="font-extrabold text-stone-850 text-xs flex items-center gap-2">
                ⚙️ لوحة التخصيص السرية والمالية
              </h3>
              <button
                type="button"
                onClick={() => setShowSettingsModal(false)}
                className="p-1 rounded-lg hover:bg-stone-150 text-stone-405 transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Tabs for Secret Dashboard */}
            <div className="flex border-b border-stone-100 mb-5 gap-4">
              <button
                type="button"
                onClick={() => setSecretModalTab('branding')}
                className={`pb-2.5 font-extrabold text-xs transition-all relative cursor-pointer ${
                  secretModalTab === 'branding'
                    ? 'text-amber-600 font-black border-b-2 border-amber-500'
                    : 'text-stone-450 hover:text-stone-700'
                }`}
              >
                🎨 هوية الوكالة وتخصيص الألوان
              </button>
              <button
                type="button"
                onClick={() => setSecretModalTab('profits')}
                className={`pb-2.5 font-extrabold text-xs transition-all relative cursor-pointer ${
                  secretModalTab === 'profits'
                    ? 'text-amber-600 font-black border-b-2 border-amber-500'
                    : 'text-stone-450 hover:text-stone-700'
                }`}
              >
                📊 أرباح ومداخيل المواسم والرحلات
              </button>
            </div>

            {secretModalTab === 'branding' ? (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!editWebsiteName.trim()) {
                    showToast('الرجاء إدخال اسم الموقع العربي', 'error');
                    return;
                  }

                  try {
                    const newSettings: AgencySettings = {
                      websiteName: editWebsiteName.trim(),
                      websiteEnglishName: editWebsiteEnglishName.trim(),
                      primaryColor: editPrimaryColor,
                      primaryColorHover: darkenColor(editPrimaryColor, 0.15),
                      primaryColorLight: adjustColorBrightness(editPrimaryColor, 0.65),
                      primaryColorBg: adjustColorBrightness(editPrimaryColor, 0.85),
                      primaryColorLightest: adjustColorBrightness(editPrimaryColor, 0.95),
                      websiteLogoUrl: editWebsiteLogoUrl,
                      receiptLogoUrl: editReceiptLogoUrl,
                    };

                    await setDoc(doc(db, 'agencySettings', 'default'), newSettings);
                    
                    // Also log this change in logs
                    const logId = `log-${Date.now()}`;
                    const newLog = {
                      id: logId,
                      employeeId: currentEmployee?.id || 'emp-1',
                      employeeName: currentEmployee?.name || 'عبد الفتاح عبعوب',
                      branchName: currentEmployee?.branchName || 'فرع تقرت الرئيسي',
                      actionType: 'update_settings' as any,
                      details: `تحديث هوية وتخصيصات الوكالة: تم تغيير اسم الموقع وألوانه وشعارات الهوية.`,
                      timestamp: new Date().toISOString()
                    };
                    await setDoc(doc(db, 'logs', logId), newLog);

                    setAgencySettings(newSettings);
                    localStorage.setItem('agencySettings', JSON.stringify(newSettings));
                    window.dispatchEvent(new Event('agencySettingsChanged'));

                    setShowSettingsModal(false);
                    showToast('تم حفظ وتحديث هوية وإعدادات الوكالة بنجاح وتعميمها على كافة الأجهزة!', 'success');
                  } catch (err) {
                    console.error(err);
                    showToast('حدث خطأ أثناء حفظ الإعدادات في قاعدة البيانات', 'error');
                  }
                }}
                className="space-y-4 text-right"
              >
                {/* Name Inputs */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-stone-600">اسم الموقع (بالعربية)</label>
                    <input
                      type="text"
                      value={editWebsiteName}
                      onChange={(e) => setEditWebsiteName(e.target.value)}
                      placeholder="مثال: وكالة عبعوب للسياحة والأسفار"
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-[11px] font-bold text-stone-600">الاسم بالإنجليزية</label>
                    <input
                      type="text"
                      value={editWebsiteEnglishName}
                      onChange={(e) => setEditWebsiteEnglishName(e.target.value)}
                      placeholder="مثال: ABOUB TRAVEL & TOURISM"
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Dynamic Theme Colors */}
                <div className="bg-stone-50/60 p-4 rounded-2xl border border-stone-150 space-y-3">
                  <span className="text-xs font-extrabold text-stone-700 block">🎨 اللون الرئيسي للعلامة التجارية</span>
                  <p className="text-[10px] text-stone-450 leading-relaxed font-semibold">
                    اختر لون العلامة التجارية وسيتكفل النظام تلقائياً بتوليد التدرجات اللونية الفاتحة والداكنة لتطبيقها على جميع الواجهات والأزرار والتأثيرات فوراً.
                  </p>
                  <div className="flex items-center gap-3">
                    <div className="relative w-12 h-10 rounded-xl overflow-hidden border border-stone-200 shrink-0 shadow-xs">
                      <input
                        type="color"
                        value={editPrimaryColor}
                        onChange={(e) => setEditPrimaryColor(e.target.value)}
                        className="absolute inset-0 w-full h-full p-0 border-0 cursor-pointer scale-150"
                      />
                    </div>
                    <input
                      type="text"
                      value={editPrimaryColor}
                      onChange={(e) => setEditPrimaryColor(e.target.value)}
                      placeholder="#d97706"
                      className="w-full px-3 py-2 bg-white border border-stone-200 rounded-xl font-mono font-bold text-stone-850 text-xs focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500/80 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Logo Uploads */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Website "ع" Logo */}
                  <div className="border border-stone-150 rounded-2xl p-3 bg-stone-50/30 text-center space-y-2">
                    <span className="text-[11px] font-extrabold text-stone-700 block">لوجو "حرف ع" في الموقع</span>
                    <div className="flex items-center justify-center h-14 w-14 mx-auto rounded-xl bg-zinc-950 text-white overflow-hidden shadow-md">
                      {editWebsiteLogoUrl ? (
                        <img src={editWebsiteLogoUrl} className="h-full w-full object-cover" alt="Website logo preview" referrerPolicy="no-referrer" />
                      ) : (
                        <span className="text-lg font-black font-sans text-amber-400">ع</span>
                      )}
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-all font-bold text-[10px] rounded-lg border border-blue-200 cursor-pointer block text-center">
                        📥 رفع صورة جديدة
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleLogoFileChange(e, 'website')}
                          className="hidden"
                        />
                      </label>
                      {editWebsiteLogoUrl && (
                        <button
                          type="button"
                          onClick={() => setEditWebsiteLogoUrl('')}
                          className="px-3 py-1 bg-red-50 text-red-600 hover:bg-red-100 transition-all font-bold text-[10px] rounded-lg border border-red-100 cursor-pointer"
                        >
                          ❌ إزالة والعودة للافتراضي
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Receipt Logo */}
                  <div className="border border-stone-150 rounded-2xl p-3 bg-stone-50/30 text-center space-y-2">
                    <span className="text-[11px] font-extrabold text-stone-700 block">شعار الوصلات والفواتير المطبوعة</span>
                    <div className="flex items-center justify-center h-14 w-14 mx-auto rounded-xl bg-stone-100 overflow-hidden shadow-inner border border-stone-150">
                      {editReceiptLogoUrl ? (
                        <img src={editReceiptLogoUrl} className="h-full w-full object-contain p-1" alt="Receipt logo preview" referrerPolicy="no-referrer" />
                      ) : (
                        <img src="/logo.png" className="h-full w-full object-contain p-1" alt="Receipt logo default" referrerPolicy="no-referrer" />
                      )}
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="px-3 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-all font-bold text-[10px] rounded-lg border border-blue-200 cursor-pointer block text-center">
                        📥 رفع صورة جديدة
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleLogoFileChange(e, 'receipt')}
                          className="hidden"
                        />
                      </label>
                      {editReceiptLogoUrl && (
                        <button
                          type="button"
                          onClick={() => setEditReceiptLogoUrl('')}
                          className="px-3 py-1 bg-red-50 text-red-600 hover:bg-red-100 transition-all font-bold text-[10px] rounded-lg border border-red-100 cursor-pointer"
                        >
                          ❌ إزالة والعودة للافتراضي
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-4 flex items-center justify-end gap-2 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={() => setShowSettingsModal(false)}
                    className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                  >
                    إلغاء التراجع
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-all cursor-pointer inline-flex items-center gap-1.5 shadow-sm"
                  >
                    <CheckCircle2 size={14} />
                    <span>حفظ التعديلات وتعميم الهوية</span>
                  </button>
                </div>
              </form>
            ) : (
              (() => {
                const selectedTripForProfit = trips.find(t => t.id === selectedProfitTripId);
                if (selectedProfitTripId && selectedTripForProfit) {
                  return (
                    <TripProfitDetailEditor
                      trip={selectedTripForProfit}
                      customers={customers}
                      onSaveExpenses={handleSaveTripExpenses}
                      onBack={() => setSelectedProfitTripId(null)}
                    />
                  );
                }
                return (
                  <div className="space-y-5 text-right">
                    {/* Dynamic Profits Dashboard */}
                    <div className="bg-stone-50 p-4 rounded-2xl border border-stone-150">
                      <h4 className="text-xs font-black text-stone-800 mb-3 flex items-center gap-1.5">
                        <TrendingUp size={16} className="text-emerald-600" />
                        <span>ملخص الأرباح والمداخيل لجميع الرحلات</span>
                      </h4>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div className="bg-white p-3 rounded-xl border border-stone-100 shadow-2xs">
                          <span className="text-[10px] font-bold text-stone-450 block mb-0.5">إجمالي المبيعات</span>
                          <span className="text-sm font-black text-stone-850 font-mono font-sans">{(tripProfitSummary.totalSales).toLocaleString()} <span className="text-[9px] font-bold text-stone-500 font-sans">د.ج</span></span>
                        </div>
                        <div className="bg-white p-3 rounded-xl border border-stone-100 shadow-2xs">
                          <span className="text-[10px] font-bold text-stone-450 block mb-0.5">المبالغ المحصلة</span>
                          <span className="text-sm font-black text-blue-600 font-mono font-sans">{(tripProfitSummary.totalPaid).toLocaleString()} <span className="text-[9px] font-bold text-stone-500 font-sans">د.ج</span></span>
                        </div>
                        <div className="bg-white p-3 rounded-xl border border-stone-100 shadow-2xs">
                          <span className="text-[10px] font-bold text-stone-450 block mb-0.5">صافي الأرباح المقدرة</span>
                          <span className={`text-sm font-black font-mono font-sans ${tripProfitSummary.netProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {(tripProfitSummary.netProfit).toLocaleString()} <span className="text-[9px] font-bold text-stone-500 font-sans">د.ج</span>
                          </span>
                        </div>
                      </div>

                      <p className="text-[9px] text-stone-400 mt-2 font-semibold">
                        * ملاحظة: يتم احتساب صافي الأرباح على أساس (إجمالي المبيعات) مطروحاً منه مجموع نفقات كل رحلة (الإقامة، النقل، المرشد، التأمين، وأخرى). اضغط على أي رحلة أدناه لتعديل وحفظ مصاريفها وتفاصيل أرباحها.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[350px] overflow-y-auto p-1">
                      {trips.length === 0 ? (
                        <div className="col-span-2 py-8 text-center text-stone-400 font-bold bg-stone-50 rounded-2xl border border-stone-150">
                          لا توجد برامج رحلات مسجلة في النظام حالياً.
                        </div>
                      ) : (
                        trips.map(trip => {
                          const tripCustomers = customers.filter(c => c.tripId === trip.id);
                          const totalSales = tripCustomers.reduce((sum, c) => {
                            if (c.totalPrice !== undefined) return sum + c.totalPrice;
                            return sum + (trip.price * (c.peopleCount || 1));
                          }, 0);
                          const acc = trip.expenseAccommodation || 0;
                          const trans = trip.expenseTransport || 0;
                          const guide = trip.expenseGuide || 0;
                          const ins = trip.expenseInsurance || 0;
                          const other = trip.expenseOther || 0;
                          const netProfit = totalSales - (acc + trans + guide + ins + other);

                          return (
                            <button
                              key={trip.id}
                              type="button"
                              onClick={() => setSelectedProfitTripId(trip.id)}
                              className="text-right p-3 bg-white border border-stone-200 hover:border-amber-500 hover:bg-stone-50/40 rounded-2xl transition-all cursor-pointer flex flex-col justify-between h-full shadow-2xs group relative overflow-hidden text-stone-850"
                            >
                              <div className="w-full">
                                <div className="flex justify-between items-start gap-2 w-full">
                                  <h5 className="font-extrabold text-stone-850 group-hover:text-amber-600 text-xs transition-colors">{trip.name}</h5>
                                  <span className="text-[9px] bg-amber-50 text-amber-700 border border-amber-100 px-2 py-0.5 rounded-full font-bold shrink-0">
                                    {trip.destination}
                                  </span>
                                </div>
                                <div className="flex items-center gap-1.5 text-[9px] text-stone-400 font-bold mt-1">
                                  <span>📅 {trip.date}</span>
                                  <span>•</span>
                                  <span>{tripCustomers.reduce((sum, c) => sum + (c.peopleCount || 0), 0)} مسافر</span>
                                </div>
                              </div>
                              
                              <div className="mt-3 pt-2 border-t border-stone-100 flex items-center justify-between w-full">
                                <div>
                                  <span className="text-[9px] text-stone-400 block font-bold">المكتسب (المبيعات)</span>
                                  <span className="text-[11px] font-extrabold text-stone-700 font-mono">{totalSales.toLocaleString()} د.ج</span>
                                </div>
                                <div className="text-left">
                                  <span className="text-[9px] text-stone-400 block font-bold">صافي الأرباح</span>
                                  <span className={`text-[11px] font-black font-mono ${netProfit >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                                    {netProfit.toLocaleString()} د.ج
                                  </span>
                                </div>
                              </div>
                              
                              <span className="absolute left-2 top-2 text-stone-300 group-hover:text-amber-500 transition-colors text-[9px] font-bold">
                                تعديل ⚙️
                              </span>
                            </button>
                          );
                        })
                      )}
                    </div>

                    {/* Footer close */}
                    <div className="pt-4 flex items-center justify-end border-t border-stone-100">
                      <button
                        type="button"
                        onClick={() => setShowSettingsModal(false)}
                        className="px-5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                      >
                        إغلاق اللوحة السرية
                      </button>
                    </div>
                  </div>
                );
              })()
            )}
          </div>
        </div>
      )}

    </div>
  );
}


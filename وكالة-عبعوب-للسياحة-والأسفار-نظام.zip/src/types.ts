/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Customer {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  birthPlace: string;
  phone: string;
  tripId: string;
  peopleCount: number;
  registrationDate: string;
  invoiceNumber: string;
  notes?: string;
  age?: number;               // Auto-calculated age
  roomType?: string;          // Selected apartment / room type
  pricePerPerson?: number;    // Calculated price per person based on apartment type
  totalPrice?: number;        // Calculated totalPrice (pricePerPerson * peopleCount)
  role?: 'tourist' | 'organizer' | 'driver'; // الصفة (مؤطر، سائح، سائق)
}

export interface Trip {
  id: string;
  name: string;
  destination: string;
  price: number; // in DZD (Algerian Dinar)
  duration: string;
  date: string;
  status: 'active' | 'completed' | 'upcoming';
}

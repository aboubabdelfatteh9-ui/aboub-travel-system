/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Customer, Trip } from '../types';
import { Search, Edit2, Trash2, Printer, X, Save, Phone, MapPin, Calendar, Users, Building2 } from 'lucide-react';
import { calculateAge, getRoomOptionsForTrip } from './CustomerForm';

interface CustomerTableProps {
  customers: Customer[];
  trips: Trip[];
  onDeleteCustomer: (id: string) => void;
  onUpdateCustomer: (customer: Customer) => void;
  onPrintCustomer: (customer: Customer) => void;
}

export const CustomerTable: React.FC<CustomerTableProps> = ({
  customers,
  trips,
  onDeleteCustomer,
  onUpdateCustomer,
  onPrintCustomer,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Helper to find trip by ID
  const getTripName = (tripId: string) => {
    const trip = trips.find((t) => t.id === tripId);
    return trip ? trip.name : 'رحلة غير معروفة';
  };

  // Helper to show role badge
  const getRoleBadge = (role?: 'tourist' | 'organizer' | 'driver') => {
    if (role === 'organizer') {
      return (
        <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-250 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
          👔 المؤطر (مجاناً)
        </span>
      );
    }
    if (role === 'driver') {
      return (
        <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-250 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
          🚌 السائق (مجاناً)
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-semibold px-2.5 py-0.5 rounded-full">
        👤 سائح
      </span>
    );
  };

  // Filter customers depending on first or last name search
  const filteredCustomers = customers.filter((customer) => {
    const fullName = `${customer.firstName} ${customer.lastName}`.toLowerCase();
    const cleanSearch = searchTerm.toLowerCase().trim();
    return (
      fullName.includes(cleanSearch) ||
      customer.firstName.toLowerCase().includes(cleanSearch) ||
      customer.lastName.toLowerCase().includes(cleanSearch) ||
      customer.phone.includes(cleanSearch)
    );
  });

  // Handle Save in Editing Mode
  const handleEditSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCustomer) {
      if (!editingCustomer.firstName.trim() || !editingCustomer.lastName.trim()) {
        alert('الرجاء إدخال الاسم واللقب بشكل صحيح');
        return;
      }
      
      const computedAge = calculateAge(editingCustomer.birthDate);
      const chosenTrip = trips.find(t => t.id === editingCustomer.tripId);
      const isFree = editingCustomer.role === 'organizer' || editingCustomer.role === 'driver';
      const actualPricePerPerson = isFree ? 0 : (editingCustomer.pricePerPerson !== undefined ? editingCustomer.pricePerPerson : (chosenTrip?.price || 0));
      const computedTotalPrice = actualPricePerPerson * 1;

      onUpdateCustomer({
        ...editingCustomer,
        age: computedAge,
        peopleCount: 1,
        pricePerPerson: actualPricePerPerson,
        totalPrice: computedTotalPrice
      });
      setEditingCustomer(null);
    }
  };

  const handleEditRoleChange = (role: 'tourist' | 'organizer' | 'driver') => {
    if (!editingCustomer) return;
    const selected = trips.find(t => t.id === editingCustomer.tripId) || trips[0];
    const opts = getRoomOptionsForTrip(selected.id, selected.price);
    
    let finalPrice = editingCustomer.pricePerPerson;
    if (role === 'organizer' || role === 'driver') {
      finalPrice = 0;
    } else {
      // tourist: restore standard price of selected room option
      const matched = opts.find(o => o.label === editingCustomer.roomType);
      finalPrice = matched ? matched.price : selected.price;
    }

    setEditingCustomer({
      ...editingCustomer,
      role,
      pricePerPerson: finalPrice
    });
  };

  const handleEditTripChange = (tripId: string) => {
    if (!editingCustomer) return;
    const selected = trips.find(t => t.id === tripId);
    if (selected) {
      const opts = getRoomOptionsForTrip(selected.id, selected.price);
      const computedAge = calculateAge(editingCustomer.birthDate);
      
      let finalRoomType = opts[0]?.label || '';
      let finalPrice = opts[0]?.price || selected.price;

      if (editingCustomer.birthDate) {
        let recommendedOpt = null;
        if (selected.id === 'trip-istanbul-8d') {
          if (computedAge < 2) {
            recommendedOpt = opts.find(o => o.value === 'istanbul_child_under_2');
          } else if (computedAge >= 3 && computedAge <= 11) {
            recommendedOpt = opts.find(o => o.value === 'istanbul_child_3_11');
          } else {
            recommendedOpt = opts.find(o => o.value === 'istanbul_adult_double_triple');
          }
        } else if (selected.id === 'trip-center-algeria' || selected.id === 'trip-jijel-beach' || selected.id === 'trip-family-tunisia' || selected.id === 'trip-soviva-tunisia') {
          if (computedAge < 2) {
            recommendedOpt = opts.find(o => o.value === 'child_under_2');
          } else if (computedAge >= 3 && computedAge <= 10) {
            recommendedOpt = opts.find(o => o.value === 'child_3_10');
          } else {
            if (selected.id === 'trip-center-algeria') {
              recommendedOpt = opts.find(o => o.value === 'mergad_quad_five');
            } else if (selected.id === 'trip-jijel-beach') {
              recommendedOpt = opts.find(o => o.value === 'jijel_apt_5');
            } else if (selected.id === 'trip-family-tunisia') {
              recommendedOpt = opts.find(o => o.value === 'five_six');
            } else if (selected.id === 'trip-soviva-tunisia') {
              recommendedOpt = opts.find(o => o.value === 'soviva_standard');
            }
          }
        }

        if (recommendedOpt) {
          finalRoomType = recommendedOpt.label;
          finalPrice = recommendedOpt.price;
        }
      }

      if (editingCustomer.role === 'organizer' || editingCustomer.role === 'driver') {
        finalPrice = 0;
      }

      setEditingCustomer({
        ...editingCustomer,
        tripId,
        roomType: finalRoomType,
        pricePerPerson: finalPrice
      });
    }
  };

  const handleEditBirthDateChange = (birthDate: string) => {
    if (!editingCustomer) return;
    const computedAge = calculateAge(birthDate);
    const selected = trips.find(t => t.id === editingCustomer.tripId) || trips[0];
    const opts = getRoomOptionsForTrip(selected.id, selected.price);
    
    let finalRoomType = editingCustomer.roomType;
    let finalPrice = editingCustomer.pricePerPerson;

    let recommendedOpt = null;
    if (selected.id === 'trip-istanbul-8d') {
      if (computedAge < 2) {
        recommendedOpt = opts.find(o => o.value === 'istanbul_child_under_2');
      } else if (computedAge >= 3 && computedAge <= 11) {
        recommendedOpt = opts.find(o => o.value === 'istanbul_child_3_11');
      } else {
        recommendedOpt = opts.find(o => o.value === 'istanbul_adult_double_triple');
      }
    } else if (selected.id === 'trip-center-algeria' || selected.id === 'trip-jijel-beach' || selected.id === 'trip-family-tunisia' || selected.id === 'trip-soviva-tunisia') {
      if (computedAge < 2) {
        recommendedOpt = opts.find(o => o.value === 'child_under_2');
      } else if (computedAge >= 3 && computedAge <= 10) {
        recommendedOpt = opts.find(o => o.value === 'child_3_10');
      } else {
        if (selected.id === 'trip-center-algeria') {
          recommendedOpt = opts.find(o => o.value === 'mergad_quad_five');
        } else if (selected.id === 'trip-jijel-beach') {
          recommendedOpt = opts.find(o => o.value === 'jijel_apt_5');
        } else if (selected.id === 'trip-family-tunisia') {
          recommendedOpt = opts.find(o => o.value === 'five_six');
        } else if (selected.id === 'trip-soviva-tunisia') {
          recommendedOpt = opts.find(o => o.value === 'soviva_standard');
        }
      }
    }

    if (recommendedOpt) {
      finalRoomType = recommendedOpt.label;
      finalPrice = recommendedOpt.price;
    }

    if (editingCustomer.role === 'organizer' || editingCustomer.role === 'driver') {
      finalPrice = 0;
    }

    setEditingCustomer({
      ...editingCustomer,
      birthDate,
      age: computedAge,
      roomType: finalRoomType,
      pricePerPerson: finalPrice
    });
  };

  const handleEditRoomChange = (roomTypeLabel: string) => {
    if (!editingCustomer) return;
    const selected = trips.find(t => t.id === editingCustomer.tripId) || trips[0];
    if (selected) {
      const opts = getRoomOptionsForTrip(selected.id, selected.price);
      const matched = opts.find(o => o.label === roomTypeLabel);
      if (matched) {
        let finalPrice = matched.price;
        if (editingCustomer.role === 'organizer' || editingCustomer.role === 'driver') {
          finalPrice = 0;
        }
        setEditingCustomer({
          ...editingCustomer,
          roomType: roomTypeLabel,
          pricePerPerson: finalPrice
        });
      }
    }
  };

  // Get active room choices for editing modal
  const editingTripObj = editingCustomer ? (trips.find(t => t.id === editingCustomer.tripId) || trips[0]) : null;
  const editingRoomOptions = editingTripObj ? getRoomOptionsForTrip(editingTripObj.id, editingTripObj.price) : [];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6" dir="rtl">
      {/* Table Header & Search Input */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
        <div>
          <h2 className="font-sans font-bold text-lg text-slate-800">قائمة زبائن الوكالة</h2>
          <p className="text-xs text-slate-500 font-sans mt-0.5">
            إجمالي المحجوزين حالياً: <span className="font-semibold text-blue-600">{customers.length}</span> زبون
          </p>
        </div>

        {/* Dynamic Search */}
        <div className="relative w-full md:w-80">
          <input
            type="text"
            id="input-search-customers"
            placeholder="ابحث بالاسم، اللقب أو الهاتف..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-4 pr-10 py-2 rounded-xl border border-slate-200 text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-sans"
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
            <Search size={16} id="icon-search" />
          </div>
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              id="btn-clear-search"
              className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 hover:text-slate-600 font-sans text-xs"
            >
              مسح
            </button>
          )}
        </div>
      </div>

      {/* Empty State */}
      {filteredCustomers.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-center" id="empty-state">
          <div className="p-4 bg-slate-50 text-slate-400 rounded-full mb-3">
            <Search size={32} id="icon-search-big" />
          </div>
          <h3 className="font-sans font-semibold text-slate-700 text-base">لا توجد نتائج مطابقة</h3>
          <p className="text-xs text-slate-400 font-sans mt-1 max-w-sm">
            {customers.length === 0
               ? 'لم يتم تسجيل أي زبائن في النظام بعد. ابدأ بإدخال البيانات من النموذج الجانبي لملء القائمة.'
               : 'لم نجد أي زبون يطابق تفاصيل البحث التي أدخلتها. يرجى مراجعة التهجئة أو رقم الهاتف.'}
          </p>
        </div>
      ) : (
        /* Customers List / Table */
        <div className="overflow-x-auto animate-in fade-in duration-200">
          {/* Desktop Table View */}
          <table className="w-full text-right border-collapse hidden md:table font-sans">
            <thead>
              <tr className="border-b border-slate-100 text-slate-500 text-xs font-semibold uppercase">
                <th className="py-3 px-4 font-semibold text-slate-600">رقم الفاتورة</th>
                <th className="py-3 px-4 font-semibold text-slate-600">الزبون والسن</th>
                <th className="py-3 px-4 font-semibold text-slate-600">الصفة</th>
                <th className="py-3 px-4 font-semibold text-slate-600">معلومات الاتصال</th>
                <th className="py-3 px-4 font-semibold text-slate-600">الرحلة والإقامة المحددة</th>
                <th className="py-3 px-4 font-semibold text-slate-600 text-left">عائد الحجز</th>
                <th className="py-3 px-4 font-semibold text-slate-600 text-center">خيارات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-sm">
              {filteredCustomers.map((customer) => {
                const ageComputed = customer.age || calculateAge(customer.birthDate);
                const currentTrip = trips.find(t => t.id === customer.tripId);
                const showPricePerPerson = customer.pricePerPerson || currentTrip?.price || 0;
                const showTotalPrice = customer.totalPrice || (showPricePerPerson * (customer.peopleCount || 1));

                return (
                  <tr key={customer.id} className="hover:bg-slate-50/50 transition-colors group">
                    {/* Invoice Code */}
                    <td className="py-3 px-4">
                      <span className="font-mono text-xs font-semibold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md">
                        {customer.invoiceNumber}
                      </span>
                    </td>
                    {/* Customer Identity */}
                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-800">
                          {customer.firstName} {customer.lastName}
                        </span>
                        <span className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                          <Calendar size={12} id={`icon-calc-${customer.id}`} />
                          {customer.birthDate} ({customer.birthPlace}) • <strong className="text-blue-600">{ageComputed} سنة</strong>
                        </span>
                      </div>
                    </td>
                    {/* Role / الصفة */}
                    <td className="py-3 px-4">
                      {getRoleBadge(customer.role)}
                    </td>
                    {/* Customer Contact */}
                    <td className="py-3 px-4 text-slate-600 font-mono text-xs">
                      <span className="inline-flex items-center gap-1.5 bg-slate-50 border border-slate-100 text-slate-700 px-2.5 py-1 rounded-lg">
                        <Phone size={12} className="text-slate-400" id={`icon-phone-${customer.id}`} />
                        {customer.phone}
                      </span>
                    </td>
                    {/* Chosen Trip */}
                    <td className="py-3 px-4">
                      <div className="flex flex-col">
                        <span className="font-medium text-slate-800 max-w-[200px] truncate block" title={getTripName(customer.tripId)}>
                          {getTripName(customer.tripId)}
                        </span>
                        {customer.roomType && (
                          <div className="flex items-center gap-1 mt-0.5 text-[10px] text-blue-600 font-bold bg-blue-50/50 w-fit px-1.5 py-0.5 rounded border border-blue-100/25">
                            <span>🏠 {customer.roomType}</span>
                            <span className="text-slate-300 font-normal">|</span>
                            <span>{(showPricePerPerson).toLocaleString('ar-DZ')} دج/فرد</span>
                          </div>
                        )}
                      </div>
                    </td>
                    {/* Booking Price */}
                    <td className="py-3 px-4 text-left font-mono font-bold text-xs">
                      <span className="bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg inline-block text-blue-600">
                        {showTotalPrice.toLocaleString('ar-DZ')} د.ج
                      </span>
                    </td>
                    {/* Action Choices */}
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5 opacity-90 group-hover:opacity-100 transition-opacity">
                        {/* Print Ticket */}
                        <button
                          onClick={() => onPrintCustomer(customer)}
                          id={`btn-print-${customer.id}`}
                          title="طباعة تذكرة ووصل الزبون"
                          className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-blue-600 rounded-lg transition-colors cursor-pointer"
                        >
                          <Printer size={16} id={`icon-print-act-${customer.id}`} />
                        </button>

                        {/* Edit Fields */}
                        <button
                          onClick={() => setEditingCustomer(customer)}
                          id={`btn-edit-${customer.id}`}
                          title="تعديل معلومات الزبون"
                          className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-blue-600 rounded-lg transition-colors cursor-pointer"
                        >
                          <Edit2 size={16} id={`icon-edit-act-${customer.id}`} />
                        </button>

                        {/* Delete Client */}
                        <button
                          onClick={() => setDeleteConfirmId(customer.id)}
                          id={`btn-delete-${customer.id}`}
                          title="حذف الزبون من القائمة"
                          className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-rose-600 rounded-lg transition-colors cursor-pointer"
                        >
                          <Trash2 size={16} id={`icon-trash-act-${customer.id}`} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Mobile Grid Cards View */}
          <div className="grid grid-cols-1 gap-4 md:hidden font-sans">
            {filteredCustomers.map((customer) => {
              const ageComputed = customer.age || calculateAge(customer.birthDate);
              const currentTrip = trips.find(t => t.id === customer.tripId);
              const showPricePerPerson = customer.pricePerPerson || currentTrip?.price || 0;
              const showTotalPrice = customer.totalPrice || (showPricePerPerson * (customer.peopleCount || 1));

              return (
                <div key={customer.id} className="border border-slate-150 rounded-xl p-4 space-y-3 shadow-xs bg-white text-right">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                      {customer.invoiceNumber}
                    </span>
                    {getRoleBadge(customer.role)}
                  </div>

                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">
                      {customer.firstName} {customer.lastName}
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                      <Calendar size={12} id={`mob-cal-${customer.id}`} />
                      {customer.birthDate} - {customer.birthPlace} • <strong className="text-blue-600 text-xs">{ageComputed} سنة</strong>
                    </p>
                    <p className="text-xs text-slate-500 mt-1.5 font-mono flex items-center gap-1">
                      <Phone size={12} className="text-slate-400" id={`mob-phone-${customer.id}`} />
                      {customer.phone}
                    </p>
                  </div>

                  <div className="border-t border-slate-100 pt-2 text-xs text-slate-600 font-medium space-y-1.5">
                    <div>
                      <span className="text-slate-400 font-sans block mb-0.5">الرحلة المحجوزة:</span>
                      {getTripName(customer.tripId)}
                    </div>
                    {customer.roomType && (
                      <div className="flex items-center gap-1 text-[10px] text-blue-600 font-bold bg-blue-50/50 w-fit px-1.5 py-0.5 rounded">
                        <span>🏠 {customer.roomType}</span>
                        <span className="text-slate-300">|</span>
                        <span>{(showPricePerPerson).toLocaleString('ar-DZ')} دج</span>
                      </div>
                    )}
                    <div className="flex justify-between items-center bg-slate-50 p-1.5 rounded font-mono font-bold text-xs">
                      <span className="text-slate-500 font-sans font-normal text-[11px]">عائد الحجز الإجمالي:</span>
                      <span className="text-blue-600">{showTotalPrice.toLocaleString('ar-DZ')} د.ج</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                    <button
                      onClick={() => onPrintCustomer(customer)}
                      id={`mob-btn-print-${customer.id}`}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-slate-50 hover:bg-blue-50 text-slate-600 hover:text-blue-600 rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      <Printer size={14} id={`mob-print-i-${customer.id}`} />
                      طباعة
                    </button>
                    <button
                      onClick={() => setEditingCustomer(customer)}
                      id={`mob-btn-edit-${customer.id}`}
                      className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-blue-600 rounded-lg text-xs font-semibold cursor-pointer"
                    >
                      <Edit2 size={14} id={`mob-edit-i-${customer.id}`} />
                      تعديل
                    </button>
                    <button
                      onClick={() => setDeleteConfirmId(customer.id)}
                      id={`mob-btn-delete-${customer.id}`}
                      className="p-1.5 bg-slate-50 hover:bg-rose-50 text-rose-500 hover:text-rose-700 rounded-lg cursor-pointer"
                    >
                      <Trash2 size={14} id={`mob-trash-i-${customer.id}`} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 2. CUSTOM EDIT MODAL */}
      {editingCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-xl border border-slate-200 max-w-lg w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150" dir="rtl">
            <button
              onClick={() => setEditingCustomer(null)}
              id="modal-close"
              className="absolute top-4 left-4 p-1 rounded-full text-slate-400 bg-slate-50 hover:bg-slate-100 hover:text-slate-600 transition-colors cursor-pointer"
            >
              <X size={18} id="modal-close-icon" />
            </button>

            <h3 className="font-bold text-lg text-slate-800 mb-2 border-b border-slate-100 pb-3">تعديل معلومات الزبون</h3>

            <form onSubmit={handleEditSave} className="space-y-4 text-right">
              {/* Names */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="edit-firstName" className="block text-xs font-bold text-slate-600 mb-1">الاسم الأول</label>
                  <input
                    type="text"
                    id="edit-firstName"
                    value={editingCustomer.firstName}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, firstName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-stone-50 font-medium"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="edit-lastName" className="block text-xs font-bold text-slate-600 mb-1">اللقب</label>
                  <input
                    type="text"
                    id="edit-lastName"
                    value={editingCustomer.lastName}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, lastName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-stone-50 font-medium"
                    required
                  />
                </div>
              </div>

              {/* Birth details */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="edit-birthDate" className="block text-xs font-bold text-slate-600 mb-1">تاريخ الميلاد</label>
                  <input
                    type="date"
                    id="edit-birthDate"
                    value={editingCustomer.birthDate}
                    onChange={(e) => handleEditBirthDateChange(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-stone-50 font-medium"
                    required
                  />
                  <div className="mt-1 text-[11px] text-blue-600 font-bold">
                    📅 السن المحسوب: {calculateAge(editingCustomer.birthDate)} سنة
                  </div>
                </div>
                <div>
                  <label htmlFor="edit-birthPlace" className="block text-xs font-bold text-slate-600 mb-1">مكان الميلاد</label>
                  <input
                    type="text"
                    id="edit-birthPlace"
                    value={editingCustomer.birthPlace}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, birthPlace: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-stone-50 font-medium"
                    required
                  />
                </div>
              </div>

              {/* Phone & Role */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="edit-phone" className="block text-xs font-bold text-slate-600 mb-1 flex items-center gap-1.5">
                    رقم الهاتف
                  </label>
                  <input
                    type="text"
                    id="edit-phone"
                    value={editingCustomer.phone}
                    onChange={(e) => setEditingCustomer({ ...editingCustomer, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-100 rounded-lg text-sm bg-stone-50 font-mono text-right"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="edit-role" className="block text-xs font-bold text-slate-600 mb-1">الصفة</label>
                  <select
                    id="edit-role"
                    value={editingCustomer.role || 'tourist'}
                    onChange={(e) => handleEditRoleChange(e.target.value as 'tourist' | 'organizer' | 'driver')}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white font-medium text-slate-800"
                    required
                  >
                    <option value="tourist">سائح</option>
                    <option value="organizer">المؤطر (مجاناً)</option>
                    <option value="driver">السائق (مجاناً)</option>
                  </select>
                </div>
              </div>

              {/* Trip selection */}
              <div>
                <label htmlFor="edit-trip" className="block text-xs font-bold text-slate-600 mb-1">الرحلة السياحية</label>
                <select
                  id="edit-trip"
                  value={editingCustomer.tripId}
                  onChange={(e) => handleEditTripChange(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-stone-50 font-medium bg-white"
                >
                  {trips.map((trip) => (
                    <option key={trip.id} value={trip.id}>
                      {trip.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Edit Room Type / Pricing */}
              {editingRoomOptions.length > 0 && (
                <div className="bg-blue-50/50 p-3 rounded-lg border border-blue-100">
                  <label htmlFor="edit-roomType" className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1">
                    <Building2 size={14} className="text-blue-500" />
                    نوع الشقة والإقامة والأسعار للرحلة المختارة
                  </label>
                  <select
                    id="edit-roomType"
                    value={editingCustomer.roomType || ''}
                    onChange={(e) => handleEditRoomChange(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs bg-stone-50 font-medium bg-white"
                  >
                    {editingRoomOptions.map((opt, idx) => (
                      <option key={idx} value={opt.label}>
                        {opt.label} - {opt.price.toLocaleString('ar-DZ')} دج/فرد
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {/* Billing Calculations Preview inside Editing Mode */}
              <div className="bg-slate-50 border border-slate-100 rounded-lg p-3 text-[11px] font-sans flex justify-between items-center">
                <span className="font-bold text-slate-600">القيمة الجديدة لعائدات الحجز:</span>
                <span className="font-mono font-black text-xs text-blue-600">
                  {(editingCustomer.pricePerPerson || editingTripObj?.price || 0).toLocaleString('ar-DZ')} د.ج
                </span>
              </div>

              {/* Notes */}
              <div>
                <label htmlFor="edit-notes" className="block text-xs font-bold text-slate-600 mb-1">ملاحظات</label>
                <textarea
                  id="edit-notes"
                  rows={2}
                  value={editingCustomer.notes || ''}
                  onChange={(e) => setEditingCustomer({ ...editingCustomer, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-stone-50 font-medium resize-none"
                />
              </div>

              {/* Save & Cancel buttons */}
              <div className="flex items-center justify-end gap-2 border-t border-slate-100 pt-4 mt-2">
                <button
                  type="button"
                  onClick={() => setEditingCustomer(null)}
                  id="btn-edit-cancel"
                  className="px-4 py-2 text-sm font-semibold text-slate-500 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  id="btn-edit-save"
                  className="px-4 py-2 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm hover:shadow"
                >
                  <Save size={16} id="icon-save-edit" />
                  حفظ التغييرات
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. CONFIRM DELETE MODAL */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs font-sans">
          <div className="bg-white rounded-xl border border-slate-200 max-w-sm w-full p-6 shadow-xl relative text-center" dir="rtl">
            <div className="mx-auto w-12 h-12 bg-rose-50 text-rose-600 rounded-full flex items-center justify-center mb-4">
              <Trash2 size={24} id="icon-trash-modal" />
            </div>
            <h3 className="font-bold text-slate-800 text-lg mb-1">تأكيد الحذف</h3>
            <p className="text-xs text-slate-500 mb-6 font-medium">
              هل أنت متأكد من رغبتك في حذف هذا الحجز بشكل نهائي؟ لا يمكن التراجع عن هذا الإجراء لاحقاً.
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                id="btn-del-cancel"
                className="flex-1 py-1.88 text-sm font-semibold text-slate-500 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
              >
                تراجع
              </button>
              <button
                onClick={() => {
                  onDeleteCustomer(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                id="btn-del-confirm"
                className="flex-1 py-1.88 text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-all cursor-pointer shadow-sm"
              >
                نعم، احذف الزبون
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Customer, Trip } from '../types';
import { Printer, Calendar, MapPin, Users, HelpCircle, FileText, Bus, UserCheck, PhoneCall } from 'lucide-react';

interface TripManifestsProps {
  customers: Customer[];
  trips: Trip[];
}

interface ManifestMeta {
  toPlace: string;
  startDate: string;
  startTime: string;
  returnDate: string;
  docDate: string;
}

export function TripManifests({ customers, trips }: TripManifestsProps) {
  const [selectedTripId, setSelectedTripId] = useState<string>('');
  
  // Trip manifesting meta-fields stored per tripId
  const [manifestMeta, setManifestMeta] = useState<Record<string, ManifestMeta>>(() => {
    const stored = localStorage.getItem('aboub_manifest_meta');
    return stored ? JSON.parse(stored) : {};
  });

  // Keep selected trip updated when trips load
  useEffect(() => {
    if (trips.length > 0 && !selectedTripId) {
      setSelectedTripId(trips[0].id);
    }
  }, [trips, selectedTripId]);

  // Save meta to localStorage on change
  const updateMetaField = (tripId: string, flag: keyof ManifestMeta, value: string) => {
    setManifestMeta(prev => {
      const current = prev[tripId] || {
        toPlace: '',
        startDate: '',
        startTime: '',
        returnDate: '',
        docDate: new Date().toLocaleDateString('ar-DZ', { year: 'numeric', month: '2-digit', day: '2-digit' })
      };
      
      const updated = {
        ...prev,
        [tripId]: {
          ...current,
          [flag]: value
        }
      };
      localStorage.setItem('aboub_manifest_meta', JSON.stringify(updated));
      return updated;
    });
  };

  const activeTrip = trips.find(t => t.id === selectedTripId) || trips[0];

  // Get metadata for the active trip
  const currentMeta = activeTrip ? (manifestMeta[activeTrip.id] || {
    toPlace: activeTrip.destination || '',
    startDate: activeTrip.date || '',
    startTime: '08:00',
    returnDate: '',
    docDate: new Date().toLocaleDateString('ar-DZ', { year: 'numeric', month: '2-digit', day: '2-digit' })
  }) : {
    toPlace: '',
    startDate: '',
    startTime: '',
    returnDate: '',
    docDate: ''
  };

  // Filter passengers for the chosen trip
  const passengers = customers.filter(c => c.tripId === (activeTrip?.id || ''));

  // Sort passengers so that organizers and drivers are grouped or standard ordering
  const sortedPassengers = [...passengers].sort((a, b) => {
    // If we want to keep them chronologically as they registered
    return new Date(a.registrationDate).getTime() - new Date(b.registrationDate).getTime();
  });

  const getRoleArabic = (role?: 'tourist' | 'organizer' | 'driver') => {
    if (role === 'organizer') return 'مؤطر (مجاناً)';
    if (role === 'driver') return 'سائق (مجاناً)';
    return 'سائح';
  };

  const getRolePrintClass = (role?: 'tourist' | 'organizer' | 'driver') => {
    if (role === 'organizer') return 'bg-amber-50 text-amber-800 border border-amber-100 font-bold';
    if (role === 'driver') return 'bg-emerald-50 text-emerald-800 border border-emerald-100 font-bold';
    return 'text-slate-800';
  };

  // Helper to format Arabic date representation
  const formatBirthInfo = (birthDate: string, birthPlace: string) => {
    try {
      const d = new Date(birthDate);
      if (isNaN(d.getTime())) return `${birthDate} بـ ${birthPlace}`;
      const formattedDate = d.toLocaleDateString('ar-DZ', { year: 'numeric', month: '2-digit', day: '2-digit' });
      return `${formattedDate} بـ ${birthPlace}`;
    } catch {
      return `${birthDate} بـ ${birthPlace}`;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start" id="trip-manifest-page-viewport">
      
      {/* 1. LEFT SIDE DECK: TRIP SELECTOR (print:hidden) */}
      <div className="lg:col-span-3 space-y-4 print:hidden">
        <div className="bg-white rounded-xl border border-slate-200 p-4">
          <h3 className="font-sans font-bold text-slate-800 text-sm mb-3 flex items-center gap-1.5 border-b border-slate-100 pb-2">
            <Bus size={16} className="text-blue-600" />
            اختر الرحلة السياحية
          </h3>
          <p className="text-[11px] text-slate-400 mb-4 leading-normal">
            اضغط على أي برنامج أدناه لعرض قائمة المسافرين المسجلين فيه وتصديرها أو طباعتها فوراً.
          </p>

          <div className="space-y-2">
            {trips.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400 font-semibold bg-slate-50 rounded-lg border border-dashed border-slate-200">
                لا توجد رحلات مبرمجة حالياً
              </div>
            ) : (
              trips.map((trip) => {
                const count = customers.filter(c => c.tripId === trip.id).length;
                const isSelected = trip.id === selectedTripId;
                return (
                  <button
                    key={trip.id}
                    onClick={() => setSelectedTripId(trip.id)}
                    className={`w-full text-right p-3 rounded-lg border transition-all flex flex-col justify-start gap-1 cursor-pointer relative group ${
                      isSelected
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/10'
                        : 'bg-slate-50/50 hover:bg-slate-50 border-slate-200 text-slate-700'
                    }`}
                  >
                    <div className="flex justify-between items-start w-full gap-2">
                      <span className={`text-[9px] px-2 py-0.5 rounded font-black ${
                        isSelected ? 'bg-blue-500 text-white' : 'bg-slate-200/60 text-slate-600'
                      }`}>
                        {trip.duration}
                      </span>
                      <span className={`text-[10px] font-bold inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full ${
                        isSelected ? 'bg-white/20 text-white' : 'bg-blue-50 text-blue-600'
                      }`}>
                        {count} مسافر
                      </span>
                    </div>
                    <strong className="text-xs font-bold font-sans mt-1 group-hover:translate-x-[-2px] transition-transform">
                      {trip.name}
                    </strong>
                    <span className={`text-[10px] font-mono mt-0.5 ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                      المغادرة: {trip.date}
                    </span>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Dynamic Help Widget */}
        <div className="bg-gradient-to-br from-blue-50/50 to-indigo-50/30 p-4 rounded-xl border border-blue-100/50 text-right">
          <h4 className="text-xs font-bold text-blue-800 flex items-center gap-1.5 mb-1.5">
            <HelpCircle size={14} />
            كيف تعمل هذه القائمة؟
          </h4>
          <p className="text-[11px] text-slate-600 leading-relaxed font-sans">
            بمجرد قيامك بتسجيل زبون جديد في الصفحة الرئيسية واختيار رحلته، سينتقل اسمه آلياً إلى هذا الجدول مقسماً ببياناته الخاصة للشرطة ومفتشيات حافلات المسافرين مع إيقاف حسابات المقاعد الفانية لتسليمها للسائق.
          </p>
        </div>
      </div>

      {/* 2. THE MAIN OFFICIAL DECLARATION VIEW SHEET (A4 sized layout) */}
      <div className="lg:col-span-9 bg-white rounded-xl border border-slate-200 p-5 md:p-8 shadow-xs relative print:shadow-none print:border-none print:p-0 print:m-0">
        
        {/* Print controls row (print:hidden) */}
        {activeTrip && (
          <div className="flex flex-wrap items-center justify-between border-b border-slate-100 pb-4 mb-6 gap-3 print:hidden">
            <div>
              <h2 className="font-sans font-black text-slate-800 text-base flex items-center gap-2">
                <FileText className="text-blue-600" size={18} />
                بيان رحلة: {activeTrip.name}
              </h2>
              <p className="text-xs text-slate-400 font-sans mt-0.5">جهز قائمة النقل الرسمية بالبيانات المطلوبة لرجال رقابة الطرقات</p>
            </div>
            
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            >
              <Printer size={15} />
              طباعة قائمة الركاب (A4)
            </button>
          </div>
        )}

        {/* If no trip selected / empty view */}
        {!activeTrip ? (
          <div className="text-center py-16">
            <Bus size={48} className="mx-auto text-slate-300 animate-pulse mb-3" />
            <strong className="text-slate-600 text-sm block">الرجاء إعداد برنامج رحلة أولاً</strong>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">عند إضافة رحلة جديدة في تبويب البرامج، ستتمكن من تحرير وطباعة كشف السفر هنا.</p>
          </div>
        ) : (
          /* THE OFFICIAL AFRICAN-ARAB PRINTABLE SHEET */
          <div id="printable-manifest-document" className="bg-white text-right leading-relaxed font-sans text-slate-900 printable-card">
            
            {/* Top row headers */}
            <div className="grid grid-cols-2 gap-4 items-start pb-4 border-b border-double border-slate-300">
              {/* Upper Right */}
              <div>
                <h4 className="font-sans font-black text-xs text-slate-900 tracking-tight">شركة عبعوب للسياحة والأسفار</h4>
                <p className="text-[9px] text-slate-500 font-serif tracking-wider font-semibold mt-0.5">ABOUB TRAVEL AGENCY</p>
                <span className="text-[10px] text-slate-400 block mt-1">الرقم المكتبي: 01 - حي عياد تبسبست</span>
              </div>

              {/* Upper Left */}
              <div className="text-left font-sans flex flex-col items-end">
                <div className="flex items-center gap-1.5 text-xs text-slate-800 font-bold">
                  <span>تقرت في:</span>
                  <input
                    type="text"
                    value={currentMeta.docDate}
                    onChange={(e) => updateMetaField(activeTrip.id, 'docDate', e.target.value)}
                    placeholder="2026/06/12"
                    className="border-b border-dashed border-slate-300 font-bold text-xs text-slate-900 w-28 text-center py-0.5 focus:outline-none focus:border-blue-500 print:border-none print:px-0"
                  />
                </div>
                <div className="text-[9px] text-slate-400 mt-1 font-mono">سجل الولاية: 30 / تقرت</div>
              </div>
            </div>

            {/* Centered Large Title */}
            <div className="text-center my-6 space-y-1">
              <h1 className="font-sans font-black text-xl md:text-2xl text-slate-950 tracking-tight block border-b-2 border-slate-950 max-w-xs mx-auto pb-1 print:text-lg">
                قائمة الأشخاص للرحلة
              </h1>
              <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 inline-block">
                Trip Manifest ID: {activeTrip.id.replace('trip-', 'TM-')}
              </span>
            </div>

            {/* Declaration Paragraph with fillable input fields */}
            <div className="bg-slate-50/50 border border-slate-200 rounded-xl p-4 md:p-5 text-xs md:text-sm text-slate-800 leading-loose text-justify font-sans relative print:border-none print:bg-white print:p-0 print:leading-relaxed">
              نحن مدير شركة عبعوب للسياحة والأسفار نشهد على استغلال حافلة نقل المسافرين لقيامها برحلة من مقر وكالتنا الكائن بمحل رقم 01 بحي عياد تبسبست تقرت الشارع 01 إلى:
              
              <input
                type="text"
                value={currentMeta.toPlace}
                onChange={(e) => updateMetaField(activeTrip.id, 'toPlace', e.target.value)}
                placeholder=" (فراغ اكتب فيه الوجهة المحددة) "
                className="mx-1 px-2 py-0.5 font-bold border-b border-dashed border-slate-400 text-slate-950 text-center placeholder-slate-400 bg-blue-50/20 focus:outline-none focus:border-blue-600 focus:bg-white transition-all text-xs w-44 inline-block print:border-none print:bg-transparent print:p-0"
              />
              
              يوم:
              <input
                type="text"
                value={currentMeta.startDate}
                onChange={(e) => updateMetaField(activeTrip.id, 'startDate', e.target.value)}
                placeholder=" (يوم الانطلاق) "
                className="mx-1 px-2 py-0.5 font-bold border-b border-dashed border-slate-400 text-slate-950 text-center placeholder-slate-400 bg-blue-50/20 focus:outline-none focus:border-blue-600 focus:bg-white transition-all text-xs w-36 inline-block print:border-none print:bg-transparent print:p-0"
              />

              على الساعة:
              <input
                type="text"
                value={currentMeta.startTime}
                onChange={(e) => updateMetaField(activeTrip.id, 'startTime', e.target.value)}
                placeholder=" (ساعة الانطلاق المحددة) "
                className="mx-1 px-2 py-0.5 font-bold border-b border-dashed border-slate-400 text-slate-950 text-center placeholder-slate-400 bg-blue-50/20 focus:outline-none focus:border-blue-600 focus:bg-white transition-all text-xs w-28 inline-block print:border-none print:bg-transparent print:p-0"
              />

              والعودة يوم:
              <input
                type="text"
                value={currentMeta.returnDate}
                onChange={(e) => updateMetaField(activeTrip.id, 'returnDate', e.target.value)}
                placeholder=" (تاريخ رجوع الحافلة) "
                className="mx-1 px-2 py-0.5 font-bold border-b border-dashed border-slate-400 text-slate-950 text-center placeholder-slate-400 bg-blue-50/20 focus:outline-none focus:border-blue-600 focus:bg-white transition-all text-xs w-36 inline-block print:border-none print:bg-transparent print:p-0"
              />
              إلى مقر وكالتنا للقائمة التالية:
            </div>

            {/* THE FOUR-COLUMN PASSENGER MANIFEST TABLE */}
            <div className="mt-6 overflow-hidden border border-slate-300 rounded-lg shadow-xs print:shadow-none print:border-slate-400">
              <table className="w-full text-right border-collapse">
                <thead>
                  <tr className="bg-slate-100/80 text-slate-900 border-b border-slate-300 text-[11px] md:text-xs font-bold font-sans print:bg-slate-100">
                    <th className="py-2.5 px-3 border-l border-slate-300 text-center w-12">الرقم</th>
                    <th className="py-2.5 px-4 border-l border-slate-300">الاسم واللقب</th>
                    <th className="py-2.5 px-4 border-l border-slate-300">تاريخ ومكان الميلاد</th>
                    <th className="py-2.5 px-4">الصفة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs text-slate-800 print:divide-slate-300">
                  {sortedPassengers.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="py-8 text-center text-xs text-slate-400 font-semibold italic bg-slate-50/30">
                        لا يوجد أي مسافر أو زبون مسجل في هذه الرحلة حالياً.
                      </td>
                    </tr>
                  ) : (
                    sortedPassengers.map((customer, index) => (
                      <tr key={customer.id} className="hover:bg-slate-50/30 transition-colors print:bg-white font-sans text-[11px] md:text-xs">
                        {/* Number column */}
                        <td className="py-2 px-3 border-l border-slate-200 text-center font-mono font-black border-slate-350 w-12">
                          {index + 1}
                        </td>
                        
                        {/* Full Name column */}
                        <td className="py-2 px-4 border-l border-slate-200 font-sans font-bold text-slate-950 border-slate-350">
                          {customer.firstName} {customer.lastName}
                        </td>
                        
                        {/* Birth info column */}
                        <td className="py-2 px-4 border-l border-slate-200 font-mono text-slate-900 border-slate-350">
                          {formatBirthInfo(customer.birthDate, customer.birthPlace)}
                        </td>
                        
                        {/* Role / الصفة column */}
                        <td className="py-2 px-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] print:text-slate-900 ${getRolePrintClass(customer.role)}`}>
                            {getRoleArabic(customer.role)}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Bottom summary and sign-off */}
            <div className="mt-8 flex justify-between items-center text-xs font-sans text-slate-500 pt-4 border-t border-slate-200">
              <div>
                إجمالي ركاب الحافلة المرفقين في الكشف: <strong className="text-slate-900 font-bold">{sortedPassengers.length} ركاب</strong>
              </div>
              <div className="text-left font-sans pl-2 print:pl-0">
                <p className="font-black text-slate-900">إمضاء وختم المدير:</p>
                <div className="w-32 h-16 border border-dashed border-slate-300 rounded mt-1 opacity-40"></div>
              </div>
            </div>

          </div>
        )}

      </div>
      
      {/* Global CSS injected into print mode for manifests */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-manifest-document, #printable-manifest-document * {
            visibility: visible;
          }
          #printable-manifest-document {
            position: absolute;
            left: 0;
            top: 0;
            width: 210mm;
            min-height: 297mm;
            padding: 15mm;
            margin: 0;
            box-shadow: none;
            border: none;
            background: white !important;
          }
          /* Treat inputs as regular text in printing */
          #printable-manifest-document input {
            border: none !important;
            border-bottom: none !important;
            background: transparent !important;
            padding: 0 !important;
            margin: 0 !important;
            width: auto !important;
            text-align: center !important;
            font-weight: bold !important;
            color: #000 !important;
          }
          #printable-manifest-document input::placeholder {
            color: transparent !important;
          }
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `}</style>
    </div>
  );
}

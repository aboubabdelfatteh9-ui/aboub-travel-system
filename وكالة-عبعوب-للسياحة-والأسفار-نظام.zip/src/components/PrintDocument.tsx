/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Customer, Trip } from '../types';
import { Logo } from './Logo';
import { FileText, Download, Printer, X, Mail, Phone, MapPin, CheckCircle, Info, Calendar } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

interface PrintDocumentProps {
  customer: Customer | null;
  trips: Trip[];
  onClose: () => void;
}

// Simple age calculator helper duplicate to avoid circular dependencies
const calculateAge = (birthDateString: string): number => {
  if (!birthDateString) return 0;
  const today = new Date();
  const birthDate = new Date(birthDateString);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age >= 0 ? age : 0;
};

export const PrintDocument: React.FC<PrintDocumentProps> = ({ customer, trips, onClose }) => {
  const [isGenerating, setIsGenerating] = useState(false);

  if (!customer) return null;

  // Find associated trip
  const trip = trips.find((t) => t.id === customer.tripId) || {
    id: '',
    name: 'رحلة غير معروفة',
    destination: 'غير محدد',
    price: 0,
    duration: 'غير محدد',
    date: 'غير محدد',
    status: 'active'
  };

  // Resolve prices dynamically using apartment pricing when available
  const pricePerPerson = customer.pricePerPerson || trip.price;
  const totalPrice = customer.totalPrice !== undefined ? customer.totalPrice : pricePerPerson;

  // Get current date for issue
  const formattedDate = new Date().toLocaleDateString('ar-DZ', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // Calculate potential departure date in Arabic
  const formattedDepartureDate = trip.date !== 'غير محدد' 
    ? new Date(trip.date).toLocaleDateString('ar-DZ', { year: 'numeric', month: 'long', day: 'numeric' })
    : 'غير محدد';

  const ageComputed = customer.age || calculateAge(customer.birthDate);

  // Trigger PDF Download
  const downloadPDF = () => {
    const printArea = document.getElementById('a4-print-ticket-container');
    if (!printArea) return;
    
    setIsGenerating(true);

    // Hide control buttons on capturing, scale up resolution
    html2canvas(printArea, {
      scale: 3, // Very high density for crystal-clear Arabic fonts
      useCORS: true,
      backgroundColor: '#ffffff',
      logging: false,
    })
      .then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
        
        // standard A4 proportions (210 x 297 mm)
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4',
        });

        const imgWidth = 210;
        const pageHeight = 297;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
        pdf.save(`تذكرة_وكالة_عبعوب_${customer.lastName}_${customer.invoiceNumber}.pdf`);
        setIsGenerating(false);
      })
      .catch((err) => {
        console.error('Error generating PDF:', err);
        setIsGenerating(false);
        alert('حدث خطأ أثناء توليد ملف الـ PDF. يرجى المحاولة مجدداً أو استخدام ميزة الطباعة المباشرة.');
      });
  };

  // Trigger Native Browser Print
  const triggerNativePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 md:p-6 font-sans">
      {/* Printable page layout container */}
      <div className="bg-slate-50 rounded-2xl max-w-4xl w-full p-6 shadow-xl relative flex flex-col md:flex-row gap-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Controls Column (Hidden on print) */}
        <div className="md:w-1/4 flex flex-col justify-between gap-6 print:hidden">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-slate-800">
              <FileText className="text-blue-600" id="icon-filetext-print" />
              <h3 className="font-bold text-base">معاينة المستند</h3>
            </div>
            
            <p className="text-xs text-slate-500 leading-relaxed text-right" dir="rtl">
              هذه معاينة لـ "وصل تأكيد الحجز الرسمي". يمكنك تحميله كملف <strong>PDF</strong> وإرساله للزبون عبر واتساب، أو طباعته مباشرة عبر الطابعة المكتبية.
            </p>

            <div className="border-t border-slate-250 my-4 pt-4 space-y-2 text-right" dir="rtl">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">الزبون:</span>
                <span className="font-bold text-slate-800">{customer.firstName} {customer.lastName}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">سن الزبون:</span>
                <span className="font-bold text-blue-600">{ageComputed} سنة</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">الرقم المرجعي:</span>
                <span className="font-mono font-semibold text-slate-800">{customer.invoiceNumber}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">الرحلة:</span>
                <span className="font-semibold text-slate-800 truncate max-w-[120px]">{trip.destination}</span>
              </div>
              {customer.roomType && (
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">الإقامة:</span>
                  <span className="font-bold text-slate-800 truncate max-w-[120px]">{customer.roomType}</span>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-3">
            {/* Download PDF button */}
            <button
              onClick={downloadPDF}
              id="btn-download-pdf-modal"
              disabled={isGenerating}
              className={`w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all shadow active:scale-95 cursor-pointer ${
                isGenerating ? 'opacity-70 cursor-not-allowed' : ''
              }`}
            >
              <Download size={15} id="icon-download-pdf" />
              {isGenerating ? 'جاري التوليد...' : 'تحميل كملف PDF'}
            </button>

            {/* Direct Print button */}
            <button
              onClick={triggerNativePrint}
              id="btn-trigger-native-print"
              className="w-full py-2.5 px-4 bg-slate-850 hover:bg-slate-900 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-2 transition-all shadow active:scale-95 cursor-pointer"
            >
              <Printer size={15} id="icon-printer-direct" />
              طباعة مباشرة
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              id="btn-close-print-modal"
              className="w-full py-2 px-4 bg-white hover:bg-slate-100 border border-slate-200 text-slate-600 rounded-lg font-semibold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <X size={14} id="icon-close-print" />
              إغلاق المعاينة
            </button>
          </div>
        </div>

        {/* Paper Container Preview (The actual A4 Ticket) */}
        {/* We use specific class to print ONLY this element on print events */}
        <div className="flex-1 overflow-auto max-h-[80vh] md:max-h-none border border-slate-250 rounded-xl bg-white shadow-inner flex justify-center">
          
          <div
            id="a4-print-ticket-container"
            className="w-[210mm] min-h-[297mm] p-[15mm] bg-white text-slate-800 relative select-text flex flex-col justify-between shadow-xs"
            dir="rtl"
          >
            {/* 1. DOCUMENT WATERMARK */}
            <div className="absolute inset-0 opacity-[0.03] flex items-center justify-center pointer-events-none z-0">
              <Logo size={420} />
            </div>

            <div className="z-10 flex flex-col h-full justify-between">
              <div>
                {/* 2. RECIPIENT HEADER */}
                <div className="flex items-start justify-between border-b-2 border-blue-600 pb-5 mb-6 z-10">
                  {/* Agency details */}
                  <div className="space-y-1 text-right">
                    <Logo size={70} showText={false} />
                    <h1 className="font-sans font-black text-xl text-slate-800 tracking-tight mt-1">
                      وكالة عبعوب للسياحة والأسفار
                    </h1>
                    <p className="text-[10px] text-slate-500 font-mono tracking-wide uppercase">
                      ABOUB TRAVEL & TOURISM AGENCY
                    </p>
                    <div className="pt-2 flex flex-col gap-0.5 text-xs text-slate-600">
                      <span className="flex items-center gap-1.5 font-medium">
                        <MapPin size={12} className="text-blue-600" id="icon-pin-head" />
                        شارع ديدوش مراد، الجزائر الوسطى، الجزائر
                      </span>
                      <span className="flex items-center gap-1.5 font-mono">
                        <Phone size={12} className="text-blue-600" id="icon-phone-head" />
                        +213 (0) 23 45 67 89 / +213 (0) 550 12 34 56
                      </span>
                      <span className="flex items-center gap-1.5 font-mono">
                        <Mail size={12} className="text-blue-600" id="icon-mail-head" />
                        contact@aboubtravel.dz
                      </span>
                    </div>
                  </div>

                  {/* Document metadata (Invoice No, Date, Logo) */}
                  <div className="text-left flex flex-col items-end pt-2">
                    <div className="bg-blue-50 text-blue-700 font-bold px-4 py-1.5 rounded-xl border border-blue-100 text-xs mb-3 font-sans">
                      تأكيد حجز ووصل دفع رسمي
                    </div>
                    
                    <div className="space-y-1.5 text-xs text-slate-600 text-left font-sans">
                      <div>
                        الرقم المرجعي: <span className="font-mono text-slate-800 font-bold bg-slate-100 text-[11px] px-2 py-0.5 rounded">{customer.invoiceNumber}</span>
                      </div>
                      <div>
                        تاريخ الإصدار: <span className="text-slate-800 font-semibold">{formattedDate}</span>
                      </div>
                      <div>
                        الموقع الإلكتروني: <span className="font-mono text-slate-800 font-semibold">www.aboubtravel.dz</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. TICKET DESCRIPTION TITLE */}
                <div className="bg-gradient-to-r from-blue-700 to-blue-600 text-white rounded-xl py-3 px-5 mb-6 text-center select-none shadow-sm z-10 font-bold">
                  <h2 className="font-sans font-bold text-sm tracking-wide">بيانات الحجز ووثيقة السفر المؤكّدة</h2>
                </div>

                {/* 4. CUSTOMER PROFILE BLOCK */}
                <div className="border border-slate-200 rounded-xl p-4 mb-6 bg-slate-50/50 z-10">
                  <h3 className="font-sans font-bold text-xs text-blue-600 border-b border-slate-205 pb-2 mb-3 flex items-center gap-1.5">
                    <CheckCircle size={14} className="text-blue-600" id="icon-check-cust" />
                    أولاً: معلومات الزبون والمسافـر الرئيسي
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-y-3.5 gap-x-6 text-xs text-slate-700 text-right">
                    <div>
                      <span className="text-slate-400 block mb-0.5">الاسم واللقب الكامل:</span>
                      <strong className="text-slate-950 text-sm font-bold bg-white px-2 py-1 rounded border border-slate-200/50 inline-block">
                        {customer.lastName} {customer.firstName}
                      </strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">رقم الهاتف المحمول:</span>
                      <strong className="text-slate-900 font-mono text-sm tracking-wide bg-white px-2 py-1 rounded border border-slate-200/50 inline-block leading-none">
                        {customer.phone}
                      </strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">تاريخ الميلاد والسن:</span>
                      <strong className="text-slate-900">
                        {customer.birthDate} ({ageComputed} سنة)
                      </strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">مكان الميلاد المحدد:</span>
                      <strong className="text-slate-900">{customer.birthPlace}</strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">الصفة أو الفئة:</span>
                      <strong className="text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded border border-blue-200/50 inline-block">
                        {customer.role === 'organizer' ? '👔 المؤطر (مجاناً)' : customer.role === 'driver' ? '🚌 السائق (مجاناً)' : '👤 سائح'}
                      </strong>
                    </div>
                  </div>
                </div>

                {/* 5. VOYAGE DESCRIPTION BLOCK */}
                <div className="border border-slate-200 rounded-xl p-4 mb-6 bg-slate-50/50 z-10">
                  <h3 className="font-sans font-bold text-xs text-blue-600 border-b border-slate-205 pb-2 mb-3 flex items-center gap-1.5">
                    <Calendar size={14} className="text-blue-600" id="icon-cal-trip" />
                    ثانياً: تفاصيل البرنامج الخدمي للرحلة السياحية
                  </h3>

                  <div className="grid grid-cols-2 gap-y-3.5 gap-x-6 text-xs text-slate-700 text-right">
                    <div className="col-span-2">
                      <span className="text-slate-400 block mb-0.5">اسم البرنامج والمسار المعتمد:</span>
                      <strong className="text-slate-950 text-sm font-bold bg-white px-3 py-1.5 rounded border border-slate-200/50 block">
                        {trip.name}
                      </strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">الوجهة والبلد المستضيف:</span>
                      <strong className="text-slate-900">{trip.destination}</strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">مدة البرنامج المخططة:</span>
                      <strong className="text-slate-900">{trip.duration}</strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">تاريخ المغادرة المرتقب:</span>
                      <strong className="text-blue-600 font-bold">{formattedDepartureDate}</strong>
                    </div>

                    <div>
                      <span className="text-slate-400 block mb-0.5">نوع الشقة / الإقامة والترقية المختارة:</span>
                      <strong className="text-slate-900">
                        {customer.roomType || 'عرض قياسي موحدة'} ({pricePerPerson.toLocaleString('ar-DZ')} د.ج للشخص)
                      </strong>
                    </div>
                  </div>
                </div>

                {/* 6. REAL BILLING CALCULATION */}
                <div className="border border-slate-200 rounded-xl p-4 mb-6 bg-slate-50 z-10">
                  <div className="flex items-center justify-between text-slate-800 text-right">
                    <div>
                      <h4 className="font-sans font-bold text-xs text-slate-700">الحساب المالي الإجمالي للحجز:</h4>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        تفاصيل الحساب: {pricePerPerson.toLocaleString('ar-DZ')} د.ج {customer.roomType ? `(${customer.roomType})` : ''}
                      </p>
                    </div>
                    <div className="text-left font-sans col-span-1">
                      <span className="text-[10px] text-slate-400 block font-sans">المبلغ الكلي الشامل للضريبة (TTC):</span>
                      <strong className="text-lg text-blue-600 font-black tracking-tight font-mono">
                        {totalPrice.toLocaleString('ar-DZ')} د.ج
                      </strong>
                    </div>
                  </div>
                  {customer.notes && (
                    <div className="border-t border-slate-200 mt-3 pt-3 text-[10px] text-slate-500 leading-relaxed font-sans text-right">
                      <span className="font-bold block text-slate-700 mb-0.5">ملاحظات العميل الخاصة:</span>
                      {customer.notes}
                    </div>
                  )}
                </div>

                {/* 7. TERMS & REGULATIONS */}
                <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/20 z-10">
                  <h4 className="font-sans font-bold text-xs text-slate-700 mb-2 flex items-center gap-1 text-right">
                    <Info size={12} className="text-slate-400" id="icon-info-terms" />
                    شروط وقوانين السفر الأساسية:
                  </h4>
                  <ul className="list-decimal list-inside space-y-1 text-[10px] text-slate-500 leading-relaxed pl-2 text-right">
                    <li>يجب أن تكون التواريخ وجوازات السفر صالحة لمدة لا تقل عن ستة (06) أشهر من تاريخ السفر المخطط له.</li>
                    <li>يجب الحضور في المطار قبل ثلاث (03) ساعات على الأقل من موعد إقلاع الطائرة الرسمي.</li>
                    <li>لا يمكن للزبون تعديل الاسم واللقب أو استرجاع قيمة التذكرة بعد تأكيد الحجز وإصدار التأشيرة.</li>
                    <li>الوكالة غير مسؤولة عن أي تأخر ناتج عن قرارات جمركية أو إدارية في مكاتب المطارات والمقاصد.</li>
                  </ul>
                </div>
              </div>

              {/* 8. SIGNATURE AND STAMP SECTION */}
              <div className="flex items-center justify-between border-t border-slate-200 pt-6 mt-8 z-10">
                <div className="space-y-1 text-center w-1/3">
                  <span className="text-[10px] text-slate-400 block uppercase font-medium">توقيع المستفيد (الزبون)</span>
                  <div className="h-10 border-b border-slate-200 border-dashed"></div>
                  <span className="text-[9px] text-slate-400 block pt-1">توقيع بالمصادقة وقبول الشروط</span>
                </div>

                <div className="w-1/3 text-center flex justify-center items-center">
                  {/* Digital seal replica */}
                  <div className="border-2 border-blue-500/80 text-blue-500/80 rounded-full w-20 h-20 flex flex-col items-center justify-center border-dashed p-1 shrink-0 rotate-12 select-none">
                    <span className="text-[6px] font-bold tracking-tight text-center leading-none">وكالة عبعوب</span>
                    <span className="text-[8px] font-extrabold uppercase font-mono tracking-tighter">ABOUB AGENCY</span>
                    <div className="border-t border-blue-500/80 w-full my-0.5"></div>
                    <span className="text-[6px] font-bold">مصلحة السفر</span>
                  </div>
                </div>

                <div className="space-y-1 text-center w-1/3">
                  <span className="text-[10px] text-slate-400 block uppercase font-medium">ختم وتوقيع الوكالة الرسمي</span>
                  <div className="h-10 border-b border-slate-200 border-dashed"></div>
                  <span className="text-[9px] text-slate-400 block pt-1">تحريراً بالجزائر الوسطى في {formattedDate}</span>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Global CSS injected into print mode via direct print styles */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #a4-print-ticket-container, #a4-print-ticket-container * {
            visibility: visible;
          }
          #a4-print-ticket-container {
            position: absolute;
            left: 0;
            top: 0;
            width: 210mm;
            height: 297mm;
            padding: 15mm;
            margin: 0;
            box-shadow: none;
            border: none;
            background: white !important;
          }
          /* Ensure browser background colors show on prints */
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `}</style>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Customer, Trip } from '../types';
import { Sparkles, UserPlus, Phone, Calendar, MapPin, Users, PlaneTakeoff, Info, Building2 } from 'lucide-react';

interface CustomerFormProps {
  trips: Trip[];
  onAddCustomer: (customer: Omit<Customer, 'id' | 'registrationDate' | 'invoiceNumber'>) => void;
}

// Simple age calculator helper
export const calculateAge = (birthDateString: string): number => {
  if (!birthDateString) return 0;
  const today = new Date();
  const birthDate = new Date(birthDateString);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age >= 0 ? age : 0;
};

// Rich lookup table based on the customer's published ads
export const getRoomOptionsForTrip = (tId: string, basePrice: number) => {
  if (tId === 'trip-soviva-tunisia') {
    return [
      { value: 'soviva_standard', label: 'فندق Soviva Resort - فطور صباحي + عشاء (45,000 دج/شخص)', price: 45000 },
      { value: 'child_3_10', label: 'طفل من 3 إلى 10 سنوات (30,000 دج)', price: 30000 },
      { value: 'child_under_2', label: 'طفل أقل من سنتين (مجاناً - 0 دج)', price: 0 }
    ];
  }
  if (tId === 'trip-family-tunisia') {
    return [
      { value: 'five_six', label: 'شقة خماسية أو سداسية (24,000 دج/شخص)', price: 24000 },
      { value: 'quad', label: 'شقة رباعية (28,000 دج/شخص)', price: 28000 },
      { value: 'triple', label: 'شقة ثلاثية (30,000 دج/شخص)', price: 30000 },
      { value: 'double', label: 'شقة ثنائية (33,500 دج/شخص)', price: 33500 },
      { value: 'child_3_10', label: 'طفل من 3 إلى 10 سنوات (مقعد فقط - 10,000 دج)', price: 10000 },
      { value: 'child_under_2', label: 'طفل أقل من سنتين (مجاناً - 0 دج)', price: 0 }
    ];
  }
  if (tId === 'trip-jijel-beach') {
    return [
      { value: 'jijel_apt_5', label: 'شقة مجهزة - عائلية لـ 5 أفراد (12,900 دج/شخص)', price: 12900 },
      { value: 'jijel_apt_4', label: 'شقة مجهزة - عائلية لـ 4 أفراد (13,500 دج/شخص)', price: 13500 },
      { value: 'jijel_apt_3', label: 'شقة مجهزة - عائلية لـ 3 أفراد (14,500 دج/شخص)', price: 14500 },
      { value: 'jijel_apt_2', label: 'شقة مجهزة - عائلية لـ 2 أفراد (17,500 دج/شخص)', price: 17500 },
      { value: 'jijel_hotel', label: 'إقامة فندقية (ثنائي/ثلاثي/رباعي) مع فطور صباحي (25,000 دج/شخص)', price: 25000 },
      { value: 'child_3_10', label: 'طفل من 3 إلى 10 سنوات (مقعد فقط - 10,000 دج)', price: 10000 },
      { value: 'child_under_2', label: 'طفل أقل من سنتين (مجاناً - 0 دج)', price: 0 }
    ];
  }
  if (tId === 'trip-istanbul-8d') {
    return [
      { value: 'istanbul_adult_double_triple', label: 'شخص بالغ - غرفة ثنائية أو ثلاثية (129,000 دج/شخص)', price: 129000 },
      { value: 'istanbul_single', label: 'شخص واحد بمفرده - غرفة فردية (169,000 دج/شخص)', price: 169000 },
      { value: 'istanbul_child_3_11', label: 'طفل بين 3 إلى 11 سنة (99,000 دج/شخص)', price: 99000 },
      { value: 'istanbul_child_under_2', label: 'طفل أقل من سنتين (18,000 دج/شخص)', price: 18000 }
    ];
  }
  if (tId === 'trip-center-algeria') {
    return [
      { value: 'mergad_quad_five', label: 'مرقد - غرفة رباعية أو خماسية (12,500 دج/شخص)', price: 12500 },
      { value: 'mergad_triple', label: 'مرقد - غرفة ثلاثية (14,500 دج/شخص)', price: 14500 },
      { value: 'mergad_double', label: 'مرقد - غرفة ثنائية (15,500 دج/شخص)', price: 15500 },
      { value: 'hotel_stay', label: 'إقامة فندقية راقية (23,000 دج/شخص)', price: 23000 },
      { value: 'child_3_10', label: 'طفل من 3 إلى 10 سنوات (مقعد فقط - 10,000 دج)', price: 10000 },
      { value: 'child_under_2', label: 'طفل أقل من سنتين (مجاناً - 0 دج)', price: 0 }
    ];
  }

  // Fallback for custom trips added inside the dashboard
  return [
    { value: 'standard', label: `عرض قياسي موحد (${basePrice.toLocaleString('ar-DZ')} دج/شخص)`, price: basePrice },
    { value: 'double', label: `غرفة ثنائية مزدوجة (+10%) (${Math.round(basePrice * 1.1).toLocaleString('ar-DZ')} دج/شخص)`, price: Math.round(basePrice * 1.1) },
    { value: 'suite', label: `جناح سويت ملكي فاخر (+30%) (${Math.round(basePrice * 1.3).toLocaleString('ar-DZ')} دج/شخص)`, price: Math.round(basePrice * 1.3) }
  ];
};

export const CustomerForm: React.FC<CustomerFormProps> = ({ trips, onAddCustomer }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    birthDate: '',
    birthPlace: '',
    phone: '',
    tripId: trips[0]?.id || '',
    peopleCount: 1,
    notes: '',
    roomType: '',
    pricePerPerson: 0,
    role: 'tourist' as 'tourist' | 'organizer' | 'driver',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Sync apartment selection options and defaults on trip change
  useEffect(() => {
    if (trips.length > 0) {
      const selectedTripId = formData.tripId || trips[0].id;
      const tripObj = trips.find(t => t.id === selectedTripId) || trips[0];
      const opts = getRoomOptionsForTrip(tripObj.id, tripObj.price);
      
      // If tripId is not set or changed, correct it 
      setFormData(prev => {
        // If the current roomType matches one of the new options, keep it, otherwise use the first one
        const matches = opts.find(o => o.label === prev.roomType);
        const resolvedRoomType = matches ? prev.roomType : (opts[0]?.label || '');
        const standardPrice = matches ? matches.price : (opts[0]?.price || tripObj.price);
        // Free categories override standard price to 0
        const resolvedPrice = (prev.role === 'organizer' || prev.role === 'driver') ? 0 : standardPrice;

        return {
          ...prev,
          tripId: selectedTripId,
          roomType: resolvedRoomType,
          pricePerPerson: resolvedPrice
        };
      });
    }
  }, [trips, formData.tripId]);

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.firstName.trim()) newErrors.firstName = 'الرجاء إدخال الاسم الأول';
    if (!formData.lastName.trim()) newErrors.lastName = 'الرجاء إدخال اللقب';
    if (!formData.birthDate) newErrors.birthDate = 'الرجاء إدخال تاريخ الميلاد';
    if (!formData.birthPlace.trim()) newErrors.birthPlace = 'الرجاء تحديد مكان الميلاد';
    if (!formData.phone.trim()) {
      newErrors.phone = 'الرجاء إدخال رقم الهاتف';
    } else if (!/^(05|06|07|02|03|04)[0-9]{8}$/.test(formData.phone.replace(/\s/g, ''))) {
      newErrors.phone = 'يرجى إدخال رقم هاتف جزائري صحيح (مثال: 0550123456)';
    }
    if (!formData.tripId) newErrors.tripId = 'الرجاء اختيار الرحلة للزبون';
    if (!formData.roomType) newErrors.roomType = 'الرجاء اختيار نوع الشقة / الغرفة';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      const computedAge = calculateAge(formData.birthDate);
      const isFree = formData.role === 'organizer' || formData.role === 'driver';
      const actualPrice = isFree ? 0 : formData.pricePerPerson;
      const calculatedTotalPrice = actualPrice * 1;

      onAddCustomer({
        firstName: formData.firstName,
        lastName: formData.lastName,
        birthDate: formData.birthDate,
        birthPlace: formData.birthPlace,
        phone: formData.phone,
        tripId: formData.tripId,
        peopleCount: 1,
        notes: formData.notes,
        age: computedAge,
        roomType: formData.roomType,
        pricePerPerson: actualPrice,
        totalPrice: calculatedTotalPrice,
        role: formData.role,
      });

      // Reset form variables (retain tripId to facilitate multi-keyups)
      const currentTripId = formData.tripId || trips[0]?.id || '';
      const selected = trips.find(t => t.id === currentTripId);
      const opts = selected ? getRoomOptionsForTrip(selected.id, selected.price) : [];
      
      setFormData({
        firstName: '',
        lastName: '',
        birthDate: '',
        birthPlace: '',
        phone: '',
        tripId: currentTripId,
        peopleCount: 1,
        notes: '',
        roomType: opts[0]?.label || '',
        pricePerPerson: opts[0]?.price || 0,
        role: 'tourist',
      });
      setErrors({});
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    setFormData((prev) => {
      const updated = {
        ...prev,
        [name]: name === 'peopleCount' ? parseInt(value) || 1 : value,
      };

      // Recalculate options if trip changes or birthDate changes
      if (name === 'tripId' || name === 'birthDate') {
        const selectedTripId = name === 'tripId' ? value : prev.tripId;
        const currentBirthDate = name === 'birthDate' ? value : prev.birthDate;
        
        const selected = trips.find(t => t.id === selectedTripId);
        if (selected) {
          const opts = getRoomOptionsForTrip(selected.id, selected.price);
          
          let recommendedOpt = null;
          if (currentBirthDate) {
            const computedAge = calculateAge(currentBirthDate);
            if (selectedTripId === 'trip-istanbul-8d') {
              if (computedAge < 2) {
                recommendedOpt = opts.find(o => o.value === 'istanbul_child_under_2');
              } else if (computedAge >= 3 && computedAge <= 11) {
                recommendedOpt = opts.find(o => o.value === 'istanbul_child_3_11');
              } else {
                recommendedOpt = opts.find(o => o.value === 'istanbul_adult_double_triple');
              }
            } else if (selectedTripId === 'trip-center-algeria' || selectedTripId === 'trip-jijel-beach' || selectedTripId === 'trip-family-tunisia' || selectedTripId === 'trip-soviva-tunisia') {
              if (computedAge < 2) {
                recommendedOpt = opts.find(o => o.value === 'child_under_2');
              } else if (computedAge >= 3 && computedAge <= 10) {
                recommendedOpt = opts.find(o => o.value === 'child_3_10');
              } else {
                if (selectedTripId === 'trip-center-algeria') {
                  recommendedOpt = opts.find(o => o.value === 'mergad_quad_five');
                } else if (selectedTripId === 'trip-jijel-beach') {
                  recommendedOpt = opts.find(o => o.value === 'jijel_apt_5');
                } else if (selectedTripId === 'trip-family-tunisia') {
                  recommendedOpt = opts.find(o => o.value === 'five_six');
                } else if (selectedTripId === 'trip-soviva-tunisia') {
                  recommendedOpt = opts.find(o => o.value === 'soviva_standard');
                }
              }
            }
          }

          if (recommendedOpt) {
            updated.roomType = recommendedOpt.label;
            updated.pricePerPerson = recommendedOpt.price;
          } else {
            const matches = opts.find(o => o.label === prev.roomType);
            updated.roomType = matches ? prev.roomType : (opts[0]?.label || '');
            updated.pricePerPerson = matches ? matches.price : (opts[0]?.price || selected.price);
          }
        }
      }

      // Sync pricing when roomType changes manually
      if (name === 'roomType') {
        const tripObj = trips.find(t => t.id === prev.tripId) || trips[0];
        if (tripObj) {
          const opts = getRoomOptionsForTrip(tripObj.id, tripObj.price);
          const matched = opts.find(o => o.label === value);
          if (matched) {
            updated.pricePerPerson = matched.price;
          }
        }
      }

      // If the role changes or anything else changes, force 0 if role is organizer or driver
      if (updated.role === 'organizer' || updated.role === 'driver') {
        updated.pricePerPerson = 0;
      } else if (name === 'role' && value === 'tourist') {
        // Restore price to match current roomType standard price
        const tripObj = trips.find(t => t.id === updated.tripId) || trips[0];
        if (tripObj) {
          const opts = getRoomOptionsForTrip(tripObj.id, tripObj.price);
          const matched = opts.find(o => o.label === updated.roomType);
          updated.pricePerPerson = matched ? matched.price : tripObj.price;
        }
      }

      return updated;
    });

    // Clear error for field
    if (errors[name]) {
      setErrors((prev) => {
        const updated = { ...prev };
        delete updated[name];
        return updated;
      });
    }
  };

  // Age calculations for instantaneous display
  const liveAge = formData.birthDate ? calculateAge(formData.birthDate) : null;
  const activeSelectedTrip = trips.find(t => t.id === formData.tripId) || trips[0];
  const activeOptions = activeSelectedTrip ? getRoomOptionsForTrip(activeSelectedTrip.id, activeSelectedTrip.price) : [];

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm" dir="rtl">
      <div className="flex items-center gap-3 border-b border-slate-100 pb-4 mb-6">
        <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
          <UserPlus size={22} id="icon-user-plus" />
        </div>
        <div>
          <h2 className="font-sans font-bold text-lg text-slate-800">تسجيل زبون جديد</h2>
          <p className="text-xs text-slate-500 font-sans mt-0.5">أدخل معلومات الزبون وسيتم حساب العمر وتكلفة الإقامة والتذكرة تلقائياً</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5 font-sans">
        {/* Name and Lastname Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="firstName" className="block text-sm font-semibold text-slate-700 mb-1.5">
              الاسم الأول <span className="text-blue-500">*</span>
            </label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              placeholder="مثال: محمد"
              className={`w-full px-4 py-2.5 rounded-xl border font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all ${
                errors.firstName ? 'border-amber-400 bg-amber-50/10' : 'border-slate-200'
              }`}
            />
            {errors.firstName && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.firstName}</p>}
          </div>

          <div>
            <label htmlFor="lastName" className="block text-sm font-semibold text-slate-700 mb-1.5">
              اللقب (اسم العائلة) <span className="text-blue-500">*</span>
            </label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              placeholder="مثال: عبعوب"
              className={`w-full px-4 py-2.5 rounded-xl border font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all ${
                errors.lastName ? 'border-amber-400 bg-amber-50/10' : 'border-slate-200'
              }`}
            />
            {errors.lastName && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.lastName}</p>}
          </div>
        </div>

        {/* Birth Date and Birth Place */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="birthDate" className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Calendar size={16} className="text-slate-400" id="icon-calendar" />
              تاريخ الميلاد <span className="text-blue-500">*</span>
            </label>
            <input
              type="date"
              id="birthDate"
              name="birthDate"
              value={formData.birthDate}
              onChange={handleChange}
              className={`w-full px-4 py-2.5 rounded-xl border font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all ${
                errors.birthDate ? 'border-amber-400 bg-amber-50/10' : 'border-slate-200'
              }`}
            />
            {liveAge !== null && (
              <div className="mt-1.5 text-xs text-blue-600 font-bold bg-blue-50/80 px-2 py-1 rounded-md inline-flex items-center gap-1">
                📅 العمر المحسوب: <span className="underline">{liveAge} سنة</span>
              </div>
            )}
            {errors.birthDate && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.birthDate}</p>}
          </div>

          <div>
            <label htmlFor="birthPlace" className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <MapPin size={16} className="text-slate-400" id="icon-mappin" />
              مكان الميلاد <span className="text-blue-500">*</span>
            </label>
            <input
              type="text"
              id="birthPlace"
              name="birthPlace"
              value={formData.birthPlace}
              onChange={handleChange}
              placeholder="مثال: الجزائر العاصمة"
              className={`w-full px-4 py-2.5 rounded-xl border font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all ${
                errors.birthPlace ? 'border-amber-400 bg-amber-50/10' : 'border-slate-200'
              }`}
            />
            {errors.birthPlace && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.birthPlace}</p>}
          </div>
        </div>

        {/* Contact and Role */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="phone" className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Phone size={16} className="text-slate-400" id="icon-phone" />
              رقم الهاتف المحمول <span className="text-blue-500">*</span>
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="مثال: 0550123456"
              className={`w-full px-4 py-2.5 rounded-xl border font-mono font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-right ${
                errors.phone ? 'border-amber-400 bg-amber-50/10' : 'border-slate-200'
              }`}
            />
            {errors.phone && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.phone}</p>}
          </div>

          <div>
            <label htmlFor="role" className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
              <Users size={16} className="text-slate-400" id="icon-role" />
              الصفة <span className="text-blue-500">*</span>
            </label>
            <select
              id="role"
              name="role"
              value={formData.role}
              onChange={handleChange}
              className="w-full px-4 py-2.5 rounded-xl border border-slate-200 font-medium text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            >
              <option value="tourist">سائح</option>
              <option value="organizer">المؤطر (مجاناً)</option>
              <option value="driver">السائق (مجاناً)</option>
            </select>
          </div>
        </div>

        {/* Selected Trip Selection */}
        <div>
          <label htmlFor="tripId" className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <PlaneTakeoff size={16} className="text-slate-400" id="icon-planetakeoff" />
            الرحلة السياحية المطلوبة <span className="text-blue-500">*</span>
          </label>
          <select
            id="tripId"
            name="tripId"
            value={formData.tripId}
            onChange={handleChange}
            className={`w-full px-4 py-2.5 rounded-xl border font-medium text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all ${
              errors.tripId ? 'border-amber-400' : 'border-slate-200'
            }`}
          >
            {trips.map((trip) => (
              <option key={trip.id} value={trip.id}>
                {trip.name} | ({trip.duration})
              </option>
            ))}
          </select>
          {errors.tripId && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.tripId}</p>}
        </div>

        {/* NEW SPECIFIC APARTMENT / ACCOMODATION SELECTION FIELD */}
        {activeOptions.length > 0 && (
          <div className="bg-blue-50/[0.3] p-4 rounded-xl border border-blue-100/60 transition-all">
            <label htmlFor="roomType" className="block text-sm font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <Building2 size={16} className="text-blue-500" id="icon-roomtype" />
              نوع الشقة / ترتيب الإقامة والأسعار <span className="text-blue-500">*</span>
            </label>
            <select
              id="roomType"
              name="roomType"
              value={formData.roomType}
              onChange={handleChange}
              className={`w-full px-3 py-2.5 rounded-lg border font-medium text-xs text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all ${
                errors.roomType ? 'border-amber-400' : 'border-slate-200'
              }`}
            >
              {activeOptions.map((opt, i) => (
                <option key={i} value={opt.label}>
                  {opt.label} - {opt.price.toLocaleString('ar-DZ')} د.ج للشخص
                </option>
              ))}
            </select>
            {errors.roomType && <p className="text-xs text-amber-600 mt-1 font-medium">{errors.roomType}</p>}
          </div>
        )}

        {/* Dynamic Billing Calculations Real-time Card */}
        {activeSelectedTrip && (
          <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-4 space-y-2 mt-4 text-xs">
            <h4 className="font-bold text-slate-700 border-b border-slate-200 pb-1.5 mb-2">💰 الحساب المالي المباشر للمشتركين</h4>
            <div className="flex justify-between">
              <span className="text-slate-500">نوع الإقامة المحددة:</span>
              <span className="font-bold text-slate-800">{formData.roomType || 'افتراضية'}</span>
            </div>
            <div className="flex justify-between border-b border-slate-100 pb-2">
              <span className="text-slate-500">التكلفة للفرد الواحد:</span>
              <span className="font-mono font-bold text-slate-800">{(formData.pricePerPerson || 0).toLocaleString('ar-DZ')} دج</span>
            </div>
            <div className="pt-1 flex justify-between items-center text-sm">
              <span className="font-extrabold text-slate-800">العائدات الإجمالية المحتسبة:</span>
              <span className="font-mono font-black text-blue-600 text-base">
                {(formData.pricePerPerson || 0).toLocaleString('ar-DZ')} د.ج
              </span>
            </div>
          </div>
        )}

        {/* Optional Notes */}
        <div>
          <label htmlFor="notes" className="block text-sm font-semibold text-slate-700 mb-1.5 flex items-center gap-1.5">
            <Info size={16} className="text-slate-400" id="icon-info" />
            ملاحظات وتفاصيل إضافية (اختياري)
          </label>
          <textarea
            id="notes"
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows={2}
            placeholder="مثال: يحتاج كرسي متحرك، تفضيل السكن في فندق قريب..."
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all resize-none"
          />
        </div>

        {/* Form Actions */}
        <button
          type="submit"
          id="btn-submit-customer"
          className="w-full mt-4 flex items-center justify-center gap-2 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-center rounded-lg shadow-sm hover:shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all transform active:scale-[0.99] cursor-pointer"
        >
          <Sparkles size={18} id="icon-sparkles" />
          تسجيل الزبون وحفظ الحجز
        </button>
      </form>
    </div>
  );
};
